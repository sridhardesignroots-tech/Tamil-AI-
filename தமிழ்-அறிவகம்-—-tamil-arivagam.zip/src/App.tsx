import React, { useState, useEffect, useRef } from 'react';
import { 
  ResearchBrief, LensSelection, ResearchMode, LanguagePreference, 
  UserPreferences, ThemePreference 
} from './types/research';
import { DEMO_INVESTIGATIONS, SOURCES_DATABASE, SCHOLARS_DATABASE } from './data/mockInvestigations';
import { classifyUserQuery, ClassificationResult } from './utils/scopeClassifier';
import { ResearchDock } from './components/ResearchDock';
import { ResearchHeader } from './components/ResearchHeader';
import { ResearchInput } from './components/ResearchInput';
import { ResearchBriefView } from './components/ResearchBriefView';
import { EvidenceLens } from './components/EvidenceLens';
import { LandingHero } from './components/LandingHero';
import { SettingsWorkspace } from './components/SettingsWorkspace';
import { CollectionsModal } from './components/CollectionsModal';
import { ConversationScopeView } from './components/ConversationScopeView';
import { ProgressiveLoader } from './components/ProgressiveLoader';

export default function App() {
  // State
  const [activeInvestigationId, setActiveInvestigationId] = useState<string | null>(null);
  const [currentBrief, setCurrentBrief] = useState<ResearchBrief | null>(null);
  const [activeScopeView, setActiveScopeView] = useState<{
    userQuery: string;
    classification: ClassificationResult;
  } | null>(null);
  const [isDockCollapsed, setIsDockCollapsed] = useState<boolean>(false);
  const [isLensOpen, setIsLensOpen] = useState<boolean>(false);
  const [selectedLensEntity, setSelectedLensEntity] = useState<LensSelection | null>(null);
  const [researchMode, setResearchMode] = useState<ResearchMode>('deep');
  const [language, setLanguage] = useState<LanguagePreference>('ta');
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [settingsTab, setSettingsTab] = useState<string>('General');
  const [isCollectionsModalOpen, setIsCollectionsModalOpen] = useState<boolean>(false);
  const [savedBriefIds, setSavedBriefIds] = useState<string[]>(['roman-tamil-trade']);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // User preferences
  const [preferences, setPreferences] = useState<UserPreferences>({
    defaultMode: 'research',
    language: 'ta',
    theme: 'ivory',
    readingDensity: 'balanced',
    tamilTextSize: 'normal',
    evidencePreferences: {
      prioritizePrimaryText: true,
      requireArchaeology: true,
      showScholarlyDebates: true,
      showUncertaintyBadges: true,
      showProvenance: true,
      showLexicalBreakdown: true,
      allowAIIllustrations: true
    },
    aiBehaviour: {
      strictEvidenceFiltering: true,
      distinguishModernFromAncientTerminology: true,
      neverManufactureCertainty: true
    }
  });

  // Apply theme class to body
  useEffect(() => {
    document.body.className = '';
    if (preferences.theme === 'ink') {
      document.body.classList.add('theme-ink', 'bg-[#1E2830]', 'text-[#F0F4F8]');
    } else if (preferences.theme === 'night') {
      document.body.classList.add('theme-night', 'bg-[#121417]', 'text-[#EDEFEF]');
    } else {
      document.body.classList.add('bg-[#F7F3EA]', 'text-[#171717]');
    }
  }, [preferences.theme]);

  // Keep language in sync with preferences
  useEffect(() => {
    setLanguage(preferences.language);
  }, [preferences.language]);

  // Scroll to top of content on investigation change
  const contentContainerRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (contentContainerRef.current) {
      contentContainerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [activeInvestigationId]);

  // Handle switching to a known investigation
  const handleSelectInvestigation = (id: string | null) => {
    setActiveScopeView(null);
    if (!id) {
      setActiveInvestigationId(null);
      setCurrentBrief(null);
      return;
    }
    setIsLoading(true);
    setTimeout(() => {
      setActiveInvestigationId(id);
      if (DEMO_INVESTIGATIONS[id]) {
        setCurrentBrief(DEMO_INVESTIGATIONS[id]);
        setResearchMode(DEMO_INVESTIGATIONS[id].researchMode);
      }
      setIsLoading(false);
      setIsLensOpen(false);
    }, 1400);
  };

  // Handle query submit
  const handleSubmitQuery = (query: string, mode: ResearchMode) => {
    // 1. Evaluate conversation scope & intent (Casual greeting vs Out-of-scope vs Tamil knowledge)
    const classification = classifyUserQuery(query);
    if (classification.intent === 'GREETING' || classification.intent === 'OUT_OF_SCOPE') {
      setActiveScopeView({
        userQuery: query,
        classification
      });
      setIsLoading(false);
      return;
    }

    // In-scope Tamil knowledge inquiry: proceed with research-first pipeline
    setActiveScopeView(null);
    setIsLoading(true);

    // Fuzzy match against known demo investigations
    const lower = query.toLowerCase();
    let matchedId = 'roman-tamil-trade';

    if (
      lower.includes('hard work') ||
      lower.includes('work') ||
      lower.includes('உழைப்பு') ||
      lower.includes('முயற்சி') ||
      lower.includes('effort') ||
      lower.includes('labor') ||
      lower.includes('labour') ||
      lower.includes('ஆள்வினை') ||
      lower.includes('alvinai') ||
      lower.includes('619')
    ) {
      matchedId = 'thirukkural-hard-work';
    } else if (
      lower.includes('391') ||
      lower.includes('கல்வி') ||
      lower.includes('education') ||
      lower.includes('learning') ||
      lower.includes('கற்க')
    ) {
      matchedId = 'thirukkural-391';
    } else if (
      lower.includes('kural') ||
      lower.includes('குறள்') ||
      lower.includes('thirukkural') ||
      lower.includes('திருக்குறள்')
    ) {
      matchedId = 'thirukkural-hard-work';
    } else if (lower.includes('pallar') || lower.includes('பள்ளர்') || lower.includes('mallar') || lower.includes('marutham') || lower.includes('devendrakula')) {
      matchedId = 'pallar-community-history';
    } else if (lower.includes('keeladi') || lower.includes('கீழடி') || lower.includes('excavation') || lower.includes('carbon')) {
      matchedId = 'keeladi-excavations';
    } else if (lower.includes('brahmi') || lower.includes('பிராமி') || lower.includes('script') || lower.includes('jambai') || lower.includes('mangulam') || lower.includes('கல்வெட்டு') || lower.includes('inscription')) {
      matchedId = 'tamil-brahmi-epigraphy';
    } else if (lower.includes('chola') || lower.includes('சோழ') || lower.includes('srivijaya') || lower.includes('kadaram') || lower.includes('rajendra')) {
      matchedId = 'chola-maritime-expeditions';
    } else if (lower.includes('rome') || lower.includes('roman') || lower.includes('உரோம') || lower.includes('muziris') || lower.includes('trade') || lower.includes('வாணிபம்') || lower.includes('வணிகம்') || lower.includes('கடல்')) {
      matchedId = 'roman-tamil-trade';
    } else {
      // Dynamic synthesis fallback structured brief adhering strictly to epistemology (Section D)
      setTimeout(() => {
        const dynamicBrief: ResearchBrief = {
          id: `custom-${Date.now()}`,
          query: query,
          tamilQuery: `ஆய்வு வினா: "${query}"`,
          category: 'Literature',
          completedDate: new Date().toISOString().split('T')[0],
          researchMode: mode,
          isDemoData: true,
          evidenceStatus: {
            primaryTextual: 'FOUND',
            archaeological: 'PARTIAL',
            independentSupporting: 'FOUND',
            scholarlyDiscussion: 'FOUND',
            directConnectionToModernTerminology: 'UNCERTAIN',
            dating: 'APPROXIMATE'
          },
          keyFinding: `Available evidence indicates that primary textual and epigraphical records in classical Tamil culture provide relevant contextual attestations for "${query}". The available evidence is limited in establishing direct unbroken continuity with modern administrative forms, and scholars have proposed different interpretations regarding the chronological stratigraphy.`,
          whatSourceActuallySays: `The identified classical sources document specific contextual usages. I could not verify a direct 1-to-1 retrospective connection to modern terminology from the available sources without subsequent medieval epigraphical records.`,
          primaryTexts: [
            {
              id: 'pt-custom-1',
              title: `Classical Reference Relevant to: ${query}`,
              work: 'Classical Tamil Corpus',
              period: 'Early Historic / Sangam Period',
              reference: 'Critical Edition Recension',
              originalTamil: `யாதும் ஊரே யாவரும் கேளிர்\nதீதும் நன்றும் பிறர்தர வாரா\nநோதலும் தணிதலும் அவற்றோ ரன்ன...`,
              modernTamil: `எல்லா ஊரும் எம் ஊரே; எல்லா மக்களும் எம் உறவினரே. நன்மையும் தீமையும் பிறர் தர வருவதில்லை...`,
              englishTranslation: `Every town is our hometown, and every person is our kin; good and evil come not from others...`,
              provenanceNotes: 'Preserved in palm-leaf recensions; referenced to demonstrate classical egalitarian poetic traditions.',
              verifiedStatus: 'VERIFIED'
            }
          ],
          archaeologicalEvidence: [
            {
              id: 'arch-custom-1',
              objectName: 'Inscribed Early Historic Ceramic Specimens',
              site: 'Vaigai & Palar River Basins',
              periodDate: 'c. 3rd century BCE – 2nd century CE',
              excavationReport: 'Archaeological Survey of India Epigraphical and Stratigraphic Surveys',
              description: 'Stratigraphically excavated black-and-red ware sherds bearing early post-firing graffiti and literacy markings.',
              museumOrRepository: 'State Department of Archaeology Repositories',
              verifiedStatus: 'PARTIALLY_VERIFIED',
              hasAuthenticPhoto: false
            }
          ],
          inscriptions: [],
          foreignSources: [],
          scholarlyDebates: [
            {
              id: 'debate-custom',
              topicTitle: `Methodological Interpretation regarding: ${query}`,
              interpretationA: {
                scholar: 'Classical Philological Tradition',
                publication: 'Textual Commentary Corpus',
                date: 'Medieval / Early Modern',
                argument: 'Interprets references through established poetic landscape grammar (Thinai) and allegorical continuity.',
                evidenceUsed: ['Tolkappiyam Porulatikaram', 'Commentaries of Ilampooranar and Nachinarkiniyar']
              },
              interpretationB: {
                scholar: 'Modern Archaeological & Epigraphical Historians',
                publication: 'Material Culture and Epigraphical Surveys',
                date: 'Contemporary',
                argument: 'Insists on physical stratigraphic corroboration before validating poetic descriptions as literal political chronicles.',
                evidenceUsed: ['AMS radiocarbon dates', 'Excavation trench profiles', 'Comparative numismatics']
              },
              whatIsAgreedUpon: 'High antiquity of linguistic and cultural traditions attested in the Tamil region.',
              whatRemainsDebated: 'The precise chronological boundaries and social organization represented in poetic verse.'
            }
          ],
          whatIsEstablished: [
            'Direct occurrences of the researched subject in classical or medieval Tamil literature.',
            'Continuous linguistic transmission preserved through palm-leaf manuscript lineages.'
          ],
          whatRemainsDebated: [
            'Exact absolute calendar dates of individual poetic anthologies.',
            'Direct correspondence between ancient terminology and modern societal formations.'
          ],
          timeline: [
            {
              id: 'tl-cust-1',
              era: 'Ancient',
              dateLabel: 'c. 300 BCE – 300 CE',
              title: 'Early Historic Textual Evidence Horizon',
              tamilTitle: 'தொடக்க வரலாற்றுக் காலப் பதிவுகள்',
              description: 'Primary composition of classical Sangam anthologies.',
              category: 'Literature'
            }
          ],
          knowledgeGraph: {
            nodes: [
              { id: 'kn-c1', label: query, type: 'question', description: 'User research investigation.' },
              { id: 'kn-c2', label: 'Classical Corpus', type: 'literature', description: 'Primary textual archive.' }
            ],
            edges: [
              { from: 'kn-c1', to: 'kn-c2', label: 'evidenced in' }
            ]
          },
          relatedResearch: [
            {
              topic: 'Epigraphical corroboration in Tamil-Brahmi inscriptions',
              tamilTopic: 'தமிழ்-பிராமிக் கல்வெட்டுச் சான்றுகள்',
              relevanceNotes: 'Automatically matched to your question. Relevance should be verified against the underlying sources.',
              suggestedQuery: `What inscriptions corroborate: ${query}?`
            }
          ]
        };

        setActiveInvestigationId(dynamicBrief.id);
        setCurrentBrief(dynamicBrief);
        setIsLoading(false);
      }, 500);
      return;
    }

    // Known mock load
    setTimeout(() => {
      setActiveInvestigationId(matchedId);
      setCurrentBrief(DEMO_INVESTIGATIONS[matchedId]);
      setIsLoading(false);
    }, 400);
  };

  const handleToggleSaveEvidence = (briefId: string) => {
    if (savedBriefIds.includes(briefId)) {
      setSavedBriefIds(savedBriefIds.filter(id => id !== briefId));
    } else {
      setSavedBriefIds([...savedBriefIds, briefId]);
    }
  };

  // If settings workspace is open, show the full-page Settings Workspace (Section 32)
  if (isSettingsOpen) {
    return (
      <SettingsWorkspace
        preferences={preferences}
        onUpdatePreferences={(updates) => setPreferences({ ...preferences, ...updates })}
        onBackToResearch={() => setIsSettingsOpen(false)}
        initialTab={settingsTab}
      />
    );
  }

  return (
    <div className="research-shell h-screen w-screen flex overflow-hidden bg-[#F7F3EA] dark:bg-[#121417] text-[#171717] dark:text-[#EDEFEF] transition-colors">
      {/* 1. LEFT COLUMN: RESEARCH DOCK */}
      <ResearchDock
        isCollapsed={isDockCollapsed}
        onToggleCollapse={() => setIsDockCollapsed(!isDockCollapsed)}
        currentInvestigationId={activeInvestigationId}
        onSelectInvestigation={handleSelectInvestigation}
        onOpenSettings={(tab) => {
          if (tab) setSettingsTab(tab);
          setIsSettingsOpen(true);
        }}
        onOpenCollections={() => setIsCollectionsModalOpen(true)}
        onNavigateHome={() => handleSelectInvestigation(null)}
        onNewResearch={() => handleSelectInvestigation(null)}
        onNavigateCategory={(category) => {
          if (category === 'home' || category === 'new-question') {
            handleSelectInvestigation(null);
          } else if (category === 'thirukkural') {
            handleSelectInvestigation('thirukkural-hard-work');
          } else if (category === 'literature') {
            handleSelectInvestigation('roman-tamil-trade');
          } else if (category === 'history') {
            handleSelectInvestigation('tamil-brahmi-epigraphy');
          } else if (category === 'sources' || category === 'saved' || category === 'books') {
            setIsCollectionsModalOpen(true);
          } else {
            handleSelectInvestigation(null);
          }
        }}
        savedEvidenceCount={savedBriefIds.length}
        language={language}
      />

      {/* 2. CENTER COLUMN: RESEARCH CANVAS (flex column: header, scrollable content, fixed bottom input) */}
      <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden relative">
        {/* Header */}
        <ResearchHeader
          currentTitle={currentBrief ? currentBrief.query : null}
          currentCategory={currentBrief ? currentBrief.category : undefined}
          isLensOpen={isLensOpen}
          onToggleLens={() => setIsLensOpen(!isLensOpen)}
          language={language}
          onLanguageChange={(l) => {
            setLanguage(l);
            setPreferences(p => ({ ...p, language: l }));
          }}
          researchMode={researchMode}
          onOpenSettings={(tab) => {
            if (tab) setSettingsTab(tab);
            setIsSettingsOpen(true);
          }}
        />

        {/* Scrollable Center Content Area */}
        <main
          ref={contentContainerRef}
          className="research-content flex-1 min-h-0 overflow-y-auto"
        >
          {isLoading ? (
            <ProgressiveLoader language={language} />
          ) : activeScopeView ? (
            <ConversationScopeView
              userQuery={activeScopeView.userQuery}
              classification={activeScopeView.classification}
              onSelectSuggestedPrompt={(q) => handleSubmitQuery(q, researchMode)}
              onOpenCollections={() => setIsCollectionsModalOpen(true)}
              language={language}
            />
          ) : currentBrief ? (
            <ResearchBriefView
              brief={currentBrief}
              onOpenLens={(selection) => {
                setSelectedLensEntity(selection);
                setIsLensOpen(true);
              }}
              onInitiateRelatedQuery={(q) => handleSubmitQuery(q, researchMode)}
              onToggleSaveEvidence={handleToggleSaveEvidence}
              isSaved={currentBrief ? savedBriefIds.includes(currentBrief.id) : false}
              language={language}
            />
          ) : (
            <LandingHero
              onSelectPrompt={(query, investigationId) => {
                if (investigationId) {
                  handleSelectInvestigation(investigationId);
                } else {
                  handleSubmitQuery(query, researchMode);
                }
              }}
              language={language}
            />
          )}
        </main>

        {/* Fixed Research Input Area (Only when browsing an answer/brief, to preserve calm on landing) */}
        {currentBrief && (
          <ResearchInput
            onSubmitQuery={handleSubmitQuery}
            isLoading={isLoading}
            activeMode={researchMode}
            onModeChange={(m) => setResearchMode(m)}
            language={language}
          />
        )}
      </div>

      {/* 3. RIGHT COLUMN: EVIDENCE LENS (Section 10, 11, 12) */}
      <EvidenceLens
        isOpen={isLensOpen}
        selection={selectedLensEntity}
        onClose={() => setIsLensOpen(false)}
        onSelectEntity={(type, id, data) => {
          setSelectedLensEntity({
            type,
            id,
            title: data?.title || data?.fullName || id,
            data
          });
        }}
        language={language}
      />

      {/* Curated Collections Modal */}
      <CollectionsModal
        isOpen={isCollectionsModalOpen}
        onClose={() => setIsCollectionsModalOpen(false)}
        onSelectCollectionTopic={(topic) => handleSubmitQuery(topic, 'research')}
        language={language}
      />
    </div>
  );
}
