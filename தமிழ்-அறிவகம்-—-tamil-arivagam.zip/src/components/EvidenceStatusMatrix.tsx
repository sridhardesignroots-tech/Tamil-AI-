import React from 'react';
import { EvidenceStatus } from '../types/research';
import { ShieldCheck, AlertTriangle, HelpCircle, CheckCircle2 } from 'lucide-react';

interface EvidenceStatusMatrixProps {
  status: EvidenceStatus;
  language: 'ta' | 'en' | 'mixed';
}

export const EvidenceStatusMatrix: React.FC<EvidenceStatusMatrixProps> = ({ status, language }) => {
  const getBadge = (val: string) => {
    switch (val) {
      case 'FOUND':
      case 'ESTABLISHED':
      case 'DOCUMENTED':
        return {
          bg: 'bg-emerald-950/20 text-emerald-800 border-emerald-800/30 dark:bg-emerald-900/30 dark:text-emerald-300 dark:border-emerald-700/40',
          icon: <CheckCircle2 className="w-3.5 h-3.5 mr-1 text-emerald-600 dark:text-emerald-400" />
        };
      case 'PARTIAL':
      case 'UNCLEAR':
      case 'UNCERTAIN':
      case 'APPROXIMATE':
      case 'DEBATED':
        return {
          bg: 'bg-amber-950/20 text-amber-800 border-amber-800/30 dark:bg-amber-900/30 dark:text-amber-300 dark:border-amber-700/40',
          icon: <AlertTriangle className="w-3.5 h-3.5 mr-1 text-amber-600 dark:text-amber-400" />
        };
      case 'NOT_FOUND':
      case 'NOT_IDENTIFIED':
      case 'NOT_ESTABLISHED':
      default:
        return {
          bg: 'bg-neutral-900/10 text-neutral-600 border-neutral-300 dark:bg-neutral-800 dark:text-neutral-400 dark:border-neutral-700',
          icon: <HelpCircle className="w-3.5 h-3.5 mr-1 text-neutral-500" />
        };
    }
  };

  const items = [
    {
      labelEn: 'Primary Textual Evidence',
      labelTa: 'மூல இலக்கியச் சான்று',
      val: status.primaryTextual
    },
    {
      labelEn: 'Archaeological Evidence',
      labelTa: 'தொல்லியல் சான்று',
      val: status.archaeological
    },
    {
      labelEn: 'Independent Supporting Evidence',
      labelTa: 'சுயாதீன துணைச் சான்று',
      val: status.independentSupporting
    },
    {
      labelEn: 'Scholarly Discussion',
      labelTa: 'ஆய்வறிஞர் விவாதம்',
      val: status.scholarlyDiscussion
    },
    {
      labelEn: 'Direct Modern Connection',
      labelTa: 'நவீனப் பெயருடன் நேரடித் தொடர்பு',
      val: status.directConnectionToModernTerminology
    },
    {
      labelEn: 'Dating & Chronology',
      labelTa: 'காலக்கணிப்பு முறை',
      val: status.dating
    }
  ];

  return (
    <div className="bg-[#F0ECE1] dark:bg-[#1D242B] border border-[#E5DFC8] dark:border-[#2D3842] rounded-lg p-4 my-5 transition-colors">
      <div className="flex items-center justify-between pb-3 mb-3 border-b border-[#E5DFC8] dark:border-[#2D3842]">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-[#A85C43]" />
          <h4 className="text-xs font-semibold uppercase tracking-wider text-[#9B8060] dark:text-[#C4A57F]">
            {language === 'ta' ? 'சான்று நம்பகத்தன்மை நிலை (EVIDENCE STATUS)' : 'EVIDENCE STATUS CLASSIFICATION'}
          </h4>
        </div>
        <span className="text-[11px] text-neutral-500 dark:text-neutral-400 font-serif italic">
          {language === 'ta' ? 'உறுதியை உருவாக்காதீர் • சான்றே முதன்மை' : 'Evidence Before Certainty • Strict Epistemology'}
        </span>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
        {items.map((it, idx) => {
          const badge = getBadge(it.val);
          return (
            <div
              key={idx}
              className="bg-white/70 dark:bg-black/20 border border-[#E5DFC8]/80 dark:border-[#2D3842] rounded p-2 flex flex-col justify-between"
            >
              <div className="text-[11px] font-medium text-neutral-700 dark:text-neutral-300 mb-1.5 leading-snug">
                {language === 'ta' ? it.labelTa : language === 'mixed' ? `${it.labelEn} (${it.labelTa})` : it.labelEn}
              </div>
              <div className="flex items-center">
                <span
                  className={`inline-flex items-center text-[10px] font-mono font-semibold px-2 py-0.5 rounded border ${badge.bg}`}
                >
                  {badge.icon}
                  {it.val}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
