import React from 'react';
import { Scholar } from '../types/research';
import { Users, ExternalLink, ShieldCheck, UserCheck, BookOpen } from 'lucide-react';

interface ScholarsListProps {
  scholars: Scholar[];
  onSelectScholar: (scholar: Scholar) => void;
  language?: 'ta' | 'en';
}

export const ScholarsList: React.FC<ScholarsListProps> = ({
  scholars,
  onSelectScholar,
  language = 'ta'
}) => {
  const isEn = language === 'en';
  if (!scholars || scholars.length === 0) return null;

  return (
    <section className="space-y-4">
      <div className="flex items-center justify-between pb-1 border-b border-[#E5DFC8] dark:border-[#2D3842]">
        <div className="flex items-center gap-2">
          <Users className="w-4 h-4 text-[#354653] dark:text-[#8498A9]" />
          <h2 className="text-xs font-mono font-bold uppercase tracking-wider text-neutral-900 dark:text-neutral-100">
            {isEn ? 'SCHOLARS, HISTORIANS & RESEARCHERS' : 'வரலாற்று ஆய்வாளர்கள் & அறிஞர்கள்'}
          </h2>
        </div>
        <span className="text-[11px] font-mono text-[#9B8060]">
          {isEn ? `${scholars.length} Peer-Reviewed Authorities` : `${scholars.length} அறிஞர்கள்`}
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {scholars.map((scholar) => (
          <div
            key={scholar.id}
            onClick={() => onSelectScholar(scholar)}
            className="p-4 rounded-xl bg-white dark:bg-[#1A2229] border border-[#E5DFC8] dark:border-[#2D3842] hover:border-[#A85C43] dark:hover:border-[#D47B62] transition-all cursor-pointer group shadow-2xs space-y-3 text-left"
          >
            <div className="flex items-start gap-3.5">
              {/* Authentic Portrait or Explicit "Portrait Unavailable" (Section 5) */}
              <div className="w-14 h-14 rounded-full bg-[#202931] border-2 border-[#E5DFC8] dark:border-[#354350] flex flex-col items-center justify-center shrink-0 overflow-hidden text-center">
                {scholar.photoStatus === 'AUTHENTIC' && scholar.imageUrl ? (
                  <img
                    src={scholar.imageUrl}
                    alt={scholar.fullName}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="p-1 flex flex-col items-center justify-center">
                    <span className="text-neutral-400 font-mono text-[9px] uppercase font-bold leading-tight">
                      {isEn ? 'Portrait' : 'உருவப்படம்'}
                    </span>
                    <span className="text-neutral-500 font-mono text-[8px] uppercase">
                      {isEn ? 'Unavailable' : 'இல்லை'}
                    </span>
                  </div>
                )}
              </div>

              {/* Scholar Details */}
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-1">
                  <h3 className="text-sm font-serif font-bold text-neutral-900 dark:text-white group-hover:text-[#A85C43] transition-colors truncate">
                    {scholar.fullName}
                  </h3>
                  <span className="text-[10px] font-mono text-[#9B8060] shrink-0 font-medium">
                    {scholar.birthDeath}
                  </span>
                </div>

                <div className="text-xs text-neutral-500 font-mono truncate">
                  {scholar.profession} • {scholar.field}
                </div>

                <div className="text-[11px] text-neutral-400 font-sans truncate">
                  {scholar.institution}
                </div>
              </div>
            </div>

            {/* Research Contribution */}
            <div className="space-y-1 pt-2 border-t border-[#E5DFC8]/60 dark:border-[#2D3842] text-xs">
              <div className="text-neutral-700 dark:text-neutral-300 leading-relaxed font-sans">
                <strong className="text-neutral-900 dark:text-white font-semibold">{isEn ? 'Research Contribution: ' : 'ஆய்வுப் பங்களிப்பு: '}</strong> {scholar.researchContribution}
              </div>

              {/* Key Publications */}
              {scholar.keyPublications && scholar.keyPublications.length > 0 && (
                <div className="text-[11px] font-serif text-[#A85C43] dark:text-[#D47B62] truncate flex items-center gap-1.5 pt-0.5">
                  <BookOpen className="w-3 h-3 shrink-0" />
                  <span className="truncate">{isEn ? 'Key Work: ' : 'முக்கிய நூல்: '}{scholar.keyPublications[0]}</span>
                </div>
              )}

              <div className="flex items-center justify-between text-[10px] font-mono text-neutral-400 pt-1">
                <span>{isEn ? 'Provenance: ' : 'மூலக் குறிப்பு: '}{scholar.photoNote}</span>
                <span className="text-[#A85C43] flex items-center gap-1 group-hover:underline">
                  <span>{isEn ? 'View Dossier' : 'விவரங்கள்'}</span>
                  <ExternalLink className="w-3 h-3" />
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
