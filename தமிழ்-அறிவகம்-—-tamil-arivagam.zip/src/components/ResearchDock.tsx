import React, { useState } from 'react';
import { 
  Home, PlusCircle, Feather, BookOpen, History, 
  Database, Bookmark, Settings, ChevronLeft, ChevronRight 
} from 'lucide-react';
import { RECENT_INVESTIGATIONS_LIST } from '../data/mockInvestigations';

interface ResearchDockProps {
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  currentInvestigationId: string | null;
  onSelectInvestigation: (id: string) => void;
  onOpenSettings: (tab?: string) => void;
  onOpenCollections?: () => void;
  onNavigateHome: () => void;
  onNewResearch: () => void;
  onNavigateCategory: (category: string) => void;
  savedEvidenceCount: number;
  language: 'ta' | 'en';
}

export const ResearchDock: React.FC<ResearchDockProps> = ({
  isCollapsed,
  onToggleCollapse,
  currentInvestigationId,
  onSelectInvestigation,
  onOpenSettings,
  onNavigateHome,
  onNewResearch,
  onNavigateCategory,
  savedEvidenceCount,
  language
}) => {
  const [activeItem, setActiveItem] = useState<string>('home');
  const isEn = language === 'en';

  // Section 16: Exact Left Navigation Items
  const navItems = [
    {
      id: 'home',
      icon: Home,
      label: 'Home',
      tamil: 'முகப்பு',
      action: () => {
        setActiveItem('home');
        onNavigateHome();
      }
    },
    {
      id: 'new-question',
      icon: PlusCircle,
      label: 'New Question',
      tamil: 'புதிய கேள்வி',
      action: () => {
        setActiveItem('new-question');
        onNewResearch();
      }
    },
    {
      id: 'thirukkural',
      icon: Feather,
      label: 'Thirukkural',
      tamil: 'திருக்குறள்',
      action: () => {
        setActiveItem('thirukkural');
        onNavigateCategory('thirukkural');
      }
    },
    {
      id: 'literature',
      icon: BookOpen,
      label: 'Literature',
      tamil: 'இலக்கியம்',
      action: () => {
        setActiveItem('literature');
        onNavigateCategory('literature');
      }
    },
    {
      id: 'history',
      icon: History,
      label: 'History',
      tamil: 'வரலாறு',
      action: () => {
        setActiveItem('history');
        onNavigateCategory('history');
      }
    },
    {
      id: 'sources',
      icon: Database,
      label: 'Sources',
      tamil: 'மூலங்கள்',
      action: () => {
        setActiveItem('sources');
        onNavigateCategory('sources');
      }
    },
    {
      id: 'saved',
      icon: Bookmark,
      label: 'Saved',
      tamil: 'சேமித்தவை',
      badge: savedEvidenceCount,
      action: () => {
        setActiveItem('saved');
        onNavigateCategory('saved');
      }
    }
  ];

  return (
    <aside
      className={`h-full bg-[#FAF8F5] dark:bg-[#12161A] border-r border-[#E7E2D8] dark:border-[#27323C] flex flex-col shrink-0 transition-all duration-200 z-30 select-none ${
        isCollapsed ? 'w-16' : 'w-[240px]'
      }`}
    >
      {/* Brand Header: Tamil AI (Section 16) */}
      <div className="h-16 px-4 border-b border-[#E7E2D8] dark:border-[#27323C] flex items-center justify-between">
        {!isCollapsed ? (
          <div 
            onClick={onNavigateHome}
            className="flex items-center gap-2.5 cursor-pointer group"
          >
            <div className="w-8 h-8 rounded-lg bg-[#8B3A1C] text-white flex items-center justify-center font-serif text-sm font-bold shadow-xs shrink-0 group-hover:scale-105 transition-transform">
              த
            </div>
            <div>
              <div className="text-base font-serif font-bold text-[#1C1917] dark:text-[#F8FAFC] tracking-tight flex items-center gap-1">
                <span>{isEn ? 'Tamil AI' : 'தமிழ் AI'}</span>
              </div>
              <div className="text-[10px] font-mono text-[#78716C] dark:text-[#94A3B8]">
                {isEn ? 'Scholarly Knowledge Engine' : 'தமிழ் அறிவுத் தளம்'}
              </div>
            </div>
          </div>
        ) : (
          <div 
            onClick={onNavigateHome}
            className="w-8 h-8 mx-auto rounded-lg bg-[#8B3A1C] text-white flex items-center justify-center font-serif text-sm font-bold shrink-0 cursor-pointer"
          >
            த
          </div>
        )}

        <button
          onClick={onToggleCollapse}
          className={`p-1.5 rounded-lg text-[#78716C] dark:text-[#94A3B8] hover:text-[#1C1917] dark:hover:text-[#F8FAFC] hover:bg-[#EFE9DD] dark:hover:bg-[#1E252D] transition-colors cursor-pointer ${
            isCollapsed ? 'mx-auto' : ''
          }`}
          title={isCollapsed ? (isEn ? 'Expand Navigation' : 'மெனுவை விரி') : (isEn ? 'Collapse Navigation' : 'மெனுவைச் சுருக்கு')}
        >
          {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </div>

      {/* Navigation List (Section 16: 7 items) */}
      <div className="flex-1 overflow-y-auto p-2 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isCurrent = activeItem === item.id;
          const primaryText = isEn ? item.label : item.tamil;
          const secondaryText = isEn ? item.tamil : item.label;

          return (
            <button
              key={item.id}
              onClick={item.action}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-colors text-xs font-medium cursor-pointer ${
                isCurrent
                  ? 'bg-white dark:bg-[#1E252D] text-[#8B3A1C] dark:text-[#E07A5F] shadow-xs font-semibold border border-[#E7E2D8] dark:border-[#334155]'
                  : 'text-[#57534E] dark:text-[#CBD5E1] hover:bg-white/70 dark:hover:bg-[#1E252D]/60'
              }`}
              title={primaryText}
            >
              <Icon className={`w-4 h-4 shrink-0 ${isCollapsed ? 'mx-auto' : ''}`} />
              
              {!isCollapsed && (
                <div className="min-w-0 flex-1 flex items-center justify-between">
                  <span className="truncate font-sans">{primaryText}</span>
                  <span className="text-[11px] opacity-60 truncate ml-1 font-mono">{secondaryText}</span>
                </div>
              )}

              {item.badge !== undefined && item.badge > 0 && !isCollapsed && (
                <span className="px-1.5 py-0.5 rounded-full text-[9px] font-mono bg-[#8B3A1C]/15 text-[#8B3A1C] dark:text-[#E07A5F] font-bold">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}

        {/* Recent Items Preview (Quiet, Subtle) */}
        {!isCollapsed && (
          <div className="pt-6 pb-2 px-1">
            <div className="text-[10px] font-mono uppercase tracking-wider text-[#A8A29E] dark:text-[#64748B] font-bold mb-2">
              {isEn ? 'RECENT INVESTIGATIONS' : 'சமீபத்திய ஆய்வுகள்'}
            </div>
            <div className="space-y-1">
              {RECENT_INVESTIGATIONS_LIST.slice(0, 3).map((item) => (
                <button
                  key={item.id}
                  onClick={() => onSelectInvestigation(item.id)}
                  className={`w-full text-left p-2 rounded-lg text-xs truncate transition-colors flex items-center gap-2 cursor-pointer ${
                    currentInvestigationId === item.id
                      ? 'bg-white dark:bg-[#1E252D] font-medium text-[#8B3A1C] dark:text-[#E07A5F] border border-[#E7E2D8] dark:border-[#334155]'
                      : 'text-[#78716C] dark:text-[#94A3B8] hover:bg-white/50 dark:hover:bg-[#1E252D]/50'
                  }`}
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-[#8B3A1C] shrink-0" />
                  <span className="truncate font-serif">{isEn ? item.title : (item.tamilTitle || item.title)}</span>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Small Bottom Area: Settings (Section 16) */}
      <div className="border-t border-[#E7E2D8] dark:border-[#27323C] p-2 bg-[#F5F0E6]/60 dark:bg-[#151A1F]">
        <button
          onClick={() => onOpenSettings()}
          className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-medium text-[#57534E] dark:text-[#CBD5E1] hover:bg-white dark:hover:bg-[#1E252D] transition-colors cursor-pointer"
          title={isEn ? "Settings" : "அமைப்புகள்"}
        >
          <Settings className={`w-4 h-4 shrink-0 ${isCollapsed ? 'mx-auto' : ''}`} />
          {!isCollapsed && (
            <div className="flex-1 flex items-center justify-between">
              <span>{isEn ? 'Settings' : 'அமைப்புகள்'}</span>
              <span className="text-[11px] opacity-60 font-mono">{isEn ? 'அமைப்புகள்' : 'Settings'}</span>
            </div>
          )}
        </button>
      </div>
    </aside>
  );
};
