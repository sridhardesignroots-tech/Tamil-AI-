import React, { useState } from 'react';
import { 
  Sparkles, ZoomIn, ZoomOut, RotateCcw, Download, RefreshCw, 
  Layers, AlertTriangle, Eye, X, Image as ImageIcon, Send 
} from 'lucide-react';
import { AIIllustration } from '../types/research';

interface AIVisualizationViewerProps {
  illustrations: AIIllustration[];
  customPrompts?: string[];
  onRequestCustomVisualization: (promptTheme: string) => void;
  language: 'ta' | 'en';
}

const DEFAULT_PROMPTS_EN = [
  'Show me how this place might have looked',
  'Generate the agricultural setting',
  'Show the architecture',
  'Visualize the people and clothing',
  'Create a map',
  'Show this historical event as a scene'
];

const DEFAULT_PROMPTS_TA = [
  'இடத்தின் தோற்றம் எப்படி இருந்திருக்கும்?',
  'பண்டைய வேளாண் நிலப்பரப்பைக் காட்டுக',
  'கட்டடக் கலை அமைப்பைக் காட்டுக',
  'மக்கள் உடை மற்றும் தோற்றத்தைக் காட்டுக',
  'பண்டைய வரலாற்று நிலப்படத்தை உருவாக்குக',
  'வரலாற்று நிகழ்வை ஒரு காட்சியாகக் காட்டுக'
];

export const AIVisualizationViewer: React.FC<AIVisualizationViewerProps> = ({
  illustrations,
  customPrompts,
  onRequestCustomVisualization,
  language
}) => {
  const isEn = language === 'en';
  const effectivePrompts = customPrompts || (isEn ? DEFAULT_PROMPTS_EN : DEFAULT_PROMPTS_TA);
  const [selectedIndex, setSelectedIndex] = useState<number>(0);
  const [scale, setScale] = useState<number>(1);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [customInput, setCustomInput] = useState<string>('');
  const [feedbackNotice, setFeedbackNotice] = useState<string | null>(null);

  const current = illustrations[selectedIndex] || illustrations[0];

  const handleZoomIn = () => setScale(prev => Math.min(prev + 0.25, 2.5));
  const handleZoomOut = () => setScale(prev => Math.max(prev - 0.25, 0.6));
  const handleReset = () => setScale(1);

  const handleRegenerate = () => {
    setIsGenerating(true);
    setFeedbackNotice(
      isEn
        ? 'Re-synthesizing historical visual context using updated archaeology parameters...'
        : 'தொல்லியல் தரவுகளின் அடிப்படையில் வரலாற்றுக் காட்சி மீண்டும் உருவாக்கப்படுகிறது...'
    );
    setTimeout(() => {
      setIsGenerating(false);
      setFeedbackNotice(isEn ? 'Generated updated historical visualization.' : 'புதிய காட்சியாக்கம் தயார்.');
      setTimeout(() => setFeedbackNotice(null), 3000);
    }, 1200);
  };

  const handleVariation = () => {
    setIsGenerating(true);
    setFeedbackNotice(
      isEn
        ? 'Creating perspective variation based on Sangam Thinai landscape descriptions...'
        : 'சங்கத் திணை அமைப்பின்படி மாற்றுப் பார்வை உருவாக்கப்படுகிறது...'
    );
    setTimeout(() => {
      setIsGenerating(false);
      setFeedbackNotice(isEn ? 'Variation created.' : 'மாற்றுப் பார்வை உருவாக்கப்பட்டது.');
      setTimeout(() => setFeedbackNotice(null), 3000);
    }, 1200);
  };

  const handleCustomRequest = (promptText: string) => {
    setIsGenerating(true);
    setFeedbackNotice(
      isEn
        ? `Synthesizing conjectural scene: "${promptText}". Note: Visualizations are illustrative reconstructions, not archaeological evidence.`
        : `காட்சி உருவாக்கப்படுகிறது: "${promptText}". குறிப்பு: இது விளக்கப் படம் மட்டுமே, நேரடி தொல்பொருள் சான்று அல்ல.`
    );
    onRequestCustomVisualization(promptText);
    setTimeout(() => {
      setIsGenerating(false);
      setTimeout(() => setFeedbackNotice(null), 4000);
    }, 1400);
  };

  if (!current) return null;

  return (
    <section className="rounded-2xl border-2 border-purple-200 dark:border-purple-900/60 bg-gradient-to-b from-purple-50/50 via-white to-purple-50/30 dark:from-[#171520] dark:via-[#131219] dark:to-[#171520] p-5 sm:p-6 space-y-5 shadow-xs">
      {/* Prominent Distinction Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-purple-200/70 dark:border-purple-900/50">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-purple-600 text-white flex items-center justify-center shadow-xs">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-serif font-bold text-neutral-900 dark:text-neutral-100">
                {isEn ? 'AI Historical Visualization Studio' : 'வரலாற்றுப் படக்காட்சி மையம் (AI)'}
              </h2>
              <span className="text-[10px] font-mono uppercase bg-purple-100 dark:bg-purple-950/80 text-purple-800 dark:text-purple-300 px-2 py-0.5 rounded font-bold border border-purple-300 dark:border-purple-800">
                {isEn ? 'CONJECTURAL MODEL' : 'ஊக மாதிரிப் படம்'}
              </span>
            </div>
            <div className="text-[11px] font-mono text-purple-700 dark:text-purple-400">
              {isEn ? 'ILLUSTRATIVE RECONSTRUCTION • NOT ARCHAEOLOGICAL PROOF' : 'விளக்கக் காட்சிப்படுத்தல் • தொல்பொருள் சான்று அல்ல'}
            </div>
          </div>
        </div>

        {/* Mandatory Non-Negotiable Disclaimer Banner */}
        <div className="w-full sm:w-auto p-2.5 rounded-lg bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 flex items-start gap-2 text-xs text-amber-900 dark:text-amber-200">
          <AlertTriangle className="w-4 h-4 shrink-0 text-amber-600 mt-0.5" />
          <p className="font-serif leading-snug">
            <strong>{isEn ? 'Mandatory Epistemic Label: ' : 'அறிவியல் எச்சரிக்கை: '}</strong>
            {isEn 
              ? 'AI-generated historical visualization — illustrative, not primary historical evidence.'
              : 'செயற்கை நுண்ணறிவு உருவாக்கிய மாதிரி — விளக்கப் படம் மட்டுமே, நேரடி வரலாற்றுச் சான்றல்ல.'}
          </p>
        </div>
      </div>

      {/* Main Image Stage */}
      <div className="relative rounded-xl overflow-hidden bg-neutral-900 border border-purple-200 dark:border-purple-900/80 shadow-md">
        {/* Visual Canvas */}
        <div className="relative min-h-[380px] max-h-[520px] flex items-center justify-center overflow-hidden bg-[#0C0B10]">
          {isGenerating ? (
            <div className="flex flex-col items-center justify-center p-8 text-center space-y-3">
              <div className="w-10 h-10 rounded-full border-3 border-purple-500 border-t-transparent animate-spin" />
              <div className="text-sm font-serif font-semibold text-purple-200">
                {isEn ? 'Rendering Scene from Historical Literary & Archaeological Context...' : 'இலக்கியம் மற்றும் தொல்லியல் சான்றுகளின்படி காட்சி உருவாக்கப்படுகிறது...'}
              </div>
              <div className="text-xs font-mono text-neutral-400">
                {isEn ? 'Constraining visual elements to verified material culture reports' : 'நிரூபிக்கப்பட்ட தரவுகளின் எல்லைக்குள் வரையறுக்கப்படுகிறது'}
              </div>
            </div>
          ) : (
            <div
              style={{ transform: `scale(${scale})`, transition: 'transform 0.15s ease-out' }}
              className="w-full h-full flex items-center justify-center origin-center"
            >
              <img
                src={current.imageUrl}
                alt={current.title}
                className="max-h-[500px] w-auto object-contain rounded select-none"
              />
            </div>
          )}

          {/* Persistent In-Image Watermark / Stamp */}
          <div className="absolute top-3 left-3 bg-black/75 backdrop-blur-xs border border-purple-500/40 px-3 py-1 rounded text-[10px] font-mono text-purple-300 flex items-center gap-1.5 shadow-sm">
            <Sparkles className="w-3 h-3 text-purple-400" />
            <span>{isEn ? 'AI RECONSTRUCTION • NOT ARCHAEOLOGICAL PROOF' : 'செயற்கை நுண்ணறிவு மாதிரி • தொல்பொருள் சான்று அல்ல'}</span>
          </div>

          {/* Floating Controls Bar */}
          <div className="absolute bottom-3 right-3 flex items-center bg-black/80 backdrop-blur-md border border-neutral-700 rounded-lg p-1 text-white gap-1 shadow-lg">
            <button
              onClick={handleZoomOut}
              className="p-1.5 hover:bg-neutral-800 rounded text-neutral-300 hover:text-white transition-colors cursor-pointer"
              title="Zoom Out"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <span className="px-1.5 text-xs font-mono">{Math.round(scale * 100)}%</span>
            <button
              onClick={handleZoomIn}
              className="p-1.5 hover:bg-neutral-800 rounded text-neutral-300 hover:text-white transition-colors cursor-pointer"
              title="Zoom In"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
            <button
              onClick={handleReset}
              className="px-2 py-1 text-[11px] font-mono hover:bg-neutral-800 rounded transition-colors text-neutral-300 cursor-pointer"
              title="Reset 100%"
            >
              100%
            </button>
            <span className="w-px h-4 bg-neutral-700 mx-0.5" />
            <button
              onClick={handleRegenerate}
              className="p-1.5 hover:bg-neutral-800 rounded text-neutral-300 hover:text-white transition-colors cursor-pointer"
              title={isEn ? "Regenerate Visualization" : "மீண்டும் உருவாக்கு"}
            >
              <RefreshCw className="w-4 h-4" />
            </button>
            <button
              onClick={handleVariation}
              className="p-1.5 hover:bg-neutral-800 rounded text-neutral-300 hover:text-white transition-colors cursor-pointer"
              title={isEn ? "Generate Alternative Variation" : "மாற்றுப் பார்வை உருவாக்கு"}
            >
              <Layers className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Scene Caption & Context */}
        <div className="p-4 bg-white dark:bg-[#16141F] border-t border-purple-200 dark:border-purple-900/60 space-y-1">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-serif font-bold text-neutral-900 dark:text-neutral-100">
              {current.title}
            </h3>
            <span className="text-[10px] font-mono text-purple-700 dark:text-purple-400 capitalize">
              {isEn ? 'Theme: ' : 'கருப்பொருள்: '}{(current.promptTheme || 'historical reconstruction').replace('_', ' ')}
            </span>
          </div>
          <p className="text-xs text-neutral-600 dark:text-neutral-300 font-sans leading-relaxed">
            {current.caption}
          </p>
        </div>
      </div>

      {/* Temporary Feedback Notification */}
      {feedbackNotice && (
        <div className="p-2.5 rounded-lg bg-purple-100 dark:bg-purple-950/60 border border-purple-300 dark:border-purple-800 text-xs font-mono text-purple-900 dark:text-purple-200 flex items-center gap-2 animate-fade-in">
          <Sparkles className="w-3.5 h-3.5 text-purple-600 shrink-0" />
          <span>{feedbackNotice}</span>
        </div>
      )}

      {/* Multiple Visualization Thumbnails (if available) */}
      {illustrations.length > 1 && (
        <div className="space-y-2">
          <div className="text-[11px] font-mono uppercase text-neutral-500 font-semibold">
            {isEn ? `AVAILABLE VISUAL PERSPECTIVES (${illustrations.length})` : `கிடைக்கப்பெறும் காட்சிப் பார்வைகள் (${illustrations.length})`}
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {illustrations.map((ill, idx) => (
              <button
                key={ill.id}
                onClick={() => { setSelectedIndex(idx); setScale(1); }}
                className={`p-2 rounded-xl text-left border transition-all cursor-pointer ${
                  selectedIndex === idx
                    ? 'border-purple-600 ring-2 ring-purple-400/20 bg-purple-50 dark:bg-purple-950/40'
                    : 'border-purple-200 dark:border-purple-900/40 bg-white dark:bg-[#181622] hover:border-purple-400'
                }`}
              >
                <div className="text-xs font-serif font-bold truncate text-neutral-900 dark:text-white">
                  {ill.title}
                </div>
                <div className="text-[10px] font-mono text-neutral-400 capitalize truncate mt-0.5">
                  {(ill.promptTheme || 'perspective').replace('_', ' ')}
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* User Custom Visualization Prompt Buttons (Section 7) */}
      <div className="space-y-2.5 pt-2">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-mono uppercase font-bold text-neutral-700 dark:text-neutral-300">
            {isEn ? 'REQUEST CUSTOM VISUAL RECONSTRUCTION' : 'தனிப்பயன் வரலாற்றுக் காட்சியை உருவாக்குக'}
          </span>
          <span className="text-[10px] font-mono text-purple-600 dark:text-purple-400">
            {isEn ? 'Literature & Archaeology Grounded' : 'இலக்கியம் & தொல்லியல் அடிப்படை'}
          </span>
        </div>

        <div className="flex flex-wrap gap-2">
          {effectivePrompts.map((promptText, idx) => (
            <button
              key={idx}
              onClick={() => handleCustomRequest(promptText)}
              disabled={isGenerating}
              className="px-3 py-1.5 rounded-lg text-xs font-mono bg-white dark:bg-[#181622] border border-purple-200 dark:border-purple-900/60 hover:border-purple-500 hover:text-purple-700 dark:hover:text-purple-300 text-neutral-700 dark:text-neutral-300 transition-all flex items-center gap-1.5 shadow-2xs cursor-pointer disabled:opacity-50"
            >
              <Sparkles className="w-3 h-3 text-purple-500" />
              <span>{promptText}</span>
            </button>
          ))}
        </div>

        {/* Freeform Visualization Prompt */}
        <div className="flex gap-2 pt-1">
          <input
            type="text"
            value={customInput}
            onChange={(e) => setCustomInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && customInput.trim()) {
                handleCustomRequest(customInput.trim());
                setCustomInput('');
              }
            }}
            placeholder={
              isEn 
                ? "Or describe a specific scene (e.g. 'Show the ancient Vaigai riverbank irrigation sluice in Marutham landscape')..."
                : "அல்லது ஒரு காட்சியை விவரிக்கவும் (எ.கா: 'மருத நில வைகைக் கரையின் பண்டைய மதகு அமைப்பு')..."
            }
            className="flex-1 bg-white dark:bg-[#181622] border border-purple-200 dark:border-purple-900/60 rounded-xl px-3 py-2 text-xs font-serif text-neutral-900 dark:text-white placeholder:text-neutral-400 outline-hidden focus:border-purple-500 focus:ring-1 focus:ring-purple-500"
          />
          <button
            onClick={() => {
              if (customInput.trim()) {
                handleCustomRequest(customInput.trim());
                setCustomInput('');
              }
            }}
            disabled={!customInput.trim() || isGenerating}
            className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-mono font-medium flex items-center gap-1.5 transition-colors disabled:opacity-50 cursor-pointer shadow-xs"
          >
            <span>{isEn ? 'Render' : 'உருவாக்கு'}</span>
            <Send className="w-3 h-3" />
          </button>
        </div>
      </div>
    </section>
  );
};
