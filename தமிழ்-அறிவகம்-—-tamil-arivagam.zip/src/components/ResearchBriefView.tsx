import React, { useState, useRef } from 'react';
import { ResearchBrief, LensSelection, ArchivalScanItem, BookRecord, Scholar } from '../types/research';
import { EvidenceStatusMatrix } from './EvidenceStatusMatrix';
import { PrimaryTextViewer } from './PrimaryTextViewer';
import { ScholarlyDebateCard } from './ScholarlyDebateCard';
import { ResearchTimeline } from './ResearchTimeline';
import { KnowledgeMap } from './KnowledgeMap';
import { EvidenceLevelBadge } from './EvidenceLevelBadge';
import { ArchivalSourceImageViewer } from './ArchivalSourceImageViewer';
import { AIVisualizationViewer } from './AIVisualizationViewer';
import { RelatedBooksList } from './RelatedBooksList';
import { ScholarsList } from './ScholarsList';
import { ThirukkuralAnswerView } from './ThirukkuralAnswerView';
import { TextSelectionToolbar } from './TextSelectionToolbar';
import { SCHOLARS_DATABASE } from '../data/mockInvestigations';
import { 
  ShieldCheck, AlertTriangle, Compass, Landmark, BookOpen, 
  ExternalLink, FileText, ArrowRight, Bookmark, Share2, 
  Check, Info, Sparkles, Newspaper, Image as ImageIcon,
  Clock, Eye, ZoomIn, Download, Layers, Calendar, Copy,
  ChevronRight, MessageSquare
} from 'lucide-react';

interface ResearchBriefViewProps {
  brief: ResearchBrief;
  onOpenLens: (selection: LensSelection) => void;
  onInitiateRelatedQuery: (query: string) => void;
  onToggleSaveEvidence: (briefId: string) => void;
  isSaved: boolean;
  language: 'ta' | 'en';
}

export const ResearchBriefView: React.FC<ResearchBriefViewProps> = ({
  brief,
  onOpenLens,
  onInitiateRelatedQuery,
  onToggleSaveEvidence,
  isSaved,
  language
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [inspectingScan, setInspectingScan] = useState<ArchivalScanItem | null>(null);
  const [explorationDepth, setExplorationDepth] = useState<'quick' | 'explore' | 'deep'>('explore');
  const [followUpInput, setFollowUpInput] = useState<string>('');
  const isEn = language === 'en';

  const handleCopy = (key: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleToolbarAction = (action: 'ask' | 'explain' | 'source' | 'translate' | 'deeper', selectedText: string) => {
    let query = '';
    if (action === 'ask') {
      query = isEn ? `Explain further: "${selectedText}"` : `"${selectedText}" - இதன் வரலாற்றுப் பின்னணி என்ன?`;
    } else if (action === 'explain') {
      query = isEn ? `Explain context of: "${selectedText}"` : `"${selectedText}" என்ற தொடரின் சூழல்சார் விளக்கம்`;
    } else if (action === 'source') {
      query = isEn ? `What is the primary source evidence for: "${selectedText}"?` : `"${selectedText}" என்பதற்கான முதன்மைச் சான்றுகள் யாவை?`;
    } else if (action === 'translate') {
      query = isEn ? `Translate and contextualize: "${selectedText}"` : `"${selectedText}" என்பதன் சொல்லாய்வு விளக்கம்`;
    } else if (action === 'deeper') {
      query = isEn ? `Deep comparative research on: "${selectedText}"` : `"${selectedText}" பற்றிய ஆழமான வரலாற்று ஆய்வு`;
    }

    if (onInitiateRelatedQuery) {
      onInitiateRelatedQuery(query);
    } else {
      setFollowUpInput(query);
    }
  };

  const handleSelectScholarByName = (scholarName: string) => {
    const found = Object.values(SCHOLARS_DATABASE).find(
      s => s.fullName.includes(scholarName) || s.knownAs.includes(scholarName)
    );
    if (found) {
      onOpenLens({
        type: 'scholar',
        id: found.id,
        title: found.fullName,
        data: found
      });
    } else {
      onOpenLens({
        type: 'scholar',
        id: 'generic-scholar',
        title: scholarName,
        data: {
          fullName: scholarName,
          knownAs: scholarName,
          profession: 'Historian / Epigraphist',
          field: 'South Asian & Tamil Studies',
          institution: 'Scholarly Publication Record',
          region: 'Tamil Nadu & International',
          birthDeath: 'Documented in Historiographical Record',
          careerTimeline: ['Author of published historical treatises'],
          keyPublications: ['Published monograph cited in research brief'],
          researchContribution: 'Contributed to scholarly analysis of ancient and medieval Tamil records.',
          relevanceToQuestion: 'Directly cited in the comparative historiographical interpretation.',
          photoStatus: 'NONE',
          photoNote: 'No verified public-domain photograph available.'
        }
      });
    }
  };

  // Dedicated Answer-First Experience for Thirukkural
  if (brief.thirukkural) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        <ThirukkuralAnswerView
          questionText={brief.query}
          kural={brief.thirukkural}
          archivalScans={brief.archivalScans}
          aiIllustrations={brief.aiIllustrations}
          onOpenLens={onOpenLens}
          onToggleSave={() => onToggleSaveEvidence(brief.id)}
          isSaved={isSaved}
          onInspectScan={(scan) => setInspectingScan(scan)}
          onFollowUpQuery={(q) => onInitiateRelatedQuery(q)}
          language={language}
        />

        {inspectingScan && (
          <ArchivalSourceImageViewer
            item={inspectingScan}
            isOpen={true}
            onClose={() => setInspectingScan(null)}
          />
        )}
      </div>
    );
  }

  const fullAnswerText = `கேள்வி: ${brief.query}

பதில்: ${brief.directAnswer?.tamilExplanation || brief.keyFinding}

English: ${brief.directAnswer?.englishExplanation || ''}

வரலாற்றுக் காலம்: ${brief.directAnswer?.datesOrPeriod || ''}`;

  return (
    <article ref={containerRef} className="research-answer-document max-w-[760px] mx-auto py-8 sm:py-12 px-3 sm:px-6 space-y-12 font-sans selection:bg-[#8B3A1C]/20">
      {/* Floating Text Selection Toolbar (Section 19) */}
      <TextSelectionToolbar
        containerRef={containerRef}
        onAction={handleToolbarAction}
        language={language}
      />

      {/* TOP HEADER & META BAR (Section 2) */}
      <header className="space-y-3 pb-6 border-b border-[#E7E2D8] dark:border-[#27323C]">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-xs">
            <span className="font-mono uppercase font-bold text-[10px] tracking-wider text-[#8B3A1C] dark:text-[#E07A5F] bg-[#8B3A1C]/10 px-2 py-0.5 rounded">
              {isEn ? 'RESEARCH DOSSIER' : 'ஆய்வு ஆவணம்'}
            </span>
            <span className="text-neutral-400">•</span>
            <span className="font-mono text-neutral-500 text-[11px]">{brief.category}</span>
            <span className="text-neutral-400">•</span>
            <span className="font-mono text-[10px] uppercase font-semibold text-emerald-800 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-300 dark:border-emerald-800">
              {isEn ? 'DIRECTLY DOCUMENTED' : 'சான்றுகளுடன் நிறுவப்பட்டது'}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onToggleSaveEvidence(brief.id)}
              className={`px-3 py-1 rounded-lg text-xs font-mono font-medium border flex items-center gap-1.5 transition-colors cursor-pointer shadow-2xs ${
                isSaved
                  ? 'bg-[#8B3A1C] text-white border-[#8B3A1C]'
                  : 'bg-white dark:bg-[#1C242C] border-[#E7E2D8] dark:border-[#354350] text-[#57534E] dark:text-[#CBD5E1] hover:border-[#8B3A1C]'
              }`}
            >
              <Bookmark className="w-3.5 h-3.5" />
              <span>
                {isSaved 
                  ? (isEn ? 'Saved' : 'சேமிக்கப்பட்டது') 
                  : (isEn ? 'Save' : 'சேமிக்க')}
              </span>
            </button>

            <button
              onClick={() => handleCopy('share', window.location.href)}
              className="p-1.5 rounded-lg text-xs font-medium border border-[#E7E2D8] dark:border-[#354350] bg-white dark:bg-[#1C242C] text-[#57534E] dark:text-[#CBD5E1] hover:border-[#8B3A1C] transition-colors cursor-pointer"
              title={isEn ? "Copy link" : "பகிர்க"}
            >
              {copiedKey === 'share' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Share2 className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        <h1 className="text-xl sm:text-2xl font-serif font-bold text-[#1C1917] dark:text-[#F8FAFC] tracking-tight leading-snug">
          “{brief.query}”
        </h1>
        {brief.tamilQuery && brief.tamilQuery !== brief.query && (
          <h2 className="text-sm sm:text-base font-serif text-[#8B3A1C] dark:text-[#E07A5F]">
            {brief.tamilQuery}
          </h2>
        )}
      </header>

      {/* ========================================================================= */}
      {/* DIRECT ANSWER LAYER (Section 4 & 5) */}
      {/* ========================================================================= */}
      <section className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="text-xs font-mono uppercase tracking-widest text-[#8B3A1C] dark:text-[#E07A5F] font-bold flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#8B3A1C] dark:bg-[#E07A5F]" />
            <span>{isEn ? 'Direct Answer' : 'உங்கள் கேள்விக்கான பதில்'}</span>
          </div>
          {brief.directAnswer?.datesOrPeriod && (
            <span className="text-[11px] font-mono text-[#78716C] dark:text-[#94A3B8]">
              {brief.directAnswer.datesOrPeriod}
            </span>
          )}
        </div>

        {/* Immediate Direct Answer Affirmation */}
        <div className="space-y-3">
          <div className="text-2xl sm:text-3xl font-serif font-bold text-[#8B3A1C] dark:text-[#E07A5F]">
            {isEn ? 'Directly Documented in Primary Evidence.' : 'இதற்கு நேரடி வரலாற்று ஆதாரம் உள்ளது.'}
          </div>

          <p className="text-base sm:text-lg font-serif text-[#1C1917] dark:text-[#F8FAFC] leading-relaxed">
            {brief.directAnswer?.tamilExplanation || brief.keyFinding}{' '}
            <button
              onClick={() => {
                if (brief.archivalScans && brief.archivalScans.length > 0) {
                  onOpenLens({
                    type: 'source',
                    id: brief.archivalScans[0].id,
                    title: brief.archivalScans[0].title,
                    data: brief.archivalScans[0]
                  });
                }
              }}
              className="inline-flex items-center text-xs font-mono text-[#8B3A1C] dark:text-[#E07A5F] underline hover:opacity-80 ml-1 cursor-pointer font-semibold"
              title="Click to open Source in Context Inspector"
            >
              [Source 01]
            </button>
          </p>

          {brief.directAnswer?.englishExplanation && (
            <div className="p-4 rounded-xl bg-white dark:bg-[#161D24] border border-[#E7E2D8] dark:border-[#27323C] space-y-1">
              <span className="text-[10px] font-mono uppercase font-bold text-[#78716C] dark:text-[#94A3B8] block">
                English Translation & Scholarly Context
              </span>
              <p className="text-sm font-serif italic text-[#44403C] dark:text-[#CBD5E1] leading-relaxed">
                “{brief.directAnswer.englishExplanation}”
              </p>
            </div>
          )}

          {/* Copy complete answer row */}
          <div className="pt-2 flex items-center justify-end gap-2">
            <button
              onClick={() => handleCopy('direct', brief.directAnswer?.tamilExplanation || brief.keyFinding)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#E7E2D8] dark:border-[#334155] bg-white dark:bg-[#1E252D] text-xs font-medium text-[#57534E] dark:text-[#CBD5E1] hover:border-[#8B3A1C] hover:text-[#8B3A1C] transition-colors cursor-pointer shadow-xs"
            >
              {copiedKey === 'direct' ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="text-emerald-600 font-bold">{isEn ? 'Copied' : 'பிரதியெடுக்கப்பட்டது'}</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>{isEn ? 'Copy explanation' : 'விளக்கத்தைப் பிரதியெடு'}</span>
                </>
              )}
            </button>

            <button
              onClick={() => handleCopy('all', fullAnswerText)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#E7E2D8] dark:border-[#334155] bg-white dark:bg-[#1E252D] text-xs font-medium text-[#57534E] dark:text-[#CBD5E1] hover:border-[#8B3A1C] hover:text-[#8B3A1C] transition-colors cursor-pointer shadow-xs"
            >
              {copiedKey === 'all' ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="text-emerald-600 font-bold">{isEn ? 'Full Answer Copied' : 'முழுவதும் பிரதியெடுக்கப்பட்டது'}</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>{isEn ? 'Copy complete answer' : 'முழு பதிலை பிரதியெடு'}</span>
                </>
              )}
            </button>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* ANSWER END — VISUAL STOPPING BOUNDARY (Section 6 & 28) */}
      {/* ========================================================================= */}
      <div className="relative my-8">
        <div className="absolute inset-0 flex items-center" aria-hidden="true">
          <div className="w-full border-t border-[#D6CEBE] dark:border-[#2D3843]" />
        </div>
        <div className="relative flex justify-center">
          <span className="px-4 py-1 rounded-full bg-[#FAF8F5] dark:bg-[#12161A] text-xs font-mono uppercase tracking-widest text-[#8B3A1C] dark:text-[#E07A5F] font-bold border border-[#E7E2D8] dark:border-[#27323C] shadow-xs">
            {isEn ? 'Sources & Supporting Evidence' : 'இதன் ஆதாரம்'}
          </span>
        </div>
      </div>

      <div className="text-center -mt-6">
        <p className="text-[11px] font-mono text-[#78716C] dark:text-[#94A3B8]">
          {isEn 
            ? 'The primary answer has concluded. Below is supporting archival evidence, inscriptions, and scholarly debates.'
            : 'முதன்மைப் பதில் முடிவடைந்தது. கீழே உள்ளவை இக்கருத்தை நிறுவும் வரலாற்று, கல்வெட்டு மற்றும் தொல்லியல் சான்றுகள்.'}
        </p>
      </div>

      {/* ========================================================================= */}
      {/* PRIMARY EVIDENCE (INSCRIPTIONS, MANUSCRIPTS & ARCHAEOLOGY) */}
      {/* ========================================================================= */}
      {brief.archivalScans && brief.archivalScans.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-mono uppercase tracking-wider text-[#1C1917] dark:text-[#F8FAFC] font-bold">
              {isEn ? 'Primary Sources & Inscription Scans' : 'முதன்மைச் சான்றுகளும் கல்வெட்டுகளும்'}
            </h3>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 font-bold">
              {isEn ? 'PRIMARY EVIDENCE' : 'அசல் சான்று'}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {brief.archivalScans.map((scan) => (
              <div
                key={scan.id}
                onClick={() => {
                  onOpenLens({
                    type: 'source',
                    id: scan.id,
                    title: scan.title,
                    data: scan
                  });
                }}
                className="p-4 rounded-xl bg-white dark:bg-[#161D24] border border-[#E7E2D8] dark:border-[#27323C] hover:border-[#8B3A1C] transition-all cursor-pointer group space-y-2.5 shadow-2xs text-left"
              >
                <div className="flex items-center justify-between text-[10px] font-mono">
                  <span className="font-bold text-[#8B3A1C] dark:text-[#E07A5F]">{scan.script}</span>
                  <span className="text-[#78716C]">{scan.period}</span>
                </div>

                <div className="h-32 rounded-lg bg-neutral-900 overflow-hidden relative flex items-center justify-center">
                  <img
                    src={scan.imageUrl}
                    alt={scan.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white text-xs font-mono gap-1">
                    <ZoomIn className="w-3.5 h-3.5" />
                    <span>{isEn ? 'Inspect in Context Inspector' : 'ஆய்வகத்தில் பார்க்க'}</span>
                  </div>
                </div>

                <div className="space-y-1">
                  <h4 className="text-xs font-serif font-bold text-[#1C1917] dark:text-[#F8FAFC] group-hover:text-[#8B3A1C] leading-snug">
                    {scan.title}
                  </h4>
                  <p className="text-[11px] font-mono text-[#78716C] line-clamp-1">
                    {scan.location} • {scan.repository}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* PRIMARY TEXT EXCERPTS */}
      {brief.primaryTexts && brief.primaryTexts.length > 0 && (
        <section className="space-y-4">
          <h3 className="text-xs font-mono uppercase tracking-wider text-[#1C1917] dark:text-[#F8FAFC] font-bold">
            {isEn ? 'Primary Textual Attestations' : 'இலக்கிய மூலச் சான்றுகள்'}
          </h3>
          <div className="space-y-3">
            {brief.primaryTexts.map((pt) => (
              <div
                key={pt.id}
                className="p-4 sm:p-5 rounded-xl bg-white dark:bg-[#161D24] border border-[#E7E2D8] dark:border-[#27323C] space-y-2.5"
              >
                <div className="flex items-center justify-between text-xs">
                  <span className="font-serif font-bold text-[#8B3A1C] dark:text-[#E07A5F]">{pt.work}</span>
                  <span className="text-[10px] font-mono text-[#78716C]">{pt.period}</span>
                </div>
                <blockquote className="pl-3 border-l-2 border-[#8B3A1C] font-serif text-sm sm:text-base font-bold text-[#1C1917] dark:text-[#F8FAFC] leading-relaxed whitespace-pre-line">
                  {pt.originalTamil}
                </blockquote>
                <p className="text-xs font-serif italic text-[#44403C] dark:text-[#CBD5E1]">
                  “{pt.englishTranslation}”
                </p>
                <div className="text-[10px] font-mono text-[#78716C] pt-1">
                  {isEn ? 'Provenance:' : 'மூலக் குறிப்பு:'} {pt.provenanceNotes}
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* SCHOLARLY DEBATES & INTERPRETATIONS (Section 33) */}
      {brief.scholarlyDebates && brief.scholarlyDebates.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-mono uppercase tracking-wider text-[#1C1917] dark:text-[#F8FAFC] font-bold">
              {isEn ? 'Scholarly Debates & Divergent Interpretations' : 'அறிஞர்களின் வாதங்களும் கருத்து வேறுபாடுகளும்'}
            </h3>
            <span className="text-[10px] font-mono text-[#78716C]">
              {isEn ? 'Historiographical Spectrum' : 'வரலாற்று விவாதம்'}
            </span>
          </div>

          <div className="space-y-3">
            <ScholarlyDebateCard
              debates={brief.scholarlyDebates}
              onSelectScholar={handleSelectScholarByName}
              language={language}
            />
          </div>
        </section>
      )}

      {/* ========================================================================= */}
      {/* CONVERSATIONAL DECISION POINT (Section 15, 37) */}
      {/* ========================================================================= */}
      <section className="p-5 sm:p-6 rounded-2xl bg-[#F5F0E6] dark:bg-[#182026] border border-[#E7E2D8] dark:border-[#2D3843] space-y-4">
        <div className="space-y-1">
          <div className="text-xs font-mono uppercase tracking-wider text-[#8B3A1C] dark:text-[#E07A5F] font-bold">
            {isEn ? 'Want to explore this further?' : 'இந்த விஷயத்தை மேலும் ஆராய விரும்புகிறீர்களா?'}
          </div>
          <p className="text-xs text-[#57534E] dark:text-[#CBD5E1] font-sans">
            {isEn 
              ? 'Choose your research depth. Compare scholars, inspect archaeological records, or launch deep research.'
              : 'நீங்கள் விரும்பும் ஆய்வு ஆழத்தைத் தேர்ந்தெடுக்கவும். மூலச் சான்றுகள், அறிஞர்களின் ஒப்பீடு மற்றும் ஆழமான ஆய்வை அணுகலாம்.'}
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setExplorationDepth('quick')}
            className={`px-3 py-2 rounded-xl text-xs font-mono transition-all cursor-pointer ${
              explorationDepth === 'quick'
                ? 'bg-[#8B3A1C] text-white shadow-xs font-bold'
                : 'bg-white dark:bg-[#1E252D] text-[#57534E] dark:text-[#CBD5E1] border border-[#E7E2D8] dark:border-[#334155] hover:border-[#8B3A1C]'
            }`}
          >
            {isEn ? 'Quick explanation' : 'விரைவு விளக்கம்'}
          </button>

          <button
            onClick={() => setExplorationDepth('explore')}
            className={`px-3 py-2 rounded-xl text-xs font-mono transition-all cursor-pointer ${
              explorationDepth === 'explore'
                ? 'bg-[#8B3A1C] text-white shadow-xs font-bold'
                : 'bg-white dark:bg-[#1E252D] text-[#57534E] dark:text-[#CBD5E1] border border-[#E7E2D8] dark:border-[#334155] hover:border-[#8B3A1C]'
            }`}
          >
            {isEn ? 'Explore the evidence' : 'சான்றுகளை ஆராய'}
          </button>

          <button
            onClick={() => setExplorationDepth('deep')}
            className={`px-3 py-2 rounded-xl text-xs font-mono transition-all cursor-pointer ${
              explorationDepth === 'deep'
                ? 'bg-[#8B3A1C] text-white shadow-xs font-bold'
                : 'bg-white dark:bg-[#1E252D] text-[#57534E] dark:text-[#CBD5E1] border border-[#E7E2D8] dark:border-[#334155] hover:border-[#8B3A1C]'
            }`}
          >
            {isEn ? 'Deep research workspace' : 'ஆழ்ந்த ஆய்வு'}
          </button>

          <button
            onClick={() => {
              if (brief.scholarlyDebates && brief.scholarlyDebates.length > 0) {
                handleSelectScholarByName(brief.scholarlyDebates[0].interpretationA.scholar);
              }
            }}
            className="px-3 py-2 rounded-xl text-xs font-mono bg-white dark:bg-[#1E252D] text-[#57534E] dark:text-[#CBD5E1] border border-[#E7E2D8] dark:border-[#334155] hover:border-[#8B3A1C] transition-all cursor-pointer"
          >
            {isEn ? 'Compare scholars' : 'அறிஞர்களை ஒப்பிட'}
          </button>
        </div>
      </section>

      {/* DEEP RESEARCH WORKSPACE (Section 16) */}
      {explorationDepth === 'deep' && (
        <section className="p-6 rounded-2xl bg-white dark:bg-[#161D24] border border-[#8B3A1C]/30 space-y-6 shadow-sm animate-fadeIn">
          <div className="flex items-center justify-between pb-3 border-b border-[#E7E2D8] dark:border-[#27323C]">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#8B3A1C]" />
              <h3 className="text-sm font-serif font-bold text-[#1C1917] dark:text-[#F8FAFC]">
                {isEn ? 'Deep Research Workspace' : 'ஆழ்ந்த ஆய்வு அரங்கம்'}
              </h3>
            </div>
            <span className="text-[10px] font-mono uppercase bg-[#8B3A1C]/10 text-[#8B3A1C] dark:text-[#E07A5F] px-2 py-0.5 rounded font-bold">
              {isEn ? 'EXPERT HISTORIOGRAPHY' : 'விரிவான ஆய்வு'}
            </span>
          </div>

          <div className="space-y-1">
            <span className="text-[10px] font-mono uppercase text-[#78716C] dark:text-[#94A3B8] font-bold">
              {isEn ? '1. Research Question' : '1. ஆராய்ச்சி வினா'}
            </span>
            <p className="text-xs font-serif text-[#1C1917] dark:text-[#F8FAFC]">
              {brief.query}
            </p>
          </div>

          <div className="space-y-1.5">
            <span className="text-[10px] font-mono uppercase text-emerald-800 dark:text-emerald-400 font-bold">
              {isEn ? '2. What is Established' : '2. நிறுவப்பட்ட சான்றுகள்'}
            </span>
            <ul className="text-xs font-sans text-[#44403C] dark:text-[#CBD5E1] space-y-1 pl-4 list-disc">
              {brief.whatIsEstablished?.map((item, idx) => (
                <li key={idx}>{item}</li>
              )) || (
                <li>{isEn ? 'Primary epigraphy and stratigraphic excavations attest to this historical record.' : 'தொல்லியல் அகழாய்வுகளும் கல்வெட்டுகளும் இதனை உறுதிசெய்கின்றன.'}</li>
              )}
            </ul>
          </div>

          <div className="space-y-1.5 p-4 rounded-xl bg-amber-50/70 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40">
            <span className="text-[10px] font-mono uppercase text-amber-900 dark:text-amber-400 font-bold block">
              {isEn ? '3. Areas of Disagreement & Interpretation' : '3. கருத்து வேறுபாடுகளும் விவாதங்களும்'}
            </span>
            <ul className="text-xs font-serif text-[#292524] dark:text-[#CBD5E1] space-y-1 pl-4 list-disc">
              {brief.whatRemainsDebated?.map((item, idx) => (
                <li key={idx}>{item}</li>
              )) || (
                <li>{isEn ? 'Debates focus on absolute calendar chronology versus relative epigraphic stratigraphy.' : 'முழுமையான நாட்காட்டி ஆண்டுமுறை மற்றும் வரலாற்றுப் பொருண்மை குறித்து விவாதங்கள் தொடர்கின்றன.'}</li>
              )}
            </ul>
          </div>
        </section>
      )}

      {/* HISTORICAL TIMELINE */}
      {brief.timeline && brief.timeline.length > 0 && (
        <section className="space-y-4 pt-6 border-t border-[#E7E2D8] dark:border-[#27323C]">
          <h3 className="text-xs font-mono uppercase tracking-wider text-[#1C1917] dark:text-[#F8FAFC] font-bold">
            {isEn ? 'Historical Chronology' : 'வரலாற்றுக் காலவரிசை'}
          </h3>
          <ResearchTimeline
            timeline={brief.timeline}
            onSelectItem={(item) =>
              onOpenLens({
                type: 'timeline',
                id: item.id,
                title: item.title,
                data: item
              })
            }
            language={language}
          />
        </section>
      )}

      {/* AI VISUALIZATION VIEWER (WITH STRICT EPISTEMIC NOTICE) */}
      {brief.aiIllustrations && brief.aiIllustrations.length > 0 && (
        <section className="space-y-4 pt-6 border-t border-[#E7E2D8] dark:border-[#27323C]">
          <AIVisualizationViewer
            illustrations={brief.aiIllustrations}
            onRequestCustomVisualization={(theme) => onInitiateRelatedQuery(`காட்சி விளக்கம்: ${theme}`)}
            language={language}
          />
        </section>
      )}

      {/* INTELLIGENT NEXT STEPS & RELATED RESEARCH PATHS */}
      {brief.relatedResearch && brief.relatedResearch.length > 0 && (
        <section className="space-y-4 pt-6 border-t border-[#E7E2D8] dark:border-[#27323C]">
          <div className="space-y-1">
            <h3 className="text-xs font-mono uppercase tracking-wider text-[#8B3A1C] dark:text-[#E07A5F] font-bold">
              {isEn ? 'Continue your research · Contextual Paths' : 'தொடர்ந்து ஆராயுங்கள்'}
            </h3>
            <p className="text-xs text-[#78716C] dark:text-[#94A3B8]">
              {isEn ? 'Scholarly inquiry paths related to this dossier:' : 'இத்தலைப்போடு தொடர்புடைய ஆழமான வினாக்கள்:'}
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {brief.relatedResearch.map((rel, idx) => (
              <button
                key={idx}
                onClick={() => {
                  const q = rel.suggestedQuery || (isEn ? rel.topic : rel.tamilTopic) || '';
                  if (onInitiateRelatedQuery) {
                    onInitiateRelatedQuery(q);
                  } else {
                    setFollowUpInput(q);
                  }
                }}
                className="p-3.5 rounded-xl bg-white dark:bg-[#161D24] border border-[#E7E2D8] dark:border-[#27323C] hover:border-[#8B3A1C] text-left transition-all group flex items-start justify-between gap-2 cursor-pointer shadow-2xs"
              >
                <div className="space-y-1">
                  <div className="text-xs font-serif font-bold text-[#1C1917] dark:text-[#F8FAFC] group-hover:text-[#8B3A1C]">
                    {isEn ? rel.topic : rel.tamilTopic}
                  </div>
                  {rel.suggestedQuery && (
                    <div className="text-[11px] font-sans text-[#78716C] dark:text-[#94A3B8] line-clamp-1">
                      {rel.suggestedQuery}
                    </div>
                  )}
                </div>
                <ChevronRight className="w-4 h-4 text-[#A8A29E] group-hover:text-[#8B3A1C] group-hover:translate-x-0.5 shrink-0 mt-0.5 transition-transform" />
              </button>
            ))}
          </div>
        </section>
      )}

      {/* SEAMLESS CONVERSATION TRANSITION / FOLLOW-UP COMPOSER */}
      <section className="pt-4">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (followUpInput.trim() && onInitiateRelatedQuery) {
              onInitiateRelatedQuery(followUpInput.trim());
              setFollowUpInput('');
            }
          }}
          className="p-3 rounded-2xl bg-white dark:bg-[#161D24] border border-[#E7E2D8] dark:border-[#27323C] shadow-sm flex items-center gap-2"
        >
          <MessageSquare className="w-4 h-4 text-[#8B3A1C] ml-2 shrink-0" />
          <input
            type="text"
            value={followUpInput}
            onChange={(e) => setFollowUpInput(e.target.value)}
            placeholder={
              isEn 
                ? 'Ask a follow-up question in context... (e.g., What archaeological excavations corroborate this?)' 
                : 'இக்கேள்வியைத் தொடர்ந்து வினவுக... (எ.கா: இதற்கான தொல்லியல் அகழாய்வுச் சான்றுகள் யாவை?)'
            }
            className="w-full bg-transparent text-sm font-serif text-[#1C1917] dark:text-[#F8FAFC] placeholder:text-[#A8A29E] outline-hidden px-1"
          />
          <button
            type="submit"
            disabled={!followUpInput.trim()}
            className={`px-4 py-2 rounded-xl text-xs font-medium shrink-0 transition-all cursor-pointer ${
              followUpInput.trim()
                ? 'bg-[#8B3A1C] text-white hover:bg-[#732F16] shadow-xs'
                : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-400 cursor-not-allowed'
            }`}
          >
            {isEn ? 'Ask' : 'கேட்க'}
          </button>
        </form>
      </section>

      {/* Inspecting Scan Viewer Modal */}
      {inspectingScan && (
        <ArchivalSourceImageViewer
          item={inspectingScan}
          isOpen={true}
          onClose={() => setInspectingScan(null)}
        />
      )}
    </article>
  );
};
