import React, { useState } from 'react';
import { UserPreferences, ResearchMode, LanguagePreference, ThemePreference, ReadingDensity } from '../types/research';
import { 
  ArrowLeft, Check, Sliders, Globe, ShieldCheck, Palette, 
  Bell, Lock, CreditCard, User, Sparkles, Database, BookOpen 
} from 'lucide-react';

interface SettingsWorkspaceProps {
  preferences: UserPreferences;
  onUpdatePreferences: (newPrefs: Partial<UserPreferences>) => void;
  onBackToResearch: () => void;
  initialTab?: string;
}

export const SettingsWorkspace: React.FC<SettingsWorkspaceProps> = ({
  preferences,
  onUpdatePreferences,
  onBackToResearch,
  initialTab = 'General'
}) => {
  const [activeTab, setActiveTab] = useState<string>(initialTab);
  const [showSavedToast, setShowSavedToast] = useState(false);
  const isEn = preferences.language === 'en';

  const triggerSaved = () => {
    setShowSavedToast(true);
    setTimeout(() => setShowSavedToast(false), 2000);
  };

  const navItems = [
    { id: 'General', label: isEn ? 'General' : 'பொது அமைப்புகள்', icon: Sliders },
    { id: 'Research Preferences', label: isEn ? 'Research Preferences' : 'ஆய்வு முன்னுரிமைகள்', icon: BookOpen },
    { id: 'Language', label: isEn ? 'Language (தமிழ் | English)' : 'மொழி (தமிழ் | English)', icon: Globe },
    { id: 'Evidence Preferences', label: isEn ? 'Evidence Preferences' : 'சான்று முன்னுரிமைகள்', icon: ShieldCheck },
    { id: 'AI Behaviour', label: isEn ? 'AI Epistemology & Ethics' : 'AI நெறிமுறைகள்', icon: Database },
    { id: 'Appearance', label: isEn ? 'Appearance & Themes' : 'தோற்றம் & வண்ணங்கள்', icon: Palette },
    { id: 'Subscription', label: isEn ? 'Subscription & Plans' : 'சந்தா & திட்டங்கள்', icon: CreditCard },
    { id: 'Account', label: isEn ? 'Account Profile' : 'பயனர் கணக்கு', icon: User }
  ];

  const handleUpdate = (updates: Partial<UserPreferences>) => {
    onUpdatePreferences(updates);
    triggerSaved();
  };

  return (
    <div className="h-screen flex flex-col bg-[#F7F3EA] dark:bg-[#121417] text-[#171717] dark:text-[#EDEFEF] transition-colors overflow-hidden">
      {/* Top Header Bar */}
      <header className="h-16 px-6 border-b border-[#E5DFC8] dark:border-[#272C35] bg-[#FAF7F0] dark:bg-[#181B20] flex items-center justify-between shrink-0">
        <div className="flex items-center gap-4">
          <button
            onClick={onBackToResearch}
            className="flex items-center gap-2 text-xs font-mono font-bold uppercase text-neutral-700 dark:text-neutral-300 hover:text-[#A85C43] dark:hover:text-[#D47B62] transition-colors px-3 py-1.5 rounded-lg border border-[#E5DFC8] dark:border-[#363E4B] bg-white dark:bg-[#22262D] cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>{isEn ? 'Back to Research' : 'ஆய்வுக்குத் திரும்பு'}</span>
          </button>

          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#A85C43]" />
            <h1 className="text-base font-serif font-bold tracking-tight text-neutral-900 dark:text-white">
              Tamil AI <span className="font-mono text-xs text-[#9B8060] font-normal">• {isEn ? 'Settings Workspace' : 'அமைப்புகள்'}</span>
            </h1>
          </div>
        </div>

        {/* Saved Indicator */}
        <div className="flex items-center gap-2">
          {showSavedToast && (
            <span className="text-xs font-mono text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-2.5 py-1 rounded border border-emerald-300 dark:border-emerald-800 flex items-center gap-1.5 animate-fade-in">
              <Check className="w-3.5 h-3.5 text-emerald-600" />
              <span>{isEn ? '✓ Saved' : '✓ சேமிக்கப்பட்டது'}</span>
            </span>
          )}
        </div>
      </header>

      {/* Main Settings Content Area */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Settings Navigation */}
        <nav className="w-64 border-r border-[#E5DFC8] dark:border-[#272C35] bg-[#F4EFE6] dark:bg-[#15191E] p-4 overflow-y-auto space-y-1 shrink-0">
          <div className="text-[10px] font-mono uppercase tracking-wider text-neutral-400 mb-2 px-2 font-bold">
            {isEn ? 'WORKSPACE CONFIGURATION' : 'அமைப்புகள் பட்டியல்'}
          </div>
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full text-left px-3 py-2.5 rounded-lg text-xs font-medium flex items-center gap-2.5 transition-all cursor-pointer ${
                  isActive
                    ? 'bg-[#A85C43] text-white font-semibold shadow-xs'
                    : 'text-neutral-700 dark:text-neutral-300 hover:bg-white/60 dark:hover:bg-[#20272E]'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Right Settings Body */}
        <main className="flex-1 overflow-y-auto p-8 max-w-4xl">
          {/* 1. GENERAL TAB */}
          {activeTab === 'General' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-serif font-bold text-neutral-900 dark:text-white">General Settings</h2>
                <p className="text-xs text-neutral-500 mt-1">
                  Manage core research session defaults, caching, and export preferences.
                </p>
              </div>

              <div className="p-5 rounded-xl bg-white dark:bg-[#181B20] border border-[#E5DFC8] dark:border-[#272C35] space-y-4 text-xs">
                <div className="flex items-center justify-between pb-3 border-b border-[#E5DFC8]/60 dark:border-[#272C35]">
                  <div>
                    <div className="font-semibold text-neutral-900 dark:text-white">Default Research Mode</div>
                    <div className="text-neutral-500 text-[11px]">Choose starting depth for new queries.</div>
                  </div>
                  <select
                    value={preferences.defaultMode}
                    onChange={(e) => handleUpdate({ defaultMode: e.target.value as ResearchMode })}
                    className="p-1.5 rounded border border-[#E5DFC8] dark:border-[#363E4B] bg-[#FAF7F0] dark:bg-[#22262D] font-mono text-xs"
                  >
                    <option value="quick">Quick Discovery</option>
                    <option value="research">Research (Standard)</option>
                    <option value="deep">Deep Research</option>
                  </select>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-semibold text-neutral-900 dark:text-white">Automatic Citation Anchoring</div>
                    <div className="text-neutral-500 text-[11px]">Instantly open Evidence Lens when clicking references.</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={true}
                    readOnly
                    className="w-4 h-4 accent-[#A85C43]"
                  />
                </div>
              </div>
            </div>
          )}

          {/* 2. RESEARCH PREFERENCES TAB */}
          {activeTab === 'Research Preferences' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-serif font-bold text-neutral-900 dark:text-white">Research Preferences</h2>
                <p className="text-xs text-neutral-500 mt-1">
                  Configure primary corpus priorities, archaeological anchoring, and manuscript inclusion.
                </p>
              </div>

              <div className="p-5 rounded-xl bg-white dark:bg-[#181B20] border border-[#E5DFC8] dark:border-[#272C35] space-y-3.5 text-xs">
                {[
                  { key: 'prioritizePrimaryText', title: 'Prioritize Primary Ancient Texts over Secondary Summaries', desc: 'Ensures original Tamil poetry or inscription precedes interpretation.' },
                  { key: 'requireArchaeology', title: 'Require Material Archaeological Grounding where Applicable', desc: 'Cross-examine textual references against excavation reports and pottery data.' },
                  { key: 'showScholarlyDebates', title: 'Display Scholarly Disagreements (Interpretation A vs B)', desc: 'Never hide historical disputes regarding chronology or identification.' },
                  { key: 'showUncertaintyBadges', title: 'Explicit Uncertainty Badges (No Fabricated Certainty)', desc: 'Display "UNCERTAIN" and "DEBATED" statuses prominently.' },
                  { key: 'showProvenance', title: 'Show Detailed Manuscript Provenance & Repository Data', desc: 'Display palm-leaf bundle IDs, editors, and critical recensions.' },
                  { key: 'showLexicalBreakdown', title: 'Include Lexical Glossaries for Classical Tamil Terms', desc: 'Break down archaic vocabulary term by term in verses.' },
                  { key: 'allowAIIllustrations', title: 'Allow Historical AI Illustrations with Explicit Disclaimers', desc: 'Show conjectural visuals clearly stamped as non-archaeological.' }
                ].map((item) => (
                  <label
                    key={item.key}
                    className="flex items-start justify-between gap-4 p-2 rounded hover:bg-[#FAF7F0] dark:hover:bg-[#22262D] cursor-pointer transition-colors"
                  >
                    <div>
                      <div className="font-semibold text-neutral-900 dark:text-white">{item.title}</div>
                      <div className="text-neutral-500 text-[11px]">{item.desc}</div>
                    </div>
                    <input
                      type="checkbox"
                      checked={(preferences.evidencePreferences as any)[item.key]}
                      onChange={(e) => {
                        handleUpdate({
                          evidencePreferences: {
                            ...preferences.evidencePreferences,
                            [item.key]: e.target.checked
                          }
                        });
                      }}
                      className="w-4 h-4 accent-[#A85C43] shrink-0 mt-1"
                    />
                  </label>
                ))}
              </div>
            </div>
          )}

          {/* 3. LANGUAGE TAB — STRICTLY TWO LANGUAGES: தமிழ் | English */}
          {activeTab === 'Language' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-serif font-bold text-neutral-900 dark:text-white">
                  {preferences.language === 'en' ? 'Language Selection (மொழி தேர்வு)' : 'மொழி தேர்வு (Language Selection)'}
                </h2>
                <p className="text-xs text-neutral-500 mt-1">
                  {preferences.language === 'en' 
                    ? 'Select the primary workspace language. Tamil AI provides a strict two-language system: தமிழ் and English.' 
                    : 'பயன்பாட்டு இடைமுகம் மற்றும் விளக்கங்களுக்கான மொழி. தமிழ் AI இரு மொழிக் கட்டமைப்பை மட்டுமே ஆதரிக்கிறது: தமிழ் மற்றும் English.'}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Tamil Mode */}
                <div
                  onClick={() => handleUpdate({ language: 'ta' })}
                  className={`p-5 rounded-xl border-2 text-left cursor-pointer transition-all ${
                    preferences.language === 'ta'
                      ? 'border-[#8B3A1C] dark:border-[#E07A5F] bg-white dark:bg-[#1E252D] shadow-md ring-2 ring-[#8B3A1C]/20'
                      : 'border-[#E5DFC8] dark:border-[#272C35] bg-white/70 dark:bg-[#181B20]/60 hover:border-[#8B3A1C]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-lg font-tamil font-bold text-neutral-900 dark:text-white">
                      தமிழ்
                    </span>
                    {preferences.language === 'ta' && (
                      <span className="w-5 h-5 rounded-full bg-[#8B3A1C] text-white flex items-center justify-center text-xs">✓</span>
                    )}
                  </div>
                  <div className="text-xs font-semibold text-[#8B3A1C] dark:text-[#E07A5F] mb-1">
                    Tamil Mode (முழுமையான தமிழ் இடைமுகம்)
                  </div>
                  <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed font-tamil">
                    பயன்பாட்டு இடைமுகம், விளக்கங்கள், வரலாற்றுப் பின்னணி மற்றும் பதில்கள் அனைத்தும் தூய நவீன தமிழில் வழங்கப்படும்.
                  </p>
                </div>

                {/* English Mode */}
                <div
                  onClick={() => handleUpdate({ language: 'en' })}
                  className={`p-5 rounded-xl border-2 text-left cursor-pointer transition-all ${
                    preferences.language === 'en'
                      ? 'border-[#8B3A1C] dark:border-[#E07A5F] bg-white dark:bg-[#1E252D] shadow-md ring-2 ring-[#8B3A1C]/20'
                      : 'border-[#E5DFC8] dark:border-[#272C35] bg-white/70 dark:bg-[#181B20]/60 hover:border-[#8B3A1C]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-lg font-serif font-bold text-neutral-900 dark:text-white">
                      English
                    </span>
                    {preferences.language === 'en' && (
                      <span className="w-5 h-5 rounded-full bg-[#8B3A1C] text-white flex items-center justify-center text-xs">✓</span>
                    )}
                  </div>
                  <div className="text-xs font-semibold text-[#8B3A1C] dark:text-[#E07A5F] mb-1">
                    English Mode (Scholarly English Workspace)
                  </div>
                  <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
                    Interface, academic explanations, and answers presented in elegant English while preserving original Tamil literature passages.
                  </p>
                </div>
              </div>

              {/* Strict Language Policy Notice */}
              <div className="p-4 rounded-xl bg-[#FAF7F0] dark:bg-[#151D23] border border-[#E5DFC8] dark:border-[#272C35] text-xs space-y-1">
                <div className="font-mono text-[11px] font-bold text-[#8B3A1C] dark:text-[#E07A5F] uppercase">
                  {preferences.language === 'en' ? 'Two Languages Principle' : 'இரு மொழிக் கொள்கை'}
                </div>
                <p className="text-neutral-600 dark:text-neutral-400 leading-relaxed">
                  {preferences.language === 'en'
                    ? 'Tamil AI adheres to a strict two-language experience: தமிழ் | English. No transliteration slang (Tanglish) or non-Tamil regional languages.'
                    : 'தமிழ் AI இரு மொழிக் கொள்கையைக் கடைப்பிடிக்கிறது: தமிழ் | English. தங்கிலீஷ் அல்லது பிற பிராந்திய மொழிக் கலப்பின்றி இயங்குகிறது.'}
                </p>
              </div>
            </div>
          )}

          {/* 4. APPEARANCE TAB */}
          {activeTab === 'Appearance' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-serif font-bold text-neutral-900 dark:text-white">Appearance & Theme</h2>
                <p className="text-xs text-neutral-500 mt-1">
                  Tailor editorial contrast, typography size, and reading density.
                </p>
              </div>

              {/* Theme Palettes */}
              <div className="space-y-3">
                <div className="text-xs font-mono uppercase text-neutral-400 font-semibold">Theme Palette</div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {[
                    { id: 'ivory', name: 'Warm Ivory Archive', bg: 'bg-[#F7F3EA]', text: 'text-[#171717]', border: 'border-[#A85C43]' },
                    { id: 'ink', name: 'Ink Blue Archive', bg: 'bg-[#1E2830]', text: 'text-[#F0F4F8]', border: 'border-[#354653]' },
                    { id: 'night', name: 'Night Epigraphy', bg: 'bg-[#121417]', text: 'text-[#EDEFEF]', border: 'border-[#363E4B]' }
                  ].map((th) => (
                    <div
                      key={th.id}
                      onClick={() => handleUpdate({ theme: th.id as ThemePreference })}
                      className={`p-4 rounded-xl border cursor-pointer transition-all ${th.bg} ${th.text} ${
                        preferences.theme === th.id ? 'ring-2 ring-[#A85C43]' : 'border-[#E5DFC8] opacity-80'
                      }`}
                    >
                      <div className="text-xs font-bold font-mono">{th.name}</div>
                      <div className="text-[11px] opacity-75 mt-1">Curated scholarly palette</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Reading Density */}
              <div className="p-5 rounded-xl bg-white dark:bg-[#181B20] border border-[#E5DFC8] dark:border-[#272C35] space-y-4 text-xs">
                <div>
                  <div className="font-semibold text-neutral-900 dark:text-white mb-1">Reading Density</div>
                  <div className="grid grid-cols-3 gap-2">
                    {(['relaxed', 'balanced', 'compact'] as ReadingDensity[]).map((d) => (
                      <button
                        key={d}
                        onClick={() => handleUpdate({ readingDensity: d })}
                        className={`py-2 rounded border font-mono capitalize transition-all ${
                          preferences.readingDensity === d
                            ? 'bg-[#A85C43] text-white border-[#A85C43]'
                            : 'bg-[#FAF7F0] dark:bg-[#22262D] border-[#E5DFC8] dark:border-[#363E4B] text-neutral-700 dark:text-neutral-300'
                        }`}
                      >
                        {d}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="pt-3 border-t border-[#E5DFC8]/60 dark:border-[#272C35]">
                  <div className="font-semibold text-neutral-900 dark:text-white mb-1">Tamil Text Font Size</div>
                  <div className="grid grid-cols-3 gap-2">
                    {(['normal', 'medium', 'large'] as const).map((s) => (
                      <button
                        key={s}
                        onClick={() => handleUpdate({ tamilTextSize: s })}
                        className={`py-2 rounded border font-mono capitalize transition-all ${
                          preferences.tamilTextSize === s
                            ? 'bg-[#9B8060] text-white border-[#9B8060]'
                            : 'bg-[#FAF7F0] dark:bg-[#22262D] border-[#E5DFC8] dark:border-[#363E4B] text-neutral-700 dark:text-neutral-300'
                        }`}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 5. AI EPISTEMOLOGY TAB (Section 2 & 21) */}
          {activeTab === 'AI Behaviour' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-serif font-bold text-neutral-900 dark:text-white">AI Epistemology & Ethics</h2>
                <p className="text-xs text-neutral-500 mt-1">
                  Tamil Arivagam strictly enforces evidence before certainty.
                </p>
              </div>

              <div className="p-5 rounded-xl bg-white dark:bg-[#181B20] border border-[#E5DFC8] dark:border-[#272C35] space-y-4 text-xs">
                <div className="p-3.5 rounded-lg bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-200 space-y-1">
                  <div className="font-bold uppercase font-mono text-[10px]">
                    Non-Negotiable Guardrails
                  </div>
                  <p className="text-[11px] leading-relaxed">
                    1. Never manufacture certainty. Fake confidence percentages (e.g. "92% confident") are permanently banned.<br />
                    2. Never equate an ancient term directly with a modern community without unbroken documented evidence.<br />
                    3. If direct evidence is missing, state clearly: "No direct reference to the modern terminology was identified in the current research collection."
                  </p>
                </div>

                <div className="space-y-2">
                  <div className="font-semibold text-neutral-900 dark:text-white">Hallucination Mitigation Protocol</div>
                  <p className="text-neutral-600 dark:text-neutral-400 text-[11px] leading-relaxed">
                    AI synthesis is bounded strictly by the indexed corpus of Sangam poetry, epigraphical surveys, and Archaeological Survey of India excavation reports.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* 6. SUBSCRIPTION TAB (Section 45) */}
          {activeTab === 'Subscription' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-serif font-bold text-neutral-900 dark:text-white">Plans & Subscriptions</h2>
                <p className="text-xs text-neutral-500 mt-1">
                  Illustrative plans for individual researchers, academic scholars, and cultural institutions.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                {/* Free Plan */}
                <div className="p-5 rounded-xl bg-white dark:bg-[#181B20] border-2 border-[#A85C43] space-y-3 relative">
                  <span className="text-[10px] font-mono uppercase bg-[#A85C43] text-white px-2 py-0.5 rounded absolute -top-2.5 left-4 font-bold">
                    CURRENT PLAN
                  </span>
                  <div className="font-serif font-bold text-base text-neutral-900 dark:text-white mt-1">
                    Free Plan
                  </div>
                  <div className="text-2xl font-mono font-bold text-neutral-900 dark:text-white">
                    ₹0 <span className="text-xs font-normal text-neutral-500">/ forever</span>
                  </div>
                  <ul className="space-y-1.5 text-neutral-600 dark:text-neutral-400 pt-2 border-t border-neutral-100 dark:border-neutral-800">
                    <li>✓ Basic research queries</li>
                    <li>✓ Core Sangam literature corpus</li>
                    <li>✓ Primary text translation tabs</li>
                    <li>✓ Standard Evidence Lens</li>
                  </ul>
                </div>

                {/* Plus Plan */}
                <div className="p-5 rounded-xl bg-white dark:bg-[#181B20] border border-[#E5DFC8] dark:border-[#272C35] space-y-3">
                  <div className="font-serif font-bold text-base text-neutral-900 dark:text-white">
                    Plus / Researcher
                  </div>
                  <div className="text-2xl font-mono font-bold text-[#A85C43]">
                    ₹249 <span className="text-xs font-normal text-neutral-500">/ mo (illustrative)</span>
                  </div>
                  <ul className="space-y-1.5 text-neutral-600 dark:text-neutral-400 pt-2 border-t border-neutral-100 dark:border-neutral-800">
                    <li>✓ Unlimited Deep Research</li>
                    <li>✓ Full Epigraphical Corpus (12,000+ records)</li>
                    <li>✓ Radiocarbon AMS dataset access</li>
                    <li>✓ Export research briefs as Markdown</li>
                  </ul>
                  <button className="w-full py-2 rounded bg-[#A85C43] text-white font-semibold mt-2">
                    Upgrade to Plus
                  </button>
                </div>

                {/* Institutional Plan */}
                <div className="p-5 rounded-xl bg-white dark:bg-[#181B20] border border-[#E5DFC8] dark:border-[#272C35] space-y-3">
                  <div className="font-serif font-bold text-base text-neutral-900 dark:text-white">
                    Institutional
                  </div>
                  <div className="text-2xl font-mono font-bold text-[#354653] dark:text-[#B0C4DE]">
                    Custom <span className="text-xs font-normal text-neutral-500">/ university</span>
                  </div>
                  <ul className="space-y-1.5 text-neutral-600 dark:text-neutral-400 pt-2 border-t border-neutral-100 dark:border-neutral-800">
                    <li>✓ Universities & Museums</li>
                    <li>✓ Palm-leaf manuscript OCR</li>
                    <li>✓ Multi-seat collaborative archive</li>
                    <li>✓ Dedicated historical dataset indexing</li>
                  </ul>
                  <button className="w-full py-2 rounded bg-[#354653] text-white font-semibold mt-2">
                    Contact Institutional Team
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* 7. ACCOUNT PROFILE TAB */}
          {activeTab === 'Account' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-serif font-bold text-neutral-900 dark:text-white">Account Profile</h2>
                <p className="text-xs text-neutral-500 mt-1">
                  Manage your research credentials and investigator session.
                </p>
              </div>

              <div className="p-5 rounded-xl bg-white dark:bg-[#181B20] border border-[#E5DFC8] dark:border-[#272C35] space-y-4 text-xs">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-full bg-[#354653] text-white flex items-center justify-center font-serif text-xl font-bold">
                    S
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-neutral-900 dark:text-white">Sridhar</h3>
                    <div className="text-neutral-500 font-mono text-[11px]">srimdga@gmail.com</div>
                    <div className="text-[#A85C43] font-mono text-[10px] font-semibold mt-0.5">Free Academic Researcher Plan</div>
                  </div>
                </div>

                <div className="pt-4 border-t border-[#E5DFC8]/60 dark:border-[#272C35] grid grid-cols-2 gap-3">
                  <div className="p-3 rounded bg-[#FAF7F0] dark:bg-[#22262D]">
                    <span className="text-neutral-400 uppercase text-[10px] font-mono block">Investigations Conducted</span>
                    <span className="text-base font-serif font-bold text-neutral-900 dark:text-white">5 Active Briefs</span>
                  </div>
                  <div className="p-3 rounded bg-[#FAF7F0] dark:bg-[#22262D]">
                    <span className="text-neutral-400 uppercase text-[10px] font-mono block">Corpus Access</span>
                    <span className="text-base font-serif font-bold text-neutral-900 dark:text-white">Tamil Classics & Archaeology</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};
