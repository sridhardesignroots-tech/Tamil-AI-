import React from 'react';
import { COLLECTIONS_INDEX } from '../data/mockInvestigations';
import { X, Scroll, BookOpen, Compass, FileText, Users, Droplets, ArrowRight } from 'lucide-react';

interface CollectionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectCollectionTopic: (topicQuery: string) => void;
  language?: 'ta' | 'en';
}

export const CollectionsModal: React.FC<CollectionsModalProps> = ({
  isOpen,
  onClose,
  onSelectCollectionTopic,
  language = 'ta'
}) => {
  if (!isOpen) return null;
  const isEn = language === 'en';

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white dark:bg-[#181B20] border border-[#E5DFC8] dark:border-[#272C35] rounded-2xl max-w-2xl w-full max-h-[85vh] flex flex-col overflow-hidden shadow-2xl animate-fade-in">
        <div className="p-5 border-b border-[#E5DFC8] dark:border-[#272C35] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#A85C43]/10 text-[#A85C43] flex items-center justify-center">
              <Scroll className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-serif font-bold text-neutral-900 dark:text-white">
                {isEn ? 'Indexed Research Corpus & Archives' : 'சரிபார்க்கப்பட்ட மூலத் தரவுத் தொகுப்புகள்'}
              </h2>
              <div className="text-[10px] font-mono text-[#9B8060] uppercase tracking-wider">
                {isEn ? 'TAMIL ARIVAGAM ARCHIVAL HOLDINGS' : 'தமிழ் அறிவகம் ஆவணக் காப்பகம்'}
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto space-y-4">
          <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed font-sans">
            {isEn 
              ? 'Tamil AI anchors all research synthesis directly in verified critical editions, archaeological surveys, and epigraphical databases. Select a collection below to initiate targeted research:'
              : 'தமிழ் AI அனைத்து வரலாற்று ஆய்வுகளையும் பதிப்பிக்கப்பட்ட மூல நூல்கள், தொல்லியல் அகழாய்வு அறிக்கைகள் மற்றும் கல்வெட்டுத் தரவுகளோடு மட்டுமே இணைக்கிறது. விரிவான ஆய்வைத் தொடங்க ஒரு தொகுப்பைத் தேர்ந்தெடுக்கவும்:'}
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {COLLECTIONS_INDEX.map((col) => (
              <div
                key={col.id}
                onClick={() => {
                  onSelectCollectionTopic(isEn ? `Investigate key findings from the ${col.name}` : `${col.tamilName} பற்றிய முதன்மைத் தரவுகள்`);
                  onClose();
                }}
                className="p-3.5 rounded-xl border border-[#E5DFC8] dark:border-[#272C35] bg-[#FAF7F0] dark:bg-[#1E242B] hover:border-[#A85C43] transition-all cursor-pointer group space-y-1.5"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-serif font-bold text-neutral-900 dark:text-white group-hover:text-[#A85C43] transition-colors">
                    {col.name}
                  </span>
                  <ArrowRight className="w-3.5 h-3.5 text-neutral-400 group-hover:text-[#A85C43] group-hover:translate-x-0.5 transition-all" />
                </div>
                <div className="text-xs font-tamil text-[#9B8060]">
                  {col.tamilName}
                </div>
                <div className="text-[10px] font-mono text-neutral-500 pt-1 border-t border-[#E5DFC8]/50 dark:border-[#272C35]">
                  {col.count}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="p-4 bg-[#FAF7F0] dark:bg-[#141B20] border-t border-[#E5DFC8] dark:border-[#272C35] text-[11px] font-mono text-neutral-500 text-center">
          {isEn
            ? 'Continuous digitization pipeline powered by academic epigraphy & archaeology institutes.'
            : 'பல்கலைக்கழகங்கள் மற்றும் தொல்லியல் நிறுவனங்களின் ஆவணத் தரவுகளோடு தொடர்ந்து புதுப்பிக்கப்படுகிறது.'}
        </div>
      </div>
    </div>
  );
};
