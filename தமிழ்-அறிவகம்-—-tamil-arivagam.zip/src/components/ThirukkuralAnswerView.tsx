import React, { useState, useRef } from 'react';
import { ThirukkuralRecord, LensSelection, ArchivalScanItem, AIIllustration, ResearchMode } from '../types/research';
import { TextSelectionToolbar } from './TextSelectionToolbar';
import { 
  BookOpen, ChevronDown, ChevronUp, ExternalLink, Bookmark, 
  Share2, Check, Sparkles, ZoomIn, ZoomOut, Maximize2, Download, 
  RotateCcw, AlertTriangle, ArrowRight, X, Copy, HelpCircle,
  FileText, User, Compass, Layers, CheckCircle2, MessageSquare, ChevronRight
} from 'lucide-react';

interface ThirukkuralAnswerViewProps {
  questionText?: string;
  kural: ThirukkuralRecord;
  archivalScans?: ArchivalScanItem[];
  aiIllustrations?: AIIllustration[];
  onOpenLens: (selection: LensSelection) => void;
  onSelectKural?: (kuralNumber: number) => void;
  onToggleSave?: () => void;
  isSaved?: boolean;
  onInspectScan?: (scan: ArchivalScanItem) => void;
  onFollowUpQuery?: (query: string) => void;
  language?: 'ta' | 'en';
}

export const ThirukkuralAnswerView: React.FC<ThirukkuralAnswerViewProps> = ({
  questionText = 'கடின உழைப்பைப் பற்றி திருக்குறளில் குறள் இருக்கிறதா?',
  kural,
  archivalScans,
  aiIllustrations,
  onOpenLens,
  onSelectKural,
  onToggleSave,
  isSaved = false,
  onInspectScan,
  onFollowUpQuery,
  language = 'ta'
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const isEn = language === 'en';

  // State for Copy actions
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Exploration Depth: 'quick' | 'explore' | 'deep'
  const [explorationDepth, setExplorationDepth] = useState<'quick' | 'explore' | 'deep'>('explore');
  const [showExtendedKurals, setShowExtendedKurals] = useState<boolean>(false);
  const [activeCommentatorTab, setActiveCommentatorTab] = useState<string>('all');

  // Follow-up input state
  const [followUpInput, setFollowUpInput] = useState<string>('');

  // AI Image viewer state
  const [zoomScale, setZoomScale] = useState<number>(1);
  const [isFullScreen, setIsFullScreen] = useState<boolean>(false);
  const [isRegenerating, setIsRegenerating] = useState<boolean>(false);
  const [regenerateNotice, setRegenerateNotice] = useState<string | null>(null);

  const activeIllustration = aiIllustrations && aiIllustrations.length > 0 ? aiIllustrations[0] : null;

  // Copy helper
  const handleCopy = (key: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  // Handle Text Selection Toolbar actions
  const handleToolbarAction = (action: 'ask' | 'explain' | 'source' | 'translate' | 'deeper', selectedText: string) => {
    let query = '';
    if (action === 'ask') {
      query = isEn ? `Explain further: "${selectedText}"` : `"${selectedText}" - இதன் பொருள் என்ன?`;
    } else if (action === 'explain') {
      query = isEn ? `Explain the context of: "${selectedText}"` : `"${selectedText}" என்ற தொடரின் சூழல்சார் விளக்கம் என்ன?`;
    } else if (action === 'source') {
      query = isEn ? `What is the primary source evidence for: "${selectedText}"?` : `"${selectedText}" என்பதற்கான மூலச் சான்றுகள் யாவை?`;
    } else if (action === 'translate') {
      query = isEn ? `Translate and analyze: "${selectedText}"` : `"${selectedText}" என்பதன் சொல்லாய்வு விளக்கம்`;
    } else if (action === 'deeper') {
      query = isEn ? `Deep research into: "${selectedText}"` : `"${selectedText}" பற்றிய ஆழமான ஒப்பீட்டு ஆய்வு`;
    }

    if (onFollowUpQuery) {
      onFollowUpQuery(query);
    } else {
      setFollowUpInput(query);
    }
  };

  // Open Source in Context Inspector (Right panel)
  const handleOpenSourceInLens = (sourceId: string, title: string, passage?: string, commentary?: string) => {
    onOpenLens({
      type: 'source',
      id: sourceId,
      title: title,
      data: {
        id: sourceId,
        title: title,
        sourceType: isEn ? 'PRIMARY MANUSCRIPT & CRITICAL TEXT' : 'அசல் ஓலைச்சுவடி & செம்பதிப்பு',
        period: 'c. 3rd Century BCE – 2nd Century CE',
        location: 'Tamilakam / Saraswathi Mahal Library, Thanjavur & UVS Library',
        language: 'Tamil',
        script: 'Tamil / Tamil-Brahmi classical lineage',
        repository: 'U.V. Swaminatha Iyer Library Critical Manuscripts',
        relevantPassage: passage || `${kural.line1}\n${kural.line2}`,
        translation: kural.englishTranslation,
        whatItEstablishes: isEn 
          ? 'Kural 619 is verified across all extant palm-leaf manuscript lineages and canonical medieval commentaries, establishing that Valluvar placed human exertion and bodily labor above destiny.'
          : 'குறள் 619 அனைத்து மூல ஓலைச்சுவடிகளிலும் உறுதிசெய்யப்பட்டுள்ளது. விதியைக் காட்டிலும் மனிதனின் மெய்வருத்த உழைப்பே முதன்மையானது என்பதை இது ஐயமின்றி நிறுவுகிறது.',
        limitations: isEn
          ? 'Does not provide biographical dates for Thiruvalluvar beyond the classical textual tradition.'
          : 'திருவள்ளுவரின் தனிப்பட்ட வாழ்க்கை வரலாற்றுக் காலத்தை ஓலைச்சுவடி நேரடியாகக் குறிப்பிடவில்லை.',
        pageOrReference: `Thirukkural, Porutpal, Adhikaram 62 (${kural.adhikaram}), Verse 9 (Couplet ${kural.kuralNumber})`
      }
    });
  };

  // Open Scholar in Context Inspector
  const handleOpenScholarInLens = (scholarName: string, role: string, period: string, commentaryText: string) => {
    onOpenLens({
      type: 'scholar',
      id: `scholar-${scholarName}`,
      title: scholarName,
      data: {
        fullName: scholarName,
        knownAs: scholarName,
        profession: role,
        field: 'Classical Tamil Hermeneutics & Philosophy',
        institution: 'Classical Commentary Lineage of Thirukkural',
        birthDeath: period,
        careerTimeline: [`Author of celebrated critical commentary on Thirukkural`],
        keyPublications: [`Thirukkural Urai (${period})`],
        researchContribution: `Defined rigorous grammatical, philosophical, and lexical interpretations of classical Tamil verses.`,
        relevanceToQuestion: isEn
          ? `Interprets Kural 619: "${commentaryText}". Establishes that sincere bodily labor never remains unrewarded even if destiny delays.`
          : `குறள் 619-க்கு உரை வரைந்தவர்: "${commentaryText}". விதியினால் காரியம் நிறைவேறாவிடினும் உடம்பு வருந்திய உழைப்பிற்குரிய கூலி நிச்சயம் கிட்டும் என்பதை உறுதிசெய்கிறார்.`,
        photoStatus: 'NONE',
        photoNote: 'Classical medieval scholar preserved through manuscript editions.'
      }
    });
  };

  const handleRegenerate = () => {
    setIsRegenerating(true);
    setRegenerateNotice(isEn ? 'Refreshing visualization based on historical parameters...' : 'வரலாற்றுத் தரவுகளின்படி காட்சி புதுப்பிக்கப்படுகிறது...');
    setTimeout(() => {
      setIsRegenerating(false);
      setRegenerateNotice(isEn ? 'New historical visualization ready.' : 'புதிய வரலாற்று காட்சிப்படுத்தல் தயாராக உள்ளது.');
      setTimeout(() => setRegenerateNotice(null), 3000);
    }, 1200);
  };

  const handleDownload = () => {
    if (!activeIllustration) return;
    const a = document.createElement('a');
    a.href = activeIllustration.imageUrl;
    a.download = `tamil-ai-kural-${kural.kuralNumber}.jpg`;
    a.target = '_blank';
    a.click();
  };

  const fullAnswerText = `கேள்வி: ${questionText}

பதில்: ஆம். கடின உழைப்பைப் பற்றி திருக்குறள் பொருட்பாலில் "ஆள்வினையுடைமை" (அதிகாரம் 62) என்ற அதிகாரத்தில் குறள் 619 உள்ளது.

திருக்குறள் - குறள் ${kural.kuralNumber}:
${kural.line1}
${kural.line2}

பொருள்:
${kural.porul}

இன்றைய தமிழில்:
${kural.modernTamilExplanation || kural.modernTamilTranslation}

English:
${kural.englishTranslation}`;

  return (
    <div ref={containerRef} className="research-answer-document max-w-[740px] mx-auto py-8 sm:py-12 px-2 sm:px-4 space-y-12 font-sans selection:bg-[#8B3A1C]/20">
      {/* Text Selection Floating Toolbar (Section 19) */}
      <TextSelectionToolbar
        containerRef={containerRef}
        onAction={handleToolbarAction}
        language={language}
      />

      {/* QUESTION HEADER (Section 2) */}
      <header className="space-y-3 pb-6 border-b border-[#E7E2D8] dark:border-[#27323C]">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono uppercase tracking-widest text-[#8B3A1C] dark:text-[#E07A5F] font-bold">
              {isEn ? 'RESEARCH INQUIRY' : 'ஆராய்ச்சி வினா'}
            </span>
            <span className="text-neutral-400">•</span>
            <span className="text-[11px] font-mono text-[#78716C] dark:text-[#94A3B8]">
              {kural.paal} · {kural.adhikaram}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {onToggleSave && (
              <button
                onClick={onToggleSave}
                className={`p-1.5 sm:px-2.5 sm:py-1 rounded-lg text-xs font-medium border flex items-center gap-1.5 transition-colors cursor-pointer ${
                  isSaved
                    ? 'bg-[#8B3A1C] text-white border-[#8B3A1C]'
                    : 'bg-white dark:bg-[#1E252D] border-[#E7E2D8] dark:border-[#334155] text-[#57534E] dark:text-[#CBD5E1] hover:border-[#8B3A1C]'
                }`}
                title={isSaved ? (isEn ? 'Saved in Collections' : 'சேமிக்கப்பட்டது') : (isEn ? 'Save Evidence' : 'சேமிக்க')}
              >
                <Bookmark className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">
                  {isSaved ? (isEn ? 'Saved' : 'சேமிக்கப்பட்டது') : (isEn ? 'Save' : 'சேமிக்க')}
                </span>
              </button>
            )}

            <button
              onClick={() => handleCopy('share', window.location.href)}
              className="p-1.5 rounded-lg text-xs border border-[#E7E2D8] dark:border-[#334155] bg-white dark:bg-[#1E252D] text-[#57534E] dark:text-[#CBD5E1] hover:border-[#8B3A1C] transition-colors cursor-pointer"
              title={isEn ? 'Copy link' : 'இணைப்பைப் பகிர்க'}
            >
              {copiedKey === 'share' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Share2 className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        <h1 className="text-xl sm:text-2xl font-serif font-bold text-[#1C1917] dark:text-[#F8FAFC] tracking-tight leading-snug">
          “{questionText}”
        </h1>
      </header>

      {/* ========================================================================= */}
      {/* FIRST LAYER — DIRECT ANSWER (Section 4 & 5) */}
      {/* ========================================================================= */}
      <section className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="text-xs font-mono uppercase tracking-widest text-[#8B3A1C] dark:text-[#E07A5F] font-bold flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#8B3A1C] dark:bg-[#E07A5F]" />
            <span>{isEn ? 'Direct Answer' : 'உங்கள் கேள்விக்கான பதில்'}</span>
          </div>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 font-bold border border-emerald-300 dark:border-emerald-800">
            {isEn ? 'Directly Documented' : 'நேரடி ஆதாரம் உள்ளது'}
          </span>
        </div>

        {/* Immediate affirmative answer */}
        <div className="space-y-2">
          <div className="text-3xl sm:text-4xl font-serif font-bold text-[#8B3A1C] dark:text-[#E07A5F]">
            {isEn ? 'Yes.' : 'ஆம்.'}
          </div>
          <p className="text-base sm:text-lg font-serif text-[#292524] dark:text-[#E2E8F0] leading-relaxed">
            {isEn ? (
              <>
                Thiruvalluvar devotes an entire chapter in Porutpal, <strong>Chapter 62: Alvinaiyudaimai (ஆள்வினையுடைமை — Effort and Hard Work)</strong>, to the supremacy of persevering human exertion over fatalism.{' '}
                <button
                  onClick={() => handleOpenSourceInLens('src-kural-619', 'Thirukkural Manuscript · Verse 619')}
                  className="inline-flex items-center text-xs font-mono text-[#8B3A1C] dark:text-[#E07A5F] underline hover:opacity-80 ml-1 cursor-pointer font-semibold"
                  title="Source 01 · Click to open Context Inspector"
                >
                  [Source 01]
                </button>
              </>
            ) : (
              <>
                கடின உழைப்பு மற்றும் இடைவிடாத முயற்சியின் இன்றியமையாமையைப் பற்றி திருக்குறள் பொருட்பாலில் <strong>"ஆள்வினையுடைமை" (அதிகாரம் 62)</strong> என்ற முழு அதிகாரத்திலேயே திருவள்ளுவர் விரிவாக விளக்கியுள்ளார்.{' '}
                <button
                  onClick={() => handleOpenSourceInLens('src-kural-619', 'திருக்குறள் ஓலைச்சுவடிப் பாடம் · குறள் 619')}
                  className="inline-flex items-center text-xs font-mono text-[#8B3A1C] dark:text-[#E07A5F] underline hover:opacity-80 ml-1 cursor-pointer font-semibold"
                  title="மூலம் 01 · வலது பலகையில் சான்றைப் பார்க்க"
                >
                  [சான்று 01]
                </button>
              </>
            )}
          </p>
        </div>

        {/* DEDICATED LITERARY READING COMPONENT (Section 5) */}
        {/* Treated like a literary quotation / primary text, NOT a generic rounded AI card */}
        <div className="pt-4 space-y-6">
          <div className="flex items-center justify-between pb-2 border-b border-[#E7E2D8] dark:border-[#27323C]">
            <div className="space-y-0.5">
              <span className="text-xs font-mono font-bold tracking-wider text-[#78716C] dark:text-[#94A3B8] uppercase">
                {isEn ? 'Thirukkural' : 'திருக்குறள்'}
              </span>
              <div className="text-sm font-serif font-bold text-[#8B3A1C] dark:text-[#E07A5F]">
                {isEn ? `Kural ${kural.kuralNumber}` : `குறள் ${kural.kuralNumber}`} · {kural.adhikaram}
              </div>
            </div>

            {/* Individual Copy Action: Copy Kural (Section 18) */}
            <button
              onClick={() => handleCopy('kural', `${kural.line1}\n${kural.line2}`)}
              className="flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-mono text-[#57534E] dark:text-[#CBD5E1] hover:text-[#8B3A1C] hover:bg-white dark:hover:bg-[#1E252D] border border-transparent hover:border-[#E7E2D8] transition-all cursor-pointer"
              title={isEn ? "Copy Kural text" : "குறளைப் பிரதியெடு"}
            >
              {copiedKey === 'kural' ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="text-emerald-600 font-bold">{isEn ? 'Copied' : 'பிரதியெடுக்கப்பட்டது'}</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>{isEn ? 'Copy Kural' : 'குறளைப் பிரதியெடு'}</span>
                </>
              )}
            </button>
          </div>

          {/* Primary Kural Verse in Authentic Typography */}
          <blockquote className="pl-4 sm:pl-6 border-l-3 border-[#8B3A1C] dark:border-[#E07A5F] py-2">
            <p className="text-2xl sm:text-3xl font-serif font-bold text-[#1C1917] dark:text-[#F8FAFC] leading-[1.7] tracking-tight whitespace-pre-line">
              {kural.line1}
              {'\n'}
              {kural.line2}
            </p>
            {kural.transliteration && (
              <p className="mt-3 text-xs font-mono text-[#78716C] dark:text-[#94A3B8] leading-relaxed italic">
                {kural.transliteration}
              </p>
            )}
          </blockquote>

          {/* பொருள் (Meaning) */}
          <div className="space-y-2 pt-2">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-mono uppercase tracking-wider text-[#8B3A1C] dark:text-[#E07A5F] font-bold">
                {isEn ? 'Meaning (பொருள்)' : 'பொருள்'}
              </h3>
              <button
                onClick={() => handleCopy('porul', kural.porul || '')}
                className="text-[11px] font-mono text-[#78716C] hover:text-[#8B3A1C] flex items-center gap-1 cursor-pointer"
              >
                {copiedKey === 'porul' ? <span className="text-emerald-600 font-bold">Copied</span> : <Copy className="w-3 h-3" />}
              </button>
            </div>
            <p className="text-base sm:text-lg font-serif text-[#1C1917] dark:text-[#E2E8F0] leading-relaxed">
              {kural.porul}
            </p>
          </div>

          {/* இன்றைய தமிழில் (Simple Modern Tamil Explanation) */}
          <div className="space-y-2 pt-2">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-mono uppercase tracking-wider text-[#78716C] dark:text-[#94A3B8] font-bold">
                {isEn ? 'Modern Tamil Explanation' : 'இன்றைய தமிழில்'}
              </h3>
              <button
                onClick={() => handleCopy('modern', kural.modernTamilExplanation || '')}
                className="text-[11px] font-mono text-[#78716C] hover:text-[#8B3A1C] flex items-center gap-1 cursor-pointer"
              >
                {copiedKey === 'modern' ? <span className="text-emerald-600 font-bold">Copied</span> : <Copy className="w-3 h-3" />}
              </button>
            </div>
            <p className="text-sm sm:text-base font-sans text-[#44403C] dark:text-[#CBD5E1] leading-relaxed">
              {kural.modernTamilExplanation || kural.modernTamilTranslation}
            </p>
          </div>

          {/* English (Clear English explanation) */}
          <div className="space-y-2 pt-2">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-mono uppercase tracking-wider text-[#78716C] dark:text-[#94A3B8] font-bold">
                English
              </h3>
              <button
                onClick={() => handleCopy('english', kural.englishTranslation)}
                className="text-[11px] font-mono text-[#78716C] hover:text-[#8B3A1C] flex items-center gap-1 cursor-pointer"
              >
                {copiedKey === 'english' ? <span className="text-emerald-600 font-bold">Copied</span> : <Copy className="w-3 h-3" />}
              </button>
            </div>
            <p className="text-sm sm:text-base font-serif italic text-[#44403C] dark:text-[#CBD5E1] leading-relaxed">
              “{kural.englishTranslation}”
            </p>
          </div>

          {/* Copy complete answer button (Section 18) */}
          <div className="pt-2 flex items-center justify-end">
            <button
              onClick={() => handleCopy('all', fullAnswerText)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#E7E2D8] dark:border-[#334155] bg-white dark:bg-[#1E252D] text-xs font-medium text-[#57534E] dark:text-[#CBD5E1] hover:border-[#8B3A1C] hover:text-[#8B3A1C] transition-colors cursor-pointer shadow-xs"
            >
              {copiedKey === 'all' ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="text-emerald-600 font-bold">{isEn ? 'Complete Answer Copied' : 'முழு பதிலும் பிரதியெடுக்கப்பட்டது'}</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>{isEn ? 'Copy complete answer' : 'முழு பதிலையும் பிரதியெடு'}</span>
                </>
              )}
            </button>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* ANSWER END — VISUALLY CLEAR STOPPING BOUNDARY (Section 6 & 28) */}
      {/* ========================================================================= */}
      <div className="relative my-8">
        <div className="absolute inset-0 flex items-center" aria-hidden="true">
          <div className="w-full border-t border-[#D6CEBE] dark:border-[#2D3843]" />
        </div>
        <div className="relative flex justify-center">
          <span className="px-4 py-1 rounded-full bg-[#FAF8F5] dark:bg-[#12161A] text-xs font-mono uppercase tracking-widest text-[#8B3A1C] dark:text-[#E07A5F] font-bold border border-[#E7E2D8] dark:border-[#27323C] shadow-xs">
            {isEn ? 'Sources & Supporting Research' : 'இதன் ஆதாரம்'}
          </span>
        </div>
      </div>

      <div className="text-center -mt-6">
        <p className="text-[11px] font-mono text-[#78716C] dark:text-[#94A3B8]">
          {isEn 
            ? 'The primary answer has concluded. Below is supporting evidence, commentaries, and scholarly debate.'
            : 'முதன்மைப் பதில் முடிவடைந்தது. கீழே உள்ளவை இக்கருத்தை நிறுவும் வரலாற்று, உரை மற்றும் தொல்லியல் சான்றுகள்.'}
        </p>
      </div>

      {/* ========================================================================= */}
      {/* SUPPORTING EVIDENCE WITH INLINE ACCESSIBLE SOURCES (Section 7, 8, 9, 10) */}
      {/* ========================================================================= */}
      <section className="space-y-6">
        {/* Source Badges Row */}
        <div className="p-4 rounded-2xl bg-white dark:bg-[#161D24] border border-[#E7E2D8] dark:border-[#27323C] space-y-3 shadow-xs">
          <div className="text-xs font-mono uppercase tracking-wider text-[#78716C] dark:text-[#94A3B8] font-bold">
            {isEn ? 'Primary Sources Cited in This Answer' : 'இப்பதிலில் மேற்கோள் காட்டப்பட்ட மூலங்கள்'}
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => handleOpenSourceInLens('src-kural-619', 'Thirukkural Manuscript · Verse 619')}
              className="group flex items-center gap-2 px-3 py-2 rounded-xl bg-[#FAF8F5] dark:bg-[#1E252D] border border-[#E7E2D8] dark:border-[#334155] hover:border-[#8B3A1C] transition-all cursor-pointer text-left"
              title="Click to open Source in Context Inspector"
            >
              <FileText className="w-3.5 h-3.5 text-[#8B3A1C] shrink-0" />
              <div className="min-w-0">
                <div className="text-xs font-serif font-bold text-[#1C1917] dark:text-[#F8FAFC] group-hover:text-[#8B3A1C] flex items-center gap-1">
                  <span>{isEn ? 'Source 01 · Palm-leaf Manuscript' : 'சான்று 01 · ஓலைச்சுவடிப் பாடம்'}</span>
                  <ExternalLink className="w-3 h-3 opacity-60" />
                </div>
                <div className="text-[10px] font-mono text-[#78716C]">
                  {isEn ? 'Chapter 62, Verse 9 · UVS Library' : 'அதிகாரம் 62, குறள் 9 · உ.வே.சா. நூலகம்'}
                </div>
              </div>
            </button>

            <button
              onClick={() => handleOpenScholarInLens('பரிமேலழகர் (Parimelazhagar)', 'Medieval Classical Commentator', '13th Century CE', 'ஊழினால் ஒரு செயல் முடியாதாயினும், விடாது முயன்றவன் உடம்பு வருந்திய வருத்தத்திற்குத் தக்க பயனை அவனுக்குத் தரும்.')}
              className="group flex items-center gap-2 px-3 py-2 rounded-xl bg-[#FAF8F5] dark:bg-[#1E252D] border border-[#E7E2D8] dark:border-[#334155] hover:border-[#8B3A1C] transition-all cursor-pointer text-left"
              title="Click to inspect Scholar"
            >
              <User className="w-3.5 h-3.5 text-[#8B3A1C] shrink-0" />
              <div className="min-w-0">
                <div className="text-xs font-serif font-bold text-[#1C1917] dark:text-[#F8FAFC] group-hover:text-[#8B3A1C] flex items-center gap-1">
                  <span>{isEn ? 'Scholar · Parimelazhagar (Source 02)' : 'அறிஞர் · பரிமேலழகர் (சான்று 02)'}</span>
                  <ExternalLink className="w-3 h-3 opacity-60" />
                </div>
                <div className="text-[10px] font-mono text-[#78716C]">
                  {isEn ? '13th c. CE Commentary' : '13-ஆம் நூற்றாண்டு உரை'}
                </div>
              </div>
            </button>

            <button
              onClick={() => handleOpenSourceInLens('src-arch-kodumanal', 'Archaeological Iron Implements (Kodumanal & Keeladi)')}
              className="group flex items-center gap-2 px-3 py-2 rounded-xl bg-[#FAF8F5] dark:bg-[#1E252D] border border-[#E7E2D8] dark:border-[#334155] hover:border-[#8B3A1C] transition-all cursor-pointer text-left"
              title="Click to view Archaeological Evidence"
            >
              <Layers className="w-3.5 h-3.5 text-[#8B3A1C] shrink-0" />
              <div className="min-w-0">
                <div className="text-xs font-serif font-bold text-[#1C1917] dark:text-[#F8FAFC] group-hover:text-[#8B3A1C] flex items-center gap-1">
                  <span>{isEn ? 'Archaeology · Sangam Iron Tools' : 'தொல்லியல் · சங்ககால உழவுக் கருவிகள்'}</span>
                  <ExternalLink className="w-3 h-3 opacity-60" />
                </div>
                <div className="text-[10px] font-mono text-[#78716C]">
                  {isEn ? 'Keeladi & Kodumanal Ploughshares' : 'கீழடி & கொடுமணல் இரும்புக் கொழு'}
                </div>
              </div>
            </button>
          </div>
        </div>

        {/* TRADITIONAL COMMENTARIES & DIVERGENT INTERPRETATIONS (Section 33) */}
        {kural.commentaries && kural.commentaries.length > 0 && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-mono uppercase tracking-wider text-[#1C1917] dark:text-[#F8FAFC] font-bold">
                {isEn ? 'Scholarly Interpretations & Classical Commentaries' : 'மரபுசார் உரையாசிரியர்களின் விளக்கம்'}
              </h3>
              <span className="text-[10px] font-mono text-[#78716C]">
                {isEn ? 'Independent Hermeneutic Lineages' : 'செவ்வியல் உரை மரபு'}
              </span>
            </div>

            <div className="space-y-3">
              {kural.commentaries.map((c, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-xl bg-white dark:bg-[#161D24] border border-[#E7E2D8] dark:border-[#27323C] hover:border-[#8B3A1C]/50 transition-colors space-y-2"
                >
                  <div className="flex items-center justify-between text-xs">
                    <button
                      onClick={() => handleOpenScholarInLens(c.scholar, 'Classical Commentator', c.period, c.tamilText)}
                      className="font-serif font-bold text-[#8B3A1C] dark:text-[#E07A5F] hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <span>{c.scholar}</span>
                      <ExternalLink className="w-3 h-3 opacity-60" />
                    </button>
                    <span className="text-[10px] font-mono text-[#78716C] dark:text-[#94A3B8]">{c.period}</span>
                  </div>

                  <p className="text-xs sm:text-sm font-serif text-[#1C1917] dark:text-[#E2E8F0] leading-relaxed">
                    “{c.tamilText}”
                  </p>
                  <p className="text-[11px] font-sans text-[#78716C] dark:text-[#94A3B8] leading-relaxed italic">
                    {c.englishSummary}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}
      </section>

      {/* ========================================================================= */}
      {/* CONVERSATIONAL DECISION POINT — EXPLORE FURTHER? (Section 15, 37) */}
      {/* ========================================================================= */}
      <section className="p-5 sm:p-6 rounded-2xl bg-[#F5F0E6] dark:bg-[#182026] border border-[#E7E2D8] dark:border-[#2D3843] space-y-4">
        <div className="space-y-1">
          <div className="text-xs font-mono uppercase tracking-wider text-[#8B3A1C] dark:text-[#E07A5F] font-bold">
            {isEn ? 'Want to explore this further?' : 'இந்த விஷயத்தை மேலும் ஆராய விரும்புகிறீர்களா?'}
          </div>
          <p className="text-xs text-[#57534E] dark:text-[#CBD5E1] font-sans">
            {isEn 
              ? 'Choose your research depth. You can inspect primary manuscripts, compare scholarly disagreements, or open deep research.'
              : 'நீங்கள் விரும்பும் ஆய்வு ஆழத்தைத் தேர்ந்தெடுக்கவும். மூலச்சுவடிகள், அறிஞர்களின் கருத்து வேறுபாடுகள் மற்றும் ஆழமான ஆய்வை அணுகலாம்.'}
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setExplorationDepth('quick')}
            className={`px-3 py-2 rounded-xl text-xs font-mono transition-all cursor-pointer ${
              explorationDepth === 'quick'
                ? 'bg-[#8B3A1C] text-white shadow-xs font-bold'
                : 'bg-white dark:bg-[#1E252D] text-[#57534E] dark:text-[#CBD5E1] border border-[#E7E2D8] dark:border-[#334155] hover:border-[#8B3A1C]'
            }`}
          >
            {isEn ? 'Quick explanation' : 'விரைவு விளக்கம்'}
          </button>

          <button
            onClick={() => setExplorationDepth('explore')}
            className={`px-3 py-2 rounded-xl text-xs font-mono transition-all cursor-pointer ${
              explorationDepth === 'explore'
                ? 'bg-[#8B3A1C] text-white shadow-xs font-bold'
                : 'bg-white dark:bg-[#1E252D] text-[#57534E] dark:text-[#CBD5E1] border border-[#E7E2D8] dark:border-[#334155] hover:border-[#8B3A1C]'
            }`}
          >
            {isEn ? 'Explore the evidence' : 'சான்றுகளை ஆராய'}
          </button>

          <button
            onClick={() => setExplorationDepth('deep')}
            className={`px-3 py-2 rounded-xl text-xs font-mono transition-all cursor-pointer ${
              explorationDepth === 'deep'
                ? 'bg-[#8B3A1C] text-white shadow-xs font-bold'
                : 'bg-white dark:bg-[#1E252D] text-[#57534E] dark:text-[#CBD5E1] border border-[#E7E2D8] dark:border-[#334155] hover:border-[#8B3A1C]'
            }`}
          >
            {isEn ? 'Deep research workspace' : 'ஆழ்ந்த ஆய்வு'}
          </button>

          <button
            onClick={() => {
              handleOpenScholarInLens('பரிமேலழகர் & மணக்குடவர்', 'Classical Commentator Debate', '10th–13th c. CE', 'Deivam as Fate vs Deivam as Circumstance');
            }}
            className="px-3 py-2 rounded-xl text-xs font-mono bg-white dark:bg-[#1E252D] text-[#57534E] dark:text-[#CBD5E1] border border-[#E7E2D8] dark:border-[#334155] hover:border-[#8B3A1C] transition-all cursor-pointer"
          >
            {isEn ? 'Compare scholars' : 'அறிஞர்களின் உரைகளை ஒப்பிட'}
          </button>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* DEEP RESEARCH WORKSPACE (Section 16) — EXPANDS WHEN "DEEP" IS ACTIVE */}
      {/* ========================================================================= */}
      {explorationDepth === 'deep' && (
        <section className="p-6 rounded-2xl bg-white dark:bg-[#161D24] border border-[#8B3A1C]/30 space-y-6 shadow-sm animate-fadeIn">
          <div className="flex items-center justify-between pb-3 border-b border-[#E7E2D8] dark:border-[#27323C]">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#8B3A1C]" />
              <h3 className="text-sm font-serif font-bold text-[#1C1917] dark:text-[#F8FAFC]">
                {isEn ? 'Deep Research Workspace' : 'ஆழ்ந்த ஆய்வு அரங்கம்'}
              </h3>
            </div>
            <span className="text-[10px] font-mono uppercase bg-[#8B3A1C]/10 text-[#8B3A1C] dark:text-[#E07A5F] px-2 py-0.5 rounded font-bold">
              {isEn ? 'EXPERT ANALYSIS' : 'விரிவான ஆய்வு'}
            </span>
          </div>

          {/* 1. Research Question */}
          <div className="space-y-1">
            <span className="text-[10px] font-mono uppercase text-[#78716C] dark:text-[#94A3B8] font-bold">
              {isEn ? '1. Research Question' : '1. ஆராய்ச்சி வினா'}
            </span>
            <p className="text-xs font-serif text-[#1C1917] dark:text-[#F8FAFC]">
              {questionText}
            </p>
          </div>

          {/* 2. What We Know (Established Evidence) */}
          <div className="space-y-1.5">
            <span className="text-[10px] font-mono uppercase text-emerald-800 dark:text-emerald-400 font-bold">
              {isEn ? '2. What is Established' : '2. நிறுவப்பட்ட சான்றுகள்'}
            </span>
            <ul className="text-xs font-sans text-[#44403C] dark:text-[#CBD5E1] space-y-1 pl-4 list-disc">
              <li>{isEn ? 'Kural 619 is unanimously attested in all ten medieval commentary recensions and palm-leaf manuscripts.' : 'பதினெண் உரையாசிரியர்களின் மரபிலும் மூல ஓலைச்சுவடிகளிலும் குறள் 619 மாற்றமின்றி உறுதிசெய்யப்பட்டுள்ளது.'}</li>
              <li>{isEn ? 'Valluvar establishes the concept of "Meyvaruthak Kooli" (the yield of bodily labor) as an autonomous law of action.' : '"மெய்வருத்தக் கூலி" என்ற தொடரின் மூலம் மனித உழைப்பின் பலனை இயல்பான இயற்கை விதியாக வள்ளுவர் நிலைநாட்டுகிறார்.'}</li>
              <li>{isEn ? 'The Sangam economic ethos honors agrarian production and iron technology over passive asceticism.' : 'சங்ககால சமுதாயம் செயலற்ற விதியை விட உழவு மற்றும் தொழில் உற்பத்தியை முதன்மைப்படுத்தியது.'}</li>
            </ul>
          </div>

          {/* 3. Areas of Disagreement (Debated Interpretations) */}
          <div className="space-y-1.5 p-4 rounded-xl bg-amber-50/70 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40">
            <span className="text-[10px] font-mono uppercase text-amber-900 dark:text-amber-400 font-bold block">
              {isEn ? '3. Areas of Disagreement & Interpretation' : '3. கருத்து வேறுபாடுகளும் விவாதங்களும்'}
            </span>
            <p className="text-xs font-serif text-[#292524] dark:text-[#CBD5E1] leading-relaxed">
              {isEn 
                ? 'Medieval commentators (Parimelazhagar) interpret "தெய்வம்" (Deivam) strictly as past karma (ஊழ்), asserting effort can defeat karma. Modern secular scholars (such as T.P. Meenakshisundaram) argue "தெய்வம்" denotes circumstantial nature or environmental adversity, framing Valluvar as a humanist champion of labor.' 
                : 'பரிமேலழகர் "தெய்வம்" என்பதை முற்பிறப்பு "ஊழ்" (வினைப்பயன்) என்று விளக்குகிறார்; மனித உழைப்பால் ஊழையும் வெல்ல முடியும் என்பது அவர் வாதம். ஆனால் தற்கால அறிஞர்கள் "தெய்வம்" என்பதை இயற்கைச் சீற்றம் அல்லது எதிர்பாராத சூழ்நிலை என்று பொருள் கொண்டு, வள்ளுவரை மனித உழைப்பின் பேராளராகக் காண்கின்றனர்.'}
            </p>
          </div>

          {/* 4. Open Questions (What remains uncertain) */}
          <div className="space-y-1">
            <span className="text-[10px] font-mono uppercase text-[#78716C] dark:text-[#94A3B8] font-bold">
              {isEn ? '4. Open Questions' : '4. முடிவுசெய்யப்படாத திறந்த வினாக்கள்'}
            </span>
            <p className="text-xs text-[#57534E] dark:text-[#CBD5E1] font-sans">
              {isEn 
                ? 'Whether Thiruvalluvar accepted metaphysical determinism as a supreme boundary or whether Kural 620 ("ஊழையும் உப்பக்கம் காண்பர்") entirely subordinated fate to persevering toil.' 
                : 'வள்ளுவர் ஊழை முழுமையான விதியாக ஏற்றுக்கொண்டாரா, அல்லது "ஊழையும் உப்பக்கம் காண்பர்" என்பதன் மூலம் விதியை உழைப்பிற்கு முழுமையாக அடிபணிய வைத்தாரா என்பது தொடர்ந்து விவாதிக்கப்படுகிறது.'}
            </p>
          </div>
        </section>
      )}

      {/* ========================================================================= */}
      {/* RELATED KURALS ON THIS THEME (Section 2, 21) */}
      {/* ========================================================================= */}
      {kural.relatedKurals && kural.relatedKurals.length > 0 && (
        <section className="space-y-4 pt-6 border-t border-[#E7E2D8] dark:border-[#27323C]">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-serif font-bold text-[#1C1917] dark:text-[#F8FAFC]">
              {isEn ? 'Related Verses on Effort and Perseverance' : 'கடின உழைப்பைப் பேசும் தொடர்புடைய குறள்கள்'}
            </h3>
            <span className="text-[11px] font-mono text-[#78716C] dark:text-[#94A3B8]">
              {showExtendedKurals ? (isEn ? '6 verses' : '6 குறள்கள்') : (isEn ? '3 verses' : '3 குறள்கள்')}
            </span>
          </div>

          <div className="space-y-2.5">
            {kural.relatedKurals.slice(0, 3).map((rel) => (
              <div
                key={rel.number}
                onClick={() => onSelectKural && onSelectKural(rel.number)}
                className="p-4 rounded-xl bg-white dark:bg-[#161D24] border border-[#E7E2D8] dark:border-[#27323C] hover:border-[#8B3A1C] transition-all cursor-pointer group space-y-1.5 shadow-2xs"
              >
                <div className="flex items-center justify-between text-xs">
                  <span className="font-mono font-bold text-[#8B3A1C] dark:text-[#E07A5F]">
                    {isEn ? `Kural ${rel.number}` : `குறள் ${rel.number}`}
                  </span>
                  <ArrowRight className="w-3.5 h-3.5 text-[#A8A29E] group-hover:text-[#8B3A1C] group-hover:translate-x-0.5 transition-all" />
                </div>
                <div className="text-sm font-serif font-medium text-[#1C1917] dark:text-[#F8FAFC] leading-snug">
                  {rel.line1}
                </div>
                <div className="text-xs text-[#78716C] dark:text-[#94A3B8] font-sans">
                  {rel.theme}
                </div>
              </div>
            ))}

            {showExtendedKurals && kural.extendedRelatedKurals && (
              <div className="space-y-2.5 pt-2 animate-fadeIn">
                {kural.extendedRelatedKurals.map((ext) => (
                  <div
                    key={ext.number}
                    onClick={() => onSelectKural && onSelectKural(ext.number)}
                    className="p-4 rounded-xl bg-[#FAF8F5] dark:bg-[#1A2229] border border-[#EBE5DA] dark:border-[#27323C] hover:border-[#8B3A1C] transition-all cursor-pointer group space-y-1.5"
                  >
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-mono font-bold text-[#8B3A1C] dark:text-[#E07A5F]">
                        {isEn ? `Kural ${ext.number}` : `குறள் ${ext.number}`}
                      </span>
                      <ArrowRight className="w-3.5 h-3.5 text-[#A8A29E] group-hover:text-[#8B3A1C] group-hover:translate-x-0.5 transition-all" />
                    </div>
                    <div className="text-sm font-serif font-medium text-[#1C1917] dark:text-[#F8FAFC] leading-snug">
                      {ext.line1}
                    </div>
                    {ext.meaning && (
                      <div className="text-xs text-[#78716C] dark:text-[#94A3B8] font-sans">
                        {ext.meaning}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {kural.extendedRelatedKurals && kural.extendedRelatedKurals.length > 0 && (
            <button
              onClick={() => setShowExtendedKurals(!showExtendedKurals)}
              className="w-full py-2.5 rounded-xl border border-dashed border-[#E7E2D8] dark:border-[#334155] bg-white/50 dark:bg-[#161D24]/50 text-xs font-medium text-[#57534E] dark:text-[#CBD5E1] hover:border-[#8B3A1C] hover:text-[#8B3A1C] transition-colors cursor-pointer"
            >
              {showExtendedKurals 
                ? (isEn ? 'Show fewer verses' : 'குறைவான குறள்களைக் காட்டு') 
                : (isEn ? 'Show more related verses on effort' : 'மேலும் குறள்களைப் பார்க்க')}
            </button>
          )}
        </section>
      )}

      {/* ========================================================================= */}
      {/* AI GENERATED VISUALIZATION (Section 34) */}
      {/* ========================================================================= */}
      {activeIllustration && (
        <section className="space-y-4 pt-6 border-t border-[#E7E2D8] dark:border-[#27323C]">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <h3 className="text-sm font-serif font-bold text-[#1C1917] dark:text-[#F8FAFC]">
                {isEn ? 'AI Visual Interpretation' : 'காட்சிப்படுத்தல்'}
              </h3>
              <p className="text-xs text-[#78716C] dark:text-[#94A3B8]">
                {isEn 
                  ? 'Conjectural reconstruction based on classical descriptions of agrarian labor.' 
                  : 'சங்ககால உழவு மற்றும் தொழில் பற்றிய வர்ணனைகளை அடிப்படையாகக் கொண்ட AI காட்சி.'}
              </p>
            </div>
            <span className="text-[10px] font-mono px-2.5 py-1 rounded bg-purple-100 dark:bg-purple-950/60 text-purple-800 dark:text-purple-300 font-bold border border-purple-200 dark:border-purple-800">
              {isEn ? 'AI VISUALIZATION' : 'AI காட்சி விளக்கம்'}
            </span>
          </div>

          <div className="rounded-2xl border border-[#E7E2D8] dark:border-[#27323C] bg-white dark:bg-[#161D24] overflow-hidden shadow-xs">
            <div className="relative aspect-[16/9] w-full bg-neutral-900 overflow-hidden flex items-center justify-center">
              <img
                src={activeIllustration.imageUrl}
                alt={activeIllustration.title}
                style={{ transform: `scale(${zoomScale})` }}
                className="w-full h-full object-cover transition-transform duration-200"
              />

              {isRegenerating && (
                <div className="absolute inset-0 bg-black/75 flex flex-col items-center justify-center text-white p-4 space-y-2 z-10">
                  <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <p className="text-xs font-mono">{regenerateNotice}</p>
                </div>
              )}

              {/* Strict Epistemic Label (Section 34) */}
              <div className="absolute bottom-3 left-3 right-3 sm:right-auto px-3 py-1.5 rounded-lg bg-black/80 backdrop-blur-xs text-[11px] text-[#F1F5F9] font-mono flex items-center gap-2">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>{isEn ? 'AI-generated visualization · Not historical evidence' : 'AI உருவாக்கிய காட்சி · வரலாற்று ஆதாரம் அல்ல'}</span>
              </div>

              {/* Zoom & Fullscreen Toolbar */}
              <div className="absolute top-3 right-3 flex items-center gap-1 bg-black/60 backdrop-blur-xs p-1 rounded-lg">
                <button
                  onClick={() => setZoomScale(s => Math.min(s + 0.25, 2.5))}
                  className="p-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded transition-colors cursor-pointer"
                  title="Zoom in"
                >
                  <ZoomIn className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setZoomScale(s => Math.max(s - 0.25, 0.75))}
                  className="p-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded transition-colors cursor-pointer"
                  title="Zoom out"
                >
                  <ZoomOut className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setZoomScale(1)}
                  className="p-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded transition-colors cursor-pointer"
                  title="Reset"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setIsFullScreen(true)}
                  className="p-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded transition-colors cursor-pointer"
                  title="Fullscreen"
                >
                  <Maximize2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="p-4 flex flex-wrap items-center justify-between gap-3 bg-[#FAF8F5] dark:bg-[#12161A] border-t border-[#E7E2D8] dark:border-[#27323C]">
              <div className="text-xs text-[#57534E] dark:text-[#CBD5E1] font-sans max-w-md">
                <strong>{isEn ? 'Prompt basis:' : 'வரலாற்று அடிப்படை:'}</strong> {activeIllustration.caption}
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleDownload}
                  className="px-3 py-1.5 rounded-lg border border-[#E7E2D8] dark:border-[#334155] bg-white dark:bg-[#1E252D] text-xs font-medium hover:border-[#8B3A1C] flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{isEn ? 'Download' : 'பதிவிறக்கு'}</span>
                </button>
                <button
                  onClick={handleRegenerate}
                  disabled={isRegenerating}
                  className="px-3 py-1.5 rounded-lg border border-[#E7E2D8] dark:border-[#334155] bg-white dark:bg-[#1E252D] text-xs font-medium hover:border-[#8B3A1C] flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <RotateCcw className={`w-3.5 h-3.5 ${isRegenerating ? 'animate-spin' : ''}`} />
                  <span>{isEn ? 'Regenerate' : 'மறுஉருவாக்கு'}</span>
                </button>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* ========================================================================= */}
      {/* INTELLIGENT SCHOLAR-LEVEL RESEARCH PATHS & NEXT STEPS (Section 20, 21, 23) */}
      {/* ========================================================================= */}
      <section className="space-y-4 pt-6 border-t border-[#E7E2D8] dark:border-[#27323C]">
        <div className="space-y-1">
          <h3 className="text-xs font-mono uppercase tracking-wider text-[#8B3A1C] dark:text-[#E07A5F] font-bold">
            {isEn ? 'Continue your research · Contextual Paths' : 'தொடர்ந்து ஆராயுங்கள்'}
          </h3>
          <p className="text-xs text-[#78716C] dark:text-[#94A3B8]">
            {isEn ? 'Intelligent inquiry paths curated for scholars and researchers:' : 'இக்கேள்வியோடு தொடர்புடைய ஆழமான வினாக்கள்:'}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {[
            {
              ta: 'இந்தக் கருத்தைப் பேசும் மற்ற குறள்கள் என்ன?',
              en: 'Which other Kurals develop this philosophy of labor?'
            },
            {
              ta: 'பரிமேலழகர் "தெய்வத்தான் ஆகா தெனினும்" என்பதை எப்படி விளக்குகிறார்?',
              en: 'How does Parimelazhagar interpret "Theyvaththaan aakaa theninum"?'
            },
            {
              ta: 'இதே போன்ற உழைப்பின் பெருமை சங்க இலக்கியத்தில் உள்ளதா?',
              en: 'Is this concept of labor found in Sangam anthologies (Akananuru, Purananuru)?'
            },
            {
              ta: 'ஆள்வினையுடைமை அதிகாரத்தின் அனைத்து குறள்களும் யாவை?',
              en: 'What are all 10 verses of Chapter 62 (Alvinaiyudaimai)?'
            }
          ].map((prompt, idx) => (
            <button
              key={idx}
              onClick={() => {
                const q = isEn ? prompt.en : prompt.ta;
                if (onFollowUpQuery) {
                  onFollowUpQuery(q);
                } else {
                  setFollowUpInput(q);
                }
              }}
              className="p-3.5 rounded-xl bg-white dark:bg-[#161D24] border border-[#E7E2D8] dark:border-[#27323C] hover:border-[#8B3A1C] text-left transition-all group flex items-start justify-between gap-2 cursor-pointer shadow-2xs"
            >
              <span className="text-xs font-serif text-[#1C1917] dark:text-[#F8FAFC] group-hover:text-[#8B3A1C]">
                {isEn ? prompt.en : prompt.ta}
              </span>
              <ChevronRight className="w-4 h-4 text-[#A8A29E] group-hover:text-[#8B3A1C] group-hover:translate-x-0.5 shrink-0 mt-0.5 transition-transform" />
            </button>
          ))}
        </div>
      </section>

      {/* ========================================================================= */}
      {/* SEAMLESS CONVERSATION TRANSITION / FOLLOW-UP COMPOSER (Section 20 & 36) */}
      {/* ========================================================================= */}
      <section className="pt-4">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (followUpInput.trim() && onFollowUpQuery) {
              onFollowUpQuery(followUpInput.trim());
              setFollowUpInput('');
            }
          }}
          className="p-3 rounded-2xl bg-white dark:bg-[#161D24] border border-[#E7E2D8] dark:border-[#27323C] shadow-sm flex items-center gap-2"
        >
          <MessageSquare className="w-4 h-4 text-[#8B3A1C] ml-2 shrink-0" />
          <input
            type="text"
            value={followUpInput}
            onChange={(e) => setFollowUpInput(e.target.value)}
            placeholder={
              isEn 
                ? 'Ask a follow-up question in context... (e.g., How does Valluvar compare fate and effort?)' 
                : 'இக்கேள்வியைத் தொடர்ந்து வினவுக... (எ.கா: விதியையும் முயற்சியையும் வள்ளுவர் எவ்வாறு ஒப்பிடுகிறார்?)'
            }
            className="w-full bg-transparent text-sm font-serif text-[#1C1917] dark:text-[#F8FAFC] placeholder:text-[#A8A29E] outline-hidden px-1"
          />
          <button
            type="submit"
            disabled={!followUpInput.trim()}
            className={`px-4 py-2 rounded-xl text-xs font-medium shrink-0 transition-all cursor-pointer ${
              followUpInput.trim()
                ? 'bg-[#8B3A1C] text-white hover:bg-[#732F16] shadow-xs'
                : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-400 cursor-not-allowed'
            }`}
          >
            {isEn ? 'Ask' : 'கேட்க'}
          </button>
        </form>
      </section>

      {/* Full Screen Image Modal */}
      {isFullScreen && activeIllustration && (
        <div className="fixed inset-0 z-50 bg-black/95 flex flex-col items-center justify-center p-4">
          <button
            onClick={() => setIsFullScreen(false)}
            className="absolute top-4 right-4 p-2 text-white/70 hover:text-white bg-white/10 hover:bg-white/20 rounded-full transition-colors cursor-pointer"
          >
            <X className="w-6 h-6" />
          </button>
          <img
            src={activeIllustration.imageUrl}
            alt={activeIllustration.title}
            className="max-w-[90vw] max-h-[85vh] object-contain rounded-lg shadow-2xl"
          />
          <div className="mt-3 text-center text-xs font-mono text-neutral-300">
            {activeIllustration.disclaimer}
          </div>
        </div>
      )}
    </div>
  );
};
