import React from 'react';
import { ScholarlyDebate } from '../types/research';
import { Scale, CheckCircle2, HelpCircle, BookOpen } from 'lucide-react';

interface ScholarlyDebateCardProps {
  debates: ScholarlyDebate[];
  onSelectScholar?: (scholarName: string) => void;
  language: 'ta' | 'en';
}

export const ScholarlyDebateCard: React.FC<ScholarlyDebateCardProps> = ({
  debates,
  onSelectScholar,
  language
}) => {
  const isEn = language === 'en';

  if (!debates || debates.length === 0) return null;

  return (
    <div className="space-y-6 my-6">
      <div className="flex items-center gap-2 border-b border-[#E5DFC8] dark:border-[#2D3842] pb-2">
        <Scale className="w-4 h-4 text-[#A85C43]" />
        <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-[#9B8060] dark:text-[#C4A57F]">
          {isEn ? 'SCHOLARLY INTERPRETATION & DISAGREEMENTS' : 'அறிஞர்களின் வரலாற்று விவாதங்கள்'}
        </h3>
      </div>

      {debates.map((debate) => (
        <div
          key={debate.id}
          className="bg-white dark:bg-[#1A2229] border border-[#E5DFC8] dark:border-[#2D3842] rounded-xl overflow-hidden shadow-xs"
        >
          {/* Header */}
          <div className="bg-[#FAF7F0] dark:bg-[#141B20] px-5 py-3 border-b border-[#E5DFC8] dark:border-[#2D3842]">
            <span className="text-[10px] font-mono uppercase tracking-widest text-[#A85C43] dark:text-[#D47B62] font-semibold">
              {isEn ? 'CRITICAL HISTORIOGRAPHICAL DEBATE' : 'முக்கிய வரலாற்று விவாதம்'}
            </span>
            <h4 className="text-sm font-semibold text-neutral-900 dark:text-white mt-0.5">
              {debate.topicTitle}
            </h4>
          </div>

          {/* Side by side interpretations */}
          <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-[#E5DFC8] dark:divide-[#2D3842]">
            {/* Interpretation A */}
            <div className="p-5 bg-white dark:bg-[#1A2229]">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-blue-50 dark:bg-blue-950/40 text-blue-800 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
                  {isEn ? 'INTERPRETATION A' : 'விளக்கம் A'}
                </span>
                <span className="text-[11px] font-mono text-neutral-500">{debate.interpretationA.date}</span>
              </div>

              <div
                onClick={() => onSelectScholar && onSelectScholar(debate.interpretationA.scholar)}
                className="font-serif font-bold text-neutral-900 dark:text-white text-sm hover:text-[#A85C43] cursor-pointer transition-colors"
              >
                {debate.interpretationA.scholar}
              </div>
              <div className="text-xs text-neutral-500 dark:text-neutral-400 italic mb-3 font-scholarly">
                {debate.interpretationA.publication}
              </div>

              <p className="text-xs text-neutral-700 dark:text-neutral-300 leading-relaxed mb-4">
                {debate.interpretationA.argument}
              </p>

              <div>
                <div className="text-[10px] font-mono uppercase text-neutral-400 font-semibold mb-1">
                  {isEn ? 'Evidence Mobilized:' : 'பயன்படுத்தப்பட்ட சான்றுகள்:'}
                </div>
                <ul className="space-y-1">
                  {debate.interpretationA.evidenceUsed.map((ev, i) => (
                    <li key={i} className="text-[11px] text-neutral-600 dark:text-neutral-400 flex items-start gap-1.5">
                      <span className="text-[#A85C43]">•</span>
                      <span>{ev}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Interpretation B */}
            <div className="p-5 bg-[#FCFBF8] dark:bg-[#161E24]">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-purple-50 dark:bg-purple-950/40 text-purple-800 dark:text-purple-300 border border-purple-200 dark:border-purple-800">
                  {isEn ? 'INTERPRETATION B' : 'விளக்கம் B'}
                </span>
                <span className="text-[11px] font-mono text-neutral-500">{debate.interpretationB.date}</span>
              </div>

              <div
                onClick={() => onSelectScholar && onSelectScholar(debate.interpretationB.scholar)}
                className="font-serif font-bold text-neutral-900 dark:text-white text-sm hover:text-[#A85C43] cursor-pointer transition-colors"
              >
                {debate.interpretationB.scholar}
              </div>
              <div className="text-xs text-neutral-500 dark:text-neutral-400 italic mb-3 font-scholarly">
                {debate.interpretationB.publication}
              </div>

              <p className="text-xs text-neutral-700 dark:text-neutral-300 leading-relaxed mb-4">
                {debate.interpretationB.argument}
              </p>

              <div>
                <div className="text-[10px] font-mono uppercase text-neutral-400 font-semibold mb-1">
                  {isEn ? 'Evidence Mobilized:' : 'பயன்படுத்தப்பட்ட சான்றுகள்:'}
                </div>
                <ul className="space-y-1">
                  {debate.interpretationB.evidenceUsed.map((ev, i) => (
                    <li key={i} className="text-[11px] text-neutral-600 dark:text-neutral-400 flex items-start gap-1.5">
                      <span className="text-[#9B8060]">•</span>
                      <span>{ev}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* Synthesis Bottom Footer */}
          <div className="p-4 bg-[#F5F1E6] dark:bg-[#131A20] border-t border-[#E5DFC8] dark:border-[#2D3842] grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-neutral-900 dark:text-neutral-100 uppercase tracking-wide text-[10px] block font-mono">
                  {isEn ? 'WHAT IS AGREED UPON' : 'ஒப்புக்கொள்ளப்பட்டவை'}
                </span>
                <p className="text-neutral-700 dark:text-neutral-300 mt-0.5 leading-snug">
                  {debate.whatIsAgreedUpon}
                </p>
              </div>
            </div>

            <div className="flex items-start gap-2">
              <HelpCircle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-neutral-900 dark:text-neutral-100 uppercase tracking-wide text-[10px] block font-mono">
                  {isEn ? 'WHAT REMAINS DEBATED' : 'விவாதத்திலுள்ளவை'}
                </span>
                <p className="text-neutral-700 dark:text-neutral-300 mt-0.5 leading-snug">
                  {debate.whatRemainsDebated}
                </p>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};
