import React, { useState } from 'react';
import { TimelineItem } from '../types/research';
import { Calendar, ChevronRight, Filter } from 'lucide-react';

interface ResearchTimelineProps {
  timeline: TimelineItem[];
  onSelectItem?: (item: TimelineItem) => void;
  language: 'ta' | 'en';
}

export const ResearchTimeline: React.FC<ResearchTimelineProps> = ({
  timeline,
  onSelectItem,
  language
}) => {
  const [activeEraFilter, setActiveEraFilter] = useState<'All' | 'Ancient' | 'Medieval' | 'Early Modern' | 'Modern'>('All');
  const isEn = language === 'en';

  if (!timeline || timeline.length === 0) return null;

  const eras = [
    { id: 'All', labelEn: 'All', labelTa: 'அனைத்தும்' },
    { id: 'Ancient', labelEn: 'Ancient', labelTa: 'பண்டைய காலம்' },
    { id: 'Medieval', labelEn: 'Medieval', labelTa: 'இடைக்காலம்' },
    { id: 'Early Modern', labelEn: 'Early Modern', labelTa: 'முந்தைய நவீன காலம்' },
    { id: 'Modern', labelEn: 'Modern', labelTa: 'நவீன காலம்' }
  ] as const;

  const filteredTimeline = activeEraFilter === 'All'
    ? timeline
    : timeline.filter(t => t.era === activeEraFilter);

  const getEraColor = (era: string) => {
    switch (era) {
      case 'Ancient':
        return 'border-[#A85C43] text-[#A85C43] bg-[#A85C43]/10';
      case 'Medieval':
        return 'border-[#9B8060] text-[#9B8060] bg-[#9B8060]/10';
      case 'Early Modern':
        return 'border-[#354653] text-[#354653] bg-[#354653]/10 dark:text-[#8498A9]';
      case 'Modern':
      default:
        return 'border-neutral-500 text-neutral-600 bg-neutral-100 dark:text-neutral-300 dark:bg-neutral-800';
    }
  };

  return (
    <div className="bg-white dark:bg-[#1A2229] border border-[#E5DFC8] dark:border-[#2D3842] rounded-xl p-5 my-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 mb-4 border-b border-[#E5DFC8] dark:border-[#2D3842]">
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4 text-[#A85C43]" />
          <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-[#9B8060] dark:text-[#C4A57F]">
            {isEn ? 'RESEARCH CHRONOLOGY & STRATIGRAPHY' : 'வரலாற்றுக் காலவரிசை'}
          </h3>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1 text-[11px] font-mono">
          <span className="text-neutral-400 mr-1 hidden sm:inline">{isEn ? 'Era:' : 'காலகட்டம்:'}</span>
          {eras.map(era => (
            <button
              key={era.id}
              onClick={() => setActiveEraFilter(era.id as any)}
              className={`px-2 py-0.5 rounded transition-all cursor-pointer ${
                activeEraFilter === era.id
                  ? 'bg-[#171717] text-white dark:bg-white dark:text-black font-semibold'
                  : 'bg-[#F2EDE2] dark:bg-[#25303B] text-neutral-600 dark:text-neutral-400 hover:text-neutral-900'
              }`}
            >
              {isEn ? era.labelEn : era.labelTa}
            </button>
          ))}
        </div>
      </div>

      {/* Timeline Line & Items */}
      <div className="relative pl-6 sm:pl-8 before:absolute before:left-3 sm:before:left-4 before:top-2 before:bottom-2 before:w-0.5 before:bg-[#E5DFC8] dark:before:bg-[#2D3842]">
        <div className="space-y-6">
          {filteredTimeline.map((item) => (
            <div
              key={item.id}
              onClick={() => onSelectItem && onSelectItem(item)}
              className="relative group cursor-pointer"
            >
              {/* Timeline marker node */}
              <div className="absolute -left-6 sm:-left-8 top-1.5 w-3 h-3 rounded-full bg-white dark:bg-[#1A2229] border-2 border-[#A85C43] group-hover:scale-125 transition-transform group-hover:bg-[#A85C43]" />

              <div className="bg-[#FAF7F0] dark:bg-[#151D23] border border-[#E5DFC8] dark:border-[#2D3842] rounded-lg p-3.5 hover:border-[#A85C43] transition-all">
                <div className="flex flex-wrap items-center justify-between gap-2 mb-1">
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] font-mono font-bold uppercase px-1.5 py-0.2 rounded border ${getEraColor(item.era)}`}>
                      {item.era}
                    </span>
                    <span className="text-xs font-mono font-semibold text-[#A85C43] dark:text-[#D47B62]">
                      {item.dateLabel}
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-neutral-500 bg-neutral-200/60 dark:bg-neutral-800 px-1.5 py-0.2 rounded">
                    {item.category}
                  </span>
                </div>

                <h4 className="text-sm font-semibold text-neutral-900 dark:text-white font-serif group-hover:text-[#A85C43] transition-colors flex items-center justify-between">
                  <span>{language === 'ta' && item.tamilTitle ? item.tamilTitle : item.title}</span>
                  <ChevronRight className="w-3.5 h-3.5 text-neutral-400 group-hover:text-[#A85C43] group-hover:translate-x-0.5 transition-all" />
                </h4>

                <p className="text-xs text-neutral-600 dark:text-neutral-400 mt-1 leading-relaxed">
                  {item.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
