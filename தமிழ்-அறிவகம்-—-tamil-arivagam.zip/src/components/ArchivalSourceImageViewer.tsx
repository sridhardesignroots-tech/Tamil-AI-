import React, { useState, useRef } from 'react';
import { 
  ZoomIn, ZoomOut, Maximize2, Minimize2, Download, RotateCcw, 
  ExternalLink, X, ShieldCheck, Compass, Info, Move 
} from 'lucide-react';
import { ArchivalScanItem } from '../types/research';

interface ArchivalSourceImageViewerProps {
  item: ArchivalScanItem;
  isOpen: boolean;
  onClose: () => void;
  onOpenSourcePanel?: (sourceId: string) => void;
}

export const ArchivalSourceImageViewer: React.FC<ArchivalSourceImageViewerProps> = ({
  item,
  isOpen,
  onClose,
  onOpenSourcePanel
}) => {
  const [scale, setScale] = useState<number>(1);
  const [position, setPosition] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isFullScreen, setIsFullScreen] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'scan' | 'transcription' | 'details'>('scan');

  if (!isOpen) return null;

  const handleZoomIn = () => setScale(prev => Math.min(prev + 0.35, 4));
  const handleZoomOut = () => setScale(prev => Math.max(prev - 0.35, 0.5));
  const handleResetZoom = () => {
    setScale(1);
    setPosition({ x: 0, y: 0 });
  };
  const handleFitScreen = () => {
    setScale(0.85);
    setPosition({ x: 0, y: 0 });
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX - position.x, y: e.clientY - position.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    setPosition({
      x: e.clientX - dragStart.x,
      y: e.clientY - dragStart.y
    });
  };

  const handleMouseUp = () => setIsDragging(false);

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = item.highResUrl || item.imageUrl;
    link.download = `tamil-ai-archival-${item.id}.jpg`;
    link.target = '_blank';
    link.rel = 'noreferrer';
    link.click();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex flex-col overflow-hidden animate-fade-in select-none">
      {/* Top Header Bar */}
      <header className="h-16 px-6 bg-[#12161A] border-b border-neutral-800 flex items-center justify-between text-white shrink-0">
        <div className="flex items-center gap-3 min-w-0">
          <div className="px-2.5 py-1 rounded bg-emerald-950/80 border border-emerald-500/50 text-emerald-400 font-mono text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5 shrink-0">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>ORIGINAL / ARCHIVAL EVIDENCE</span>
          </div>

          <div className="truncate">
            <h2 className="text-sm font-serif font-bold text-neutral-100 truncate">
              {item.title}
            </h2>
            <div className="text-[11px] font-mono text-neutral-400 truncate flex items-center gap-2">
              <span>{item.sourceType}</span>
              <span>•</span>
              <span>{item.period}</span>
              <span>•</span>
              <span className="text-[#D4A373]">{item.script}</span>
            </div>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {/* Zoom controls */}
          <div className="flex items-center bg-neutral-900 border border-neutral-700 rounded-lg p-0.5 text-neutral-300">
            <button
              onClick={handleZoomOut}
              className="p-1.5 hover:text-white hover:bg-neutral-800 rounded transition-colors"
              title="Zoom Out"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <span className="px-2 text-xs font-mono">{Math.round(scale * 100)}%</span>
            <button
              onClick={handleZoomIn}
              className="p-1.5 hover:text-white hover:bg-neutral-800 rounded transition-colors"
              title="Zoom In"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
            <button
              onClick={handleResetZoom}
              className="px-2 py-1 text-[11px] font-mono hover:text-white hover:bg-neutral-800 rounded transition-colors"
              title="Reset Zoom to 100%"
            >
              100%
            </button>
            <button
              onClick={handleFitScreen}
              className="px-2 py-1 text-[11px] font-mono hover:text-white hover:bg-neutral-800 rounded transition-colors"
              title="Fit to Screen"
            >
              Fit
            </button>
          </div>

          {/* Download */}
          <button
            onClick={handleDownload}
            className="p-2 bg-neutral-900 border border-neutral-700 hover:border-neutral-500 rounded-lg text-neutral-300 hover:text-white transition-colors"
            title="Download Archival Scan"
          >
            <Download className="w-4 h-4" />
          </button>

          {/* Close */}
          <button
            onClick={onClose}
            className="p-2 bg-neutral-800 hover:bg-neutral-700 rounded-lg text-neutral-300 hover:text-white transition-colors ml-2"
            title="Close Viewer (Esc)"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Canvas & Inspection Area */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Interactive Viewer Viewport */}
        <div
          className="flex-1 bg-[#090C0E] relative overflow-hidden flex items-center justify-center cursor-grab active:cursor-grabbing"
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
        >
          {/* Authentic Scan Image */}
          <div
            style={{
              transform: `translate(${position.x}px, ${position.y}px) scale(${scale})`,
              transition: isDragging ? 'none' : 'transform 0.15s ease-out'
            }}
            className="max-w-none origin-center select-none"
          >
            <img
              src={item.highResUrl || item.imageUrl}
              alt={item.title}
              draggable={false}
              className="max-h-[80vh] max-w-[85vw] object-contain shadow-2xl rounded-sm border border-neutral-800"
            />
          </div>

          {/* Floating Pan Instructions */}
          <div className="absolute bottom-4 left-4 bg-black/70 backdrop-blur-xs border border-neutral-800 text-[11px] font-mono text-neutral-400 px-3 py-1.5 rounded-lg flex items-center gap-2 pointer-events-none">
            <Move className="w-3.5 h-3.5 text-[#D4A373]" />
            <span>Click & drag to pan • Scroll / +/- to zoom</span>
          </div>

          {/* Archival Authenticity Stamp */}
          <div className="absolute bottom-4 right-4 bg-emerald-950/80 border border-emerald-600/40 text-emerald-300 text-[10px] font-mono px-3 py-1.5 rounded-lg flex items-center gap-1.5 pointer-events-none">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>ORIGINAL ARTIFACT / VERIFIED ARCHIVAL SCAN</span>
          </div>
        </div>

        {/* Right Details & Epigraphy Sidebar */}
        <aside className="w-96 bg-[#12161A] border-l border-neutral-800 p-5 overflow-y-auto text-neutral-300 space-y-5 shrink-0">
          <div className="space-y-1">
            <div className="text-[10px] font-mono uppercase text-[#D4A373] font-bold">
              EPIGRAPHICAL & ARCHIVAL PROVENANCE
            </div>
            <h3 className="text-base font-serif font-bold text-white">
              {item.title}
            </h3>
          </div>

          {/* Metadata pill list */}
          <div className="p-3 bg-neutral-900/90 rounded-xl border border-neutral-800 space-y-2 text-xs font-mono">
            <div className="flex justify-between border-b border-neutral-800 pb-1.5">
              <span className="text-neutral-500">Source Type:</span>
              <span className="text-neutral-200">{item.sourceType}</span>
            </div>
            <div className="flex justify-between border-b border-neutral-800 pb-1.5">
              <span className="text-neutral-500">Period / Date:</span>
              <span className="text-neutral-200">{item.period}</span>
            </div>
            <div className="flex justify-between border-b border-neutral-800 pb-1.5">
              <span className="text-neutral-500">Script:</span>
              <span className="text-[#D4A373]">{item.script}</span>
            </div>
            <div className="flex justify-between border-b border-neutral-800 pb-1.5">
              <span className="text-neutral-500">Findspot / Site:</span>
              <span className="text-neutral-200">{item.location}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-500">Repository:</span>
              <span className="text-neutral-200 truncate max-w-[180px]">{item.repository}</span>
            </div>
          </div>

          {/* Epigraphical Transcription */}
          <div className="space-y-2">
            <div className="text-[11px] font-mono uppercase text-neutral-400 font-bold flex items-center gap-1.5">
              <span>Original Epigraphical Text / Transcription</span>
            </div>
            <div className="p-3 bg-[#181F26] rounded-xl border border-neutral-700/80 font-tamil-serif text-sm text-neutral-100 leading-relaxed tracking-wide">
              {item.transcription}
            </div>
          </div>

          {/* Modern Tamil Translation */}
          <div className="space-y-1.5">
            <div className="text-[11px] font-mono uppercase text-[#D4A373] font-bold">
              நவீன தமிழ் விளக்கம் (Modern Tamil)
            </div>
            <p className="text-xs font-tamil text-neutral-300 leading-relaxed p-3 bg-neutral-900/60 rounded-xl border border-neutral-800">
              {item.modernTamilTranslation}
            </p>
          </div>

          {/* English Translation */}
          <div className="space-y-1.5">
            <div className="text-[11px] font-mono uppercase text-neutral-400 font-bold">
              English Academic Translation
            </div>
            <p className="text-xs text-neutral-300 font-serif leading-relaxed p-3 bg-neutral-900/60 rounded-xl border border-neutral-800">
              {item.englishTranslation}
            </p>
          </div>

          {/* What It Establishes */}
          <div className="p-3 bg-emerald-950/30 border border-emerald-700/40 rounded-xl space-y-1 text-xs">
            <div className="font-mono text-[10px] uppercase font-bold text-emerald-400">
              What This Primary Source Establishes
            </div>
            <p className="text-neutral-300 leading-relaxed">
              {item.whatItEstablishes}
            </p>
          </div>

          {/* Citation Reference */}
          <div className="text-[10px] font-mono text-neutral-500 pt-2 border-t border-neutral-800">
            Citation: {item.citationReference}
          </div>
        </aside>
      </div>
    </div>
  );
};
