import React from 'react';
import { BookRecord } from '../types/research';
import { BookOpen, ExternalLink, Bookmark, Check } from 'lucide-react';

interface RelatedBooksListProps {
  books: BookRecord[];
  onSelectBook: (book: BookRecord) => void;
  savedBookIds?: string[];
  onToggleSaveBook?: (bookId: string) => void;
  language?: 'ta' | 'en';
}

export const RelatedBooksList: React.FC<RelatedBooksListProps> = ({
  books,
  onSelectBook,
  savedBookIds = [],
  onToggleSaveBook,
  language = 'ta'
}) => {
  const isEn = language === 'en';
  if (!books || books.length === 0) return null;

  return (
    <section className="space-y-4">
      <div className="flex items-center justify-between pb-1 border-b border-[#E5DFC8] dark:border-[#2D3842]">
        <div className="flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-[#A85C43]" />
          <h2 className="text-xs font-mono font-bold uppercase tracking-wider text-neutral-900 dark:text-neutral-100">
            {isEn ? 'RELATED BOOKS & SCHOLARLY RESEARCH' : 'தொடர்புடைய ஆராய்ச்சி நூல்கள்'}
          </h2>
        </div>
        <span className="text-[11px] font-mono text-[#9B8060]">
          {isEn ? `${books.length} Published Monographs` : `${books.length} ஆய்வு நூல்கள்`}
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {books.map((book) => {
          const isSaved = savedBookIds.includes(book.id);

          return (
            <div
              key={book.id}
              onClick={() => onSelectBook(book)}
              className="p-4 rounded-xl bg-white dark:bg-[#1A2229] border border-[#E5DFC8] dark:border-[#2D3842] hover:border-[#A85C43] dark:hover:border-[#D47B62] transition-all cursor-pointer group shadow-2xs flex flex-col justify-between gap-3 text-left relative"
            >
              <div className="flex gap-3.5">
                {/* Book Spine / Cover Mockup */}
                <div className="w-16 h-22 rounded-md bg-gradient-to-br from-[#8C3A27] to-[#5A2518] text-amber-100 p-1.5 flex flex-col justify-between shrink-0 shadow-sm border border-amber-900/30 overflow-hidden relative">
                  <div className="w-1.5 h-full absolute left-0 top-0 bg-black/20" />
                  <span className="text-[8px] font-mono uppercase tracking-widest text-amber-200/80 truncate pl-1">
                    TAMIL AI
                  </span>
                  <div className="font-serif text-[10px] font-bold leading-tight line-clamp-3 pl-1">
                    {book.title}
                  </div>
                  <span className="text-[8px] font-mono text-amber-300/80 pl-1">
                    {book.publicationYear}
                  </span>
                </div>

                {/* Book Metadata */}
                <div className="min-w-0 flex-1 space-y-1">
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="text-sm font-serif font-bold text-neutral-900 dark:text-white group-hover:text-[#A85C43] dark:group-hover:text-[#D47B62] transition-colors leading-snug">
                      {book.title}
                    </h3>
                  </div>

                  {book.tamilTitle && (
                    <div className="text-xs font-tamil text-[#9B8060] dark:text-[#C4A57F]">
                      {book.tamilTitle}
                    </div>
                  )}

                  <div className="text-xs text-neutral-600 dark:text-neutral-400 font-sans">
                    {isEn ? 'By ' : 'ஆசிரியர்: '}<span className="font-semibold text-neutral-800 dark:text-neutral-200">{book.author}</span> ({book.publicationYear})
                  </div>

                  {book.publisher && (
                    <div className="text-[10px] font-mono text-neutral-400 truncate">
                      {isEn ? 'Publisher: ' : 'வெளியீடு: '}{book.publisher}
                    </div>
                  )}

                  <div className="text-[10px] font-mono px-2 py-0.5 rounded bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300 inline-block">
                    {book.subject}
                  </div>
                </div>
              </div>

              {/* Why Relevant & Passage */}
              <div className="pt-2 border-t border-[#E5DFC8]/60 dark:border-[#2D3842] space-y-1 text-xs">
                <div className="text-neutral-700 dark:text-neutral-300 leading-relaxed font-sans">
                  <strong className="text-neutral-900 dark:text-white font-semibold">{isEn ? 'Why Relevant: ' : 'முக்கியத்துவம்: '}</strong> {book.whyRelevant}
                </div>

                {book.relevantPassageOrPage && (
                  <div className="text-[11px] font-serif italic text-[#A85C43] dark:text-[#D47B62] bg-[#FAF7F0] dark:bg-[#151D23] p-2 rounded border border-[#E5DFC8]/60 dark:border-[#2D3842]">
                    “{book.relevantPassageOrPage}”
                  </div>
                )}

                <div className="flex items-center justify-between text-[10px] font-mono text-neutral-400 pt-1">
                  <span>Ref: {book.referenceSource}</span>
                  <span className="text-[#A85C43] flex items-center gap-1 group-hover:underline">
                    <span>{isEn ? 'Inspect Book Details' : 'நூல் விவரங்கள்'}</span>
                    <ExternalLink className="w-3 h-3" />
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
