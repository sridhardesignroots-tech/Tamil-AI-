import React, { useState } from 'react';
import { PrimaryText } from '../types/research';
import { BookOpen, Copy, Check, ExternalLink, Globe, Sparkles, BookMarked } from 'lucide-react';

interface PrimaryTextViewerProps {
  primaryTexts: PrimaryText[];
  onSelectEntity?: (type: 'source' | 'primaryText', id: string, data: any) => void;
  language: 'ta' | 'en';
}

export const PrimaryTextViewer: React.FC<PrimaryTextViewerProps> = ({
  primaryTexts,
  onSelectEntity,
  language
}) => {
  const [activeTab, setActiveTab] = useState<'original' | 'modern' | 'english' | 'compare'>('original');
  const [activeTextIndex, setActiveTextIndex] = useState(0);
  const [showTransliteration, setShowTransliteration] = useState(false);
  const [showGlossary, setShowGlossary] = useState(true);
  const [copied, setCopied] = useState(false);
  const isEn = language === 'en';

  if (!primaryTexts || primaryTexts.length === 0) return null;

  const currentText = primaryTexts[activeTextIndex] || primaryTexts[0];

  const handleCopy = () => {
    let textToCopy = currentText.originalTamil;
    if (activeTab === 'modern') textToCopy = currentText.modernTamil;
    if (activeTab === 'english') textToCopy = currentText.englishTranslation;
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-white dark:bg-[#1A2229] border border-[#E5DFC8] dark:border-[#2D3842] rounded-xl overflow-hidden shadow-xs my-6 transition-all">
      {/* Header Bar */}
      <div className="bg-[#FAF7F0] dark:bg-[#141B20] px-5 py-3.5 border-b border-[#E5DFC8] dark:border-[#2D3842] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-[#A85C43]/10 text-[#A85C43] flex items-center justify-center font-serif text-sm font-bold border border-[#A85C43]/20">
            தமிழ்
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono uppercase tracking-widest text-[#9B8060] dark:text-[#C4A57F] font-bold">
                {isEn ? 'PRIMARY TEXTUAL EVIDENCE' : 'முதன்மை இலக்கியச் சான்று'}
              </span>
              <span className="inline-block px-1.5 py-0.2 text-[9px] font-mono bg-emerald-100 dark:bg-emerald-900/40 text-emerald-800 dark:text-emerald-300 rounded border border-emerald-300 dark:border-emerald-700">
                {isEn ? 'VERIFIED CORPUS' : 'சரிபார்க்கப்பட்ட மூலம்'}
              </span>
            </div>
            <h3 className="text-sm font-semibold text-neutral-900 dark:text-white font-serif">
              {currentText.work} — {currentText.title}
            </h3>
          </div>
        </div>

        {/* Text selector if multiple */}
        {primaryTexts.length > 1 && (
          <div className="flex items-center bg-[#EFE9DB] dark:bg-[#232D37] p-0.5 rounded-lg border border-[#E5DFC8] dark:border-[#354350] text-xs">
            {primaryTexts.map((pt, i) => (
              <button
                key={pt.id}
                onClick={() => setActiveTextIndex(i)}
                className={`px-2.5 py-1 rounded text-xs font-medium transition-colors cursor-pointer ${
                  activeTextIndex === i
                    ? 'bg-white dark:bg-[#161D24] text-[#A85C43] dark:text-[#D47B62] shadow-xs'
                    : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900'
                }`}
              >
                {isEn ? `Passage ${i + 1}` : `பாடல் ${i + 1}`}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Metadata Bar */}
      <div className="px-5 py-2.5 bg-[#F6F2E8] dark:bg-[#171F26] border-b border-[#E5DFC8]/60 dark:border-[#2D3842] flex flex-wrap items-center justify-between text-xs text-neutral-600 dark:text-neutral-400 gap-y-2">
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
          <div>
            <span className="font-semibold text-neutral-800 dark:text-neutral-300">{isEn ? 'Period: ' : 'காலம்: '}</span>
            <span className="font-mono">{currentText.period}</span>
          </div>
          <span className="text-[#9B8060]">•</span>
          <div>
            <span className="font-semibold text-neutral-800 dark:text-neutral-300">{isEn ? 'Reference: ' : 'சான்றுக் குறிப்பு: '}</span>
            <span className="font-mono text-[#A85C43] dark:text-[#D47B62] font-semibold">{currentText.reference}</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {currentText.phoneticTransliteration && (
            <button
              onClick={() => setShowTransliteration(!showTransliteration)}
              className={`text-[11px] px-2 py-0.5 rounded border transition-colors flex items-center gap-1 cursor-pointer ${
                showTransliteration
                  ? 'bg-[#A85C43] text-white border-[#A85C43]'
                  : 'bg-white dark:bg-[#202932] border-[#E5DFC8] dark:border-[#374552] text-neutral-700 dark:text-neutral-300 hover:border-[#A85C43]'
              }`}
              title="Toggle Latin script phonetic transliteration"
            >
              <Globe className="w-3 h-3" />
              {isEn ? 'Latin Transliteration' : 'ஒலிபெயர்ப்பு'}
            </button>
          )}
          <button
            onClick={handleCopy}
            className="text-[11px] px-2 py-0.5 rounded border border-[#E5DFC8] dark:border-[#374552] bg-white dark:bg-[#202932] text-neutral-700 dark:text-neutral-300 hover:border-[#A85C43] transition-colors flex items-center gap-1 cursor-pointer"
          >
            {copied ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
            {copied ? (isEn ? 'Copied' : 'நகலெடுக்கப்பட்டது') : (isEn ? 'Copy' : 'நகலெடு')}
          </button>
          {onSelectEntity && (
            <button
              onClick={() => onSelectEntity('primaryText', currentText.id, currentText)}
              className="text-[11px] text-[#A85C43] dark:text-[#D47B62] hover:underline flex items-center gap-1 font-medium cursor-pointer"
            >
              {isEn ? 'Inspect in Lens' : 'சான்று ஆய்வகம்'} <ExternalLink className="w-3 h-3" />
            </button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="px-5 pt-3 border-b border-[#E5DFC8] dark:border-[#2D3842] flex items-center gap-1 bg-[#FAF7F0]/50 dark:bg-[#151D22]">
        <button
          onClick={() => setActiveTab('original')}
          className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider border-b-2 transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'original'
              ? 'border-[#A85C43] text-[#A85C43] dark:text-[#D47B62] bg-white dark:bg-[#1A2229]'
              : 'border-transparent text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200'
          }`}
        >
          <span className="w-1.5 h-1.5 rounded-full bg-[#A85C43]" />
          {isEn ? 'ORIGINAL TAMIL' : 'அசல் தமிழ் மூலம்'}
        </button>

        <button
          onClick={() => setActiveTab('modern')}
          className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider border-b-2 transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'modern'
              ? 'border-[#A85C43] text-[#A85C43] dark:text-[#D47B62] bg-white dark:bg-[#1A2229]'
              : 'border-transparent text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200'
          }`}
        >
          {isEn ? 'MODERN TAMIL' : 'நவீன தமிழ் உரை'}
        </button>

        <button
          onClick={() => setActiveTab('english')}
          className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider border-b-2 transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'english'
              ? 'border-[#A85C43] text-[#A85C43] dark:text-[#D47B62] bg-white dark:bg-[#1A2229]'
              : 'border-transparent text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200'
          }`}
        >
          {isEn ? 'ENGLISH TRANSLATION' : 'ஆங்கில மொழிபெயர்ப்பு'}
        </button>

        <button
          onClick={() => setActiveTab('compare')}
          className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider border-b-2 transition-all flex items-center gap-1.5 ml-auto cursor-pointer ${
            activeTab === 'compare'
              ? 'border-[#9B8060] text-[#9B8060] bg-white dark:bg-[#1A2229]'
              : 'border-transparent text-neutral-500 hover:text-neutral-800'
          }`}
        >
          <BookMarked className="w-3.5 h-3.5" />
          {isEn ? 'PARALLEL VIEW' : 'ஒப்பீட்டுப் பார்வை'}
        </button>
      </div>

      {/* Distinction Banner when viewing translations */}
      {activeTab !== 'original' && activeTab !== 'compare' && (
        <div className="bg-amber-50 dark:bg-amber-950/20 border-b border-amber-200/60 dark:border-amber-900/30 px-5 py-2 text-[11px] text-amber-900 dark:text-amber-300 font-mono flex items-center justify-between">
          <span className="font-semibold uppercase tracking-wider">
            {isEn ? 'TRANSLATION / EXPLANATION — NOT THE ORIGINAL TEXT' : 'விளக்க உரை — அசல் பாடல் அல்ல'}
          </span>
          <span className="text-[10px] opacity-80">
            {isEn ? 'Rendered for scholarly comprehension' : 'ஆராய்ச்சி புரிதலுக்காக வழங்கப்பட்டுள்ளது'}
          </span>
        </div>
      )}

      {/* Main Content Body */}
      <div className="p-6">
        {activeTab === 'original' && (
          <div className="space-y-4">
            <div className="font-tamil-serif text-lg leading-loose text-neutral-900 dark:text-neutral-100 whitespace-pre-line pl-4 border-l-2 border-[#A85C43]">
              {currentText.originalTamil}
            </div>

            {showTransliteration && currentText.phoneticTransliteration && (
              <div className="mt-4 pt-4 border-t border-neutral-200 dark:border-neutral-800">
                <div className="text-[11px] font-mono uppercase text-neutral-500 mb-1">
                  {isEn ? 'Phonetic Transliteration (ISO 15919 Standard):' : 'ஒலிபெயர்ப்பு (ISO 15919):'}
                </div>
                <div className="font-mono text-sm leading-relaxed text-neutral-700 dark:text-neutral-300 whitespace-pre-line italic bg-[#FBF9F4] dark:bg-[#13191E] p-3 rounded border border-[#E5DFC8] dark:border-[#2D3842]">
                  {currentText.phoneticTransliteration}
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'modern' && (
          <div className="space-y-3">
            <div className="font-tamil text-base leading-relaxed text-neutral-800 dark:text-neutral-200 whitespace-pre-line pl-4 border-l-2 border-[#9B8060]">
              {currentText.modernTamil}
            </div>
          </div>
        )}

        {activeTab === 'english' && (
          <div className="space-y-3">
            <div className="font-scholarly text-base leading-relaxed text-neutral-800 dark:text-neutral-200 whitespace-pre-line pl-4 border-l-2 border-[#354653] italic">
              "{currentText.englishTranslation}"
            </div>
          </div>
        )}

        {activeTab === 'compare' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-3 bg-[#FAF7F0] dark:bg-[#151D23] rounded-lg border border-[#E5DFC8] dark:border-[#2D3842]">
              <div className="text-[10px] font-mono font-bold uppercase text-[#A85C43] mb-2 pb-1 border-b border-[#E5DFC8] dark:border-[#2D3842]">
                {isEn ? 'ORIGINAL TAMIL' : 'அசல் தமிழ்'}
              </div>
              <div className="font-tamil-serif text-sm leading-loose text-neutral-900 dark:text-neutral-100 whitespace-pre-line">
                {currentText.originalTamil}
              </div>
            </div>

            <div className="p-3 bg-[#FAF7F0] dark:bg-[#151D23] rounded-lg border border-[#E5DFC8] dark:border-[#2D3842]">
              <div className="text-[10px] font-mono font-bold uppercase text-[#9B8060] mb-2 pb-1 border-b border-[#E5DFC8] dark:border-[#2D3842]">
                {isEn ? 'MODERN TAMIL' : 'நவீன உரை'}
              </div>
              <div className="font-tamil text-xs leading-relaxed text-neutral-800 dark:text-neutral-200 whitespace-pre-line">
                {currentText.modernTamil}
              </div>
            </div>

            <div className="p-3 bg-[#FAF7F0] dark:bg-[#151D23] rounded-lg border border-[#E5DFC8] dark:border-[#2D3842]">
              <div className="text-[10px] font-mono font-bold uppercase text-[#354653] dark:text-[#8498A9] mb-2 pb-1 border-b border-[#E5DFC8] dark:border-[#2D3842]">
                {isEn ? 'ENGLISH TRANSLATION' : 'ஆங்கில உரை'}
              </div>
              <div className="font-scholarly text-xs leading-relaxed text-neutral-800 dark:text-neutral-200 italic whitespace-pre-line">
                "{currentText.englishTranslation}"
              </div>
            </div>
          </div>
        )}

        {/* Lexical Terminology Breakdown */}
        {currentText.lexicalBreakdown && currentText.lexicalBreakdown.length > 0 && (
          <div className="mt-6 pt-4 border-t border-[#E5DFC8] dark:border-[#2D3842]">
            <div className="flex items-center justify-between mb-2.5">
              <span className="text-[11px] font-mono uppercase tracking-wider font-semibold text-neutral-700 dark:text-neutral-300">
                {isEn ? 'Lexical & Historical Glossary' : 'அருஞ்சொற்பொருள் & வரலாற்று விளக்கம்'}
              </span>
              <button
                onClick={() => setShowGlossary(!showGlossary)}
                className="text-[10px] text-[#A85C43] dark:text-[#D47B62] hover:underline cursor-pointer"
              >
                {showGlossary ? (isEn ? 'Hide Details' : 'மறைக்க') : (isEn ? 'Show Terms' : 'காட்டுக')}
              </button>
            </div>

            {showGlossary && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {currentText.lexicalBreakdown.map((item, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 rounded bg-[#F8F5ED] dark:bg-[#141B20] border border-[#E5DFC8]/80 dark:border-[#2A343F] text-xs"
                  >
                    <div className="font-semibold text-neutral-900 dark:text-neutral-100 font-tamil mb-0.5">
                      {item.term}
                    </div>
                    <div className="text-neutral-600 dark:text-neutral-400 text-[11px] leading-normal">
                      {item.meaning}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Provenance Footer */}
        <div className="mt-4 pt-3 border-t border-[#E5DFC8]/50 dark:border-[#2D3842]/50 text-[11px] text-neutral-500 dark:text-neutral-400 flex items-start gap-2">
          <BookOpen className="w-3.5 h-3.5 text-[#9B8060] shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold text-neutral-700 dark:text-neutral-300">
              {isEn ? 'Provenance & Manuscript Note: ' : 'சுவடி / பதிப்பு மூலக் குறிப்பு: '}
            </span>
            {currentText.provenanceNotes}
          </div>
        </div>
      </div>
    </div>
  );
};
