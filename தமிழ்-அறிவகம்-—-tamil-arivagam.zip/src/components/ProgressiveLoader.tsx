import React, { useState, useEffect } from 'react';

interface ProgressiveLoaderProps {
  onComplete?: () => void;
  language?: 'ta' | 'en';
}

const STAGES = [
  {
    tamil: 'கேள்வியைப் புரிந்துகொள்கிறோம்...',
    english: 'Understanding your inquiry...',
    duration: 650
  },
  {
    tamil: 'முதன்மை ஆவணங்களைத் தேடுகிறோம்...',
    english: 'Examining primary sources and archives...',
    duration: 850
  },
  {
    tamil: 'சான்றுகளைத் தொகுக்கிறோம்...',
    english: 'Synthesizing verified scholarly evidence...',
    duration: 750
  }
];

export const ProgressiveLoader: React.FC<ProgressiveLoaderProps> = ({ onComplete, language = 'ta' }) => {
  const [currentStage, setCurrentStage] = useState<number>(0);
  const isEn = language === 'en';

  useEffect(() => {
    const timer1 = setTimeout(() => {
      setCurrentStage(1);
    }, STAGES[0].duration);

    const timer2 = setTimeout(() => {
      setCurrentStage(2);
    }, STAGES[0].duration + STAGES[1].duration);

    const timer3 = setTimeout(() => {
      if (onComplete) onComplete();
    }, STAGES[0].duration + STAGES[1].duration + STAGES[2].duration);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
    };
  }, [onComplete]);

  const stage = STAGES[currentStage] || STAGES[0];

  return (
    <div className="max-w-[680px] mx-auto py-24 sm:py-32 px-6 flex flex-col items-center justify-center text-center space-y-6 animate-fadeIn">
      {/* Calm, quiet indicator dots */}
      <div className="flex items-center gap-2">
        {STAGES.map((_, idx) => (
          <span
            key={idx}
            className={`h-1.5 rounded-full transition-all duration-300 ${
              idx === currentStage
                ? 'w-8 bg-[#8B3A1C] dark:bg-[#E07A5F]'
                : idx < currentStage
                ? 'w-3 bg-[#C7BAA7] dark:bg-[#475569]'
                : 'w-2 bg-[#E7E2D8] dark:bg-[#27323C]'
            }`}
          />
        ))}
      </div>

      {/* Main calm text */}
      <div className="space-y-2">
        <h2 className="text-xl sm:text-2xl font-serif font-bold text-[#1C1917] dark:text-[#F8FAFC] tracking-tight transition-opacity duration-300">
          {isEn ? stage.english : stage.tamil}
        </h2>
        <p className="text-xs font-mono text-[#78716C] dark:text-[#94A3B8]">
          {isEn ? stage.tamil : stage.english}
        </p>
      </div>

      <div className="text-[11px] font-mono text-[#A8A29E] dark:text-[#64748B]">
        {isEn ? 'Tamil AI · Digital Research Archive' : 'தமிழ் AI · வரலாற்று ஆய்வுப் பெட்டகம்'}
      </div>
    </div>
  );
};
