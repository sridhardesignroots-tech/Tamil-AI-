import React, { useState } from 'react';
import { KnowledgeNode, KnowledgeEdge } from '../types/research';
import { Network, ArrowRight, BookOpen, User, Landmark, FileText, HelpCircle, Compass } from 'lucide-react';

interface KnowledgeMapProps {
  nodes: KnowledgeNode[];
  edges: KnowledgeEdge[];
  onSelectNode?: (node: KnowledgeNode) => void;
  language: 'ta' | 'en' | 'mixed';
}

export const KnowledgeMap: React.FC<KnowledgeMapProps> = ({
  nodes,
  edges,
  onSelectNode,
  language
}) => {
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(nodes[0]?.id || null);

  if (!nodes || nodes.length === 0) return null;

  const selectedNode = nodes.find(n => n.id === selectedNodeId) || nodes[0];

  const getNodeIcon = (type: string) => {
    switch (type) {
      case 'question':
        return <HelpCircle className="w-3.5 h-3.5 text-[#A85C43]" />;
      case 'terminology':
        return <FileText className="w-3.5 h-3.5 text-amber-600" />;
      case 'literature':
        return <BookOpen className="w-3.5 h-3.5 text-blue-600" />;
      case 'inscription':
        return <Landmark className="w-3.5 h-3.5 text-purple-600" />;
      case 'site':
        return <Compass className="w-3.5 h-3.5 text-emerald-600" />;
      case 'scholar':
        return <User className="w-3.5 h-3.5 text-neutral-700 dark:text-neutral-300" />;
      case 'publication':
        return <FileText className="w-3.5 h-3.5 text-indigo-600" />;
      default:
        return <Network className="w-3.5 h-3.5 text-neutral-500" />;
    }
  };

  const getNodeBadgeClass = (type: string, isSelected: boolean) => {
    if (isSelected) {
      return 'border-[#A85C43] bg-white dark:bg-[#202A34] shadow-sm ring-2 ring-[#A85C43]/20';
    }
    return 'border-[#E5DFC8] dark:border-[#2D3842] bg-[#FAF7F0] dark:bg-[#151D23] hover:border-[#9B8060]';
  };

  return (
    <div className="bg-white dark:bg-[#1A2229] border border-[#E5DFC8] dark:border-[#2D3842] rounded-xl p-5 my-6">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 mb-4 border-b border-[#E5DFC8] dark:border-[#2D3842]">
        <div className="flex items-center gap-2">
          <Network className="w-4 h-4 text-[#A85C43]" />
          <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-[#9B8060] dark:text-[#C4A57F]">
            {language === 'ta' ? 'அறிவுத் தொடர்பு வரைபடம் (KNOWLEDGE CONNECTIONS)' : 'EVIDENTIARY RELATIONSHIP GRAPH'}
          </h3>
        </div>
        <span className="text-[11px] text-neutral-500 font-mono">
          {nodes.length} Nodes • {edges.length} Verified Links
        </span>
      </div>

      {/* Graph Node Flow / Chain */}
      <div className="overflow-x-auto pb-3 mb-4">
        <div className="flex items-center gap-2 min-w-max py-2">
          {nodes.map((node, index) => {
            const isSelected = node.id === selectedNodeId;
            return (
              <React.Fragment key={node.id}>
                <button
                  onClick={() => {
                    setSelectedNodeId(node.id);
                    if (onSelectNode) onSelectNode(node);
                  }}
                  className={`px-3 py-2 rounded-lg border text-left transition-all flex flex-col min-w-[140px] max-w-[190px] cursor-pointer ${getNodeBadgeClass(
                    node.type,
                    isSelected
                  )}`}
                >
                  <div className="flex items-center justify-between gap-1 mb-1">
                    <span className="flex items-center gap-1 text-[9px] font-mono uppercase tracking-wider text-neutral-500 dark:text-neutral-400">
                      {getNodeIcon(node.type)}
                      {node.type}
                    </span>
                    {isSelected && (
                      <span className="w-1.5 h-1.5 rounded-full bg-[#A85C43]" />
                    )}
                  </div>
                  <div className="text-xs font-semibold text-neutral-900 dark:text-neutral-100 truncate">
                    {language === 'ta' && node.tamilLabel ? node.tamilLabel : node.label}
                  </div>
                </button>

                {index < nodes.length - 1 && (
                  <div className="flex items-center text-neutral-300 dark:text-neutral-600 px-0.5">
                    <ArrowRight className="w-3.5 h-3.5" />
                  </div>
                )}
              </React.Fragment>
            );
          })}
        </div>
      </div>

      {/* Selected Node Detail Callout */}
      {selectedNode && (
        <div className="bg-[#FAF7F0] dark:bg-[#141B20] border border-[#E5DFC8] dark:border-[#2D3842] rounded-lg p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="space-y-0.5">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono uppercase font-bold text-[#A85C43] dark:text-[#D47B62]">
                NODE TYPE: {selectedNode.type}
              </span>
              <span className="text-neutral-400">•</span>
              <span className="font-serif font-semibold text-neutral-900 dark:text-white">
                {selectedNode.label}
              </span>
            </div>
            <p className="text-neutral-600 dark:text-neutral-300 text-xs">
              {selectedNode.description}
            </p>
          </div>

          <button
            onClick={() => onSelectNode && onSelectNode(selectedNode)}
            className="shrink-0 px-3 py-1.5 rounded bg-white dark:bg-[#202932] border border-[#E5DFC8] dark:border-[#374552] text-[11px] font-medium text-neutral-800 dark:text-neutral-200 hover:border-[#A85C43] transition-colors"
          >
            Inspect in Lens →
          </button>
        </div>
      )}
    </div>
  );
};
