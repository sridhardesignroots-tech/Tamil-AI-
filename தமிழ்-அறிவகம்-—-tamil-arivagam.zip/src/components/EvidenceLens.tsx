import React, { useState } from 'react';
import { LensSelection, Scholar, SourceItem, BookRecord, ArchivalScanItem } from '../types/research';
import { 
  X, ExternalLink, BookOpen, User, ShieldCheck, AlertTriangle, 
  ZoomIn, ZoomOut, RotateCcw, Maximize2, Download, FileText, 
  MapPin, Calendar, Layers, Feather, Sparkles, CheckCircle2, ChevronRight
} from 'lucide-react';

interface EvidenceLensProps {
  isOpen: boolean;
  selection: LensSelection | null;
  onClose: () => void;
  onSelectEntity: (type: any, id: string, data: any) => void;
  language: 'ta' | 'en';
}

export const EvidenceLens: React.FC<EvidenceLensProps> = ({
  isOpen,
  selection,
  onClose,
  onSelectEntity,
  language
}) => {
  const [zoomScale, setZoomScale] = useState<number>(1);
  const [isFullScreen, setIsFullScreen] = useState<boolean>(false);
  const isEn = language === 'en';

  if (!isOpen) return null;

  // Determine Source Category for Section 10
  const getSourceCategory = (source: any) => {
    if (source.isAiGenerated || source.sourceType?.includes('AI') || source.type === 'ai_visualization') {
      return {
        label: isEn ? 'AI VISUALIZATION' : 'AI காட்சி விளக்கம்',
        bg: 'bg-purple-100 dark:bg-purple-950/60 text-purple-800 dark:text-purple-300 border-purple-300 dark:border-purple-800',
        desc: isEn ? 'Generated visual reconstruction — not historical evidence' : 'கற்பனை காட்சிப்படுத்தல் — நேரடி வரலாற்று ஆதாரம் அல்ல'
      };
    }
    if (source.sourceType?.includes('Interpretation') || source.type === 'ai_interpretation') {
      return {
        label: isEn ? 'AI INTERPRETATION' : 'AI ஆய்வு விளக்கம்',
        bg: 'bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border-amber-300 dark:border-amber-800',
        desc: isEn ? 'Synthesized scholarly interpretation' : 'தொகுக்கப்பட்ட ஆய்வுக் கருத்து'
      };
    }
    if (
      source.sourceType?.includes('Book') || 
      source.sourceType?.includes('Paper') || 
      source.sourceType?.includes('Monograph') ||
      source.publicationYear ||
      source.author?.includes('Prof.') ||
      source.author?.includes('Dr.')
    ) {
      return {
        label: isEn ? 'SECONDARY SOURCE' : 'இரண்டாம் நிலை ஆய்வு ஆதாரம்',
        bg: 'bg-blue-100 dark:bg-blue-950/60 text-blue-800 dark:text-blue-300 border-blue-300 dark:border-blue-800',
        desc: isEn ? 'Peer-reviewed academic monograph or historical paper' : 'கல்விப்புல ஆய்வு நூல் அல்லது ஆய்வுக் கட்டுரை'
      };
    }
    return {
      label: isEn ? 'PRIMARY SOURCE' : 'முதன்மை வரலாற்றுச் சான்று',
      bg: 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border-emerald-300 dark:border-emerald-800',
      desc: isEn ? 'Original inscription, palm-leaf manuscript, copper plate, or artefact' : 'அசல் கல்வெட்டு, ஓலைச்சுவடி, செப்பேடு அல்லது தொல்பொருள்'
    };
  };

  return (
    <aside className="w-full lg:w-[420px] xl:w-[460px] h-full bg-[#FAF8F5] dark:bg-[#12161A] border-l border-[#E7E2D8] dark:border-[#27323C] flex flex-col shrink-0 transition-all z-40 shadow-2xl overflow-hidden animate-fadeIn">
      {/* Top Header Bar */}
      <div className="h-16 px-5 border-b border-[#E7E2D8] dark:border-[#27323C] flex items-center justify-between bg-white dark:bg-[#161D24]">
        <div className="flex items-center gap-2.5">
          <span className="w-2 h-2 rounded-full bg-[#8B3A1C] dark:bg-[#E07A5F]" />
          <div className="text-xs font-mono font-bold uppercase tracking-wider text-[#1C1917] dark:text-[#F8FAFC]">
            {isEn ? 'Context Inspector' : 'சான்று ஆய்வகம்'}
          </div>
        </div>

        <button
          onClick={onClose}
          className="p-1.5 rounded-lg text-[#78716C] dark:text-[#94A3B8] hover:text-[#1C1917] dark:hover:text-[#F8FAFC] hover:bg-[#F2ECE1] dark:hover:bg-[#1E252D] transition-colors cursor-pointer"
          title={isEn ? 'Close Inspector' : 'மூடுக'}
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Independently Scrollable Body Area (Section 9) */}
      <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6 text-[#1C1917] dark:text-[#E2E8F0]">
        {!selection ? (
          <div className="py-20 flex flex-col items-center justify-center text-center space-y-3">
            <div className="w-12 h-12 rounded-xl bg-[#F0EAE1] dark:bg-[#1E252D] flex items-center justify-center text-[#8B3A1C] dark:text-[#E07A5F]">
              <BookOpen className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-serif font-bold">
              {isEn ? 'No Entity Selected' : 'எந்தச் சான்றும் தேர்ந்தெடுக்கப்படவில்லை'}
            </h4>
            <p className="text-xs text-[#78716C] dark:text-[#94A3B8] max-w-[280px] leading-relaxed">
              {isEn 
                ? 'Click any source badge [Source 01], scholar, book, or evidence image in the answer to inspect full archival provenance.' 
                : 'பதிலில் உள்ள எந்தவொரு [Source 01] சான்று, அறிஞர், நூல் அல்லது படத்தை கிளிக் செய்து அதன் அசல் ஆவணங்களை இங்கே ஆராயலாம்.'}
            </p>
          </div>
        ) : selection.type === 'scholar' ? (
          /* =================== SCHOLAR INSPECTOR (Section 13) =================== */
          <div className="space-y-6 text-left animate-fadeIn">
            {/* Scholar Header */}
            <div className="flex items-start gap-4">
              <div className="w-20 h-20 rounded-xl bg-[#1C1917] dark:bg-black border border-[#E7E2D8] dark:border-[#27323C] overflow-hidden flex flex-col items-center justify-center shrink-0 shadow-xs">
                {selection.data?.photoStatus === 'AUTHENTIC' && selection.data?.imageUrl ? (
                  <img
                    src={selection.data.imageUrl}
                    alt={selection.data.fullName}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="p-2 text-center text-[#78716C]">
                    <User className="w-6 h-6 mx-auto mb-1 opacity-70" />
                    <span className="text-[8px] font-mono uppercase block">{isEn ? 'Archival' : 'ஆவணப்'}</span>
                    <span className="text-[8px] font-mono uppercase block">{isEn ? 'Portrait' : 'படம்'}</span>
                  </div>
                )}
              </div>

              <div className="min-w-0 flex-1">
                <span className="text-[10px] font-mono uppercase tracking-wider font-bold px-2 py-0.5 rounded bg-[#8B3A1C]/10 text-[#8B3A1C] dark:text-[#E07A5F] inline-block mb-1">
                  {isEn ? 'HISTORIAN & RESEARCHER' : 'வரலாற்றறிஞர் / ஆய்வாளர்'}
                </span>
                <h2 className="text-lg font-serif font-bold leading-tight">
                  {selection.data?.fullName || selection.title}
                </h2>
                <div className="text-xs font-mono text-[#8B3A1C] dark:text-[#E07A5F] font-semibold mt-1">
                  {selection.data?.birthDeath || (isEn ? 'Contemporary Scholar' : 'தற்கால ஆய்வாளர்')}
                </div>
              </div>
            </div>

            {/* Field & Affiliation */}
            <div className="p-4 rounded-xl bg-white dark:bg-[#161D24] border border-[#E7E2D8] dark:border-[#27323C] space-y-2 text-xs">
              <div>
                <span className="font-mono text-[10px] uppercase text-[#78716C] dark:text-[#94A3B8] block">
                  {isEn ? 'Field of Research' : 'ஆய்வுப் புலம்'}
                </span>
                <span className="font-medium text-sm font-serif">{selection.data?.field || 'Tamil Historiography & Epigraphy'}</span>
              </div>
              <div className="pt-2 border-t border-[#E7E2D8] dark:border-[#27323C]">
                <span className="font-mono text-[10px] uppercase text-[#78716C] dark:text-[#94A3B8] block">
                  {isEn ? 'Institution / Affiliation' : 'கல்வி நிறுவனம் / பணி'}
                </span>
                <span className="text-[#57534E] dark:text-[#CBD5E1]">{selection.data?.institution || 'Academic Research Archive'}</span>
              </div>
            </div>

            {/* CRITICAL: Relevant to this answer (Section 13) */}
            <div className="p-4 rounded-xl bg-amber-50/70 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/50 space-y-1.5 text-xs">
              <div className="font-mono text-[10px] uppercase font-bold text-amber-900 dark:text-amber-300 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>{isEn ? 'Relevant to this answer' : 'இந்தக் கேள்விக்கான நேரடித் தொடர்பு'}</span>
              </div>
              <p className="text-[#292524] dark:text-[#E2E8F0] leading-relaxed font-serif">
                {selection.data?.relevanceToQuestion || 
                  (isEn 
                    ? 'This scholar authored foundational excavations and textual critical editions directly establishing the findings in this inquiry.' 
                    : 'இக்கேள்வியில் குறிப்பிடப்படும் சான்றுகள் மற்றும் மூலப் பாடங்களை உறுதிசெய்த முதன்மை ஆய்வாளர்.')}
              </p>
            </div>

            {/* Research Contribution */}
            {selection.data?.researchContribution && (
              <div className="space-y-1.5">
                <div className="text-[10px] font-mono uppercase text-[#78716C] dark:text-[#94A3B8] font-bold">
                  {isEn ? 'Major Research Contribution' : 'ஆய்வுப் பங்களிப்பு'}
                </div>
                <p className="text-xs text-[#57534E] dark:text-[#CBD5E1] leading-relaxed p-3.5 rounded-xl bg-white dark:bg-[#161D24] border border-[#E7E2D8] dark:border-[#27323C]">
                  {selection.data.researchContribution}
                </p>
              </div>
            )}

            {/* Major Works */}
            {selection.data?.keyPublications && selection.data.keyPublications.length > 0 && (
              <div className="space-y-2">
                <div className="text-[10px] font-mono uppercase text-[#78716C] dark:text-[#94A3B8] font-bold">
                  {isEn ? 'Major Works & Publications' : 'முக்கிய ஆய்வு வெளியீடுகள்'}
                </div>
                <div className="space-y-1.5">
                  {selection.data.keyPublications.map((pub: string, idx: number) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl bg-white dark:bg-[#161D24] border border-[#E7E2D8] dark:border-[#27323C] text-xs font-serif flex items-start gap-2"
                    >
                      <BookOpen className="w-3.5 h-3.5 text-[#8B3A1C] shrink-0 mt-0.5" />
                      <span>{pub}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ) : selection.type === 'book' ? (
          /* =================== BOOK INSPECTOR (Section 14) =================== */
          <div className="space-y-6 text-left animate-fadeIn">
            <div className="flex gap-4">
              {/* Book Spine Mock */}
              <div className="w-20 h-28 rounded-md bg-gradient-to-br from-[#8B3A1C] to-[#3B170B] text-amber-100 p-2 flex flex-col justify-between shrink-0 shadow-md border border-amber-900/40 relative overflow-hidden">
                <div className="w-1.5 h-full absolute left-0 top-0 bg-black/25" />
                <span className="text-[8px] font-mono uppercase text-amber-200/70 tracking-widest pl-1">TAMIL AI</span>
                <div className="font-serif text-[10px] font-bold leading-tight line-clamp-3 pl-1">{selection.data?.title || selection.title}</div>
                <span className="text-[8px] font-mono text-amber-300 pl-1">{selection.data?.publicationYear || 'Archive'}</span>
              </div>

              <div className="min-w-0 flex-1 space-y-1">
                <span className="text-[10px] font-mono uppercase tracking-wider font-bold px-2 py-0.5 rounded bg-blue-100 dark:bg-blue-950/60 text-blue-800 dark:text-blue-300 inline-block">
                  {isEn ? 'SECONDARY SOURCE · BOOK' : 'ஆய்வு நூல்'}
                </span>
                <h2 className="text-base font-serif font-bold leading-tight">
                  {selection.data?.title || selection.title}
                </h2>
                {selection.data?.tamilTitle && (
                  <div className="text-xs text-[#8B3A1C] font-serif">{selection.data.tamilTitle}</div>
                )}
                <div className="text-xs text-[#57534E] dark:text-[#94A3B8]">
                  {isEn ? 'Author:' : 'ஆசிரியர்:'} <strong className="text-[#1C1917] dark:text-[#F8FAFC]">{selection.data?.author}</strong>
                </div>
                {selection.data?.publisher && (
                  <div className="text-[11px] font-mono text-[#78716C]">
                    {selection.data.publisher} ({selection.data.publicationYear})
                  </div>
                )}
              </div>
            </div>

            {/* Why Relevant */}
            <div className="p-4 rounded-xl bg-white dark:bg-[#161D24] border border-[#E7E2D8] dark:border-[#27323C] space-y-1.5 text-xs">
              <div className="font-mono text-[10px] uppercase font-bold text-[#8B3A1C] dark:text-[#E07A5F]">
                {isEn ? 'Why this book is relevant' : 'நூலின் தொடர்பு'}
              </div>
              <p className="text-[#292524] dark:text-[#CBD5E1] leading-relaxed font-serif">
                {selection.data?.whyRelevant || 
                  (isEn 
                    ? 'Provides critical archaeological stratification and primary textual collation for this answer.' 
                    : 'இக்கேள்விக்கான வரலாற்று மற்றும் தொல்லியல் சான்றுகளை ஆவணப்படுத்தும் நூல்.')}
              </p>
            </div>

            {/* Relevant Section */}
            {(selection.data?.relevantPassageOrPage || selection.data?.relevantPassage) && (
              <div className="space-y-1.5">
                <div className="text-[10px] font-mono uppercase text-[#78716C] dark:text-[#94A3B8] font-bold">
                  {isEn ? 'Relevant Section / Excerpt' : 'மேற்கோள் பத்தி / அதிகாரம்'}
                </div>
                <blockquote className="p-4 rounded-xl bg-[#FBF9F5] dark:bg-[#1A2229] border border-[#E7E2D8] dark:border-[#27323C] font-serif text-xs italic leading-relaxed text-[#1C1917] dark:text-[#E2E8F0]">
                  “{selection.data.relevantPassageOrPage || selection.data.relevantPassage}”
                </blockquote>
              </div>
            )}

            {/* Source Reference */}
            <div className="p-3.5 bg-white dark:bg-[#161D24] rounded-xl border border-[#E7E2D8] dark:border-[#27323C] space-y-1 text-xs font-mono">
              <span className="text-[#78716C] text-[10px] uppercase block">{isEn ? 'Archival Reference' : 'காப்பக மேற்கோள்'}</span>
              <div className="text-[#1C1917] dark:text-[#F8FAFC]">{selection.data?.referenceSource || selection.data?.pageOrReference || 'Classical Tamil Archival Corpus'}</div>
            </div>
          </div>
        ) : (
          /* =================== SOURCE & EVIDENCE INSPECTOR (Section 9, 10, 11, 12) =================== */
          <div className="space-y-6 text-left animate-fadeIn">
            {/* Source Category Badge (Section 10) */}
            {(() => {
              const cat = getSourceCategory(selection.data || {});
              return (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className={`text-[10px] font-mono uppercase tracking-wider font-bold px-2.5 py-1 rounded-md border ${cat.bg}`}>
                      {cat.label}
                    </span>
                    <span className="text-[10px] font-mono text-[#78716C] dark:text-[#94A3B8]">
                      {selection.data?.id || selection.id}
                    </span>
                  </div>
                  <h2 className="text-lg font-serif font-bold leading-tight">
                    {selection.data?.title || selection.data?.codeOrTitle || selection.title}
                  </h2>
                </div>
              );
            })()}

            {/* Metadata Grid (Section 9) */}
            <div className="grid grid-cols-2 gap-2.5 text-xs">
              <div className="p-3 rounded-xl bg-white dark:bg-[#161D24] border border-[#E7E2D8] dark:border-[#27323C]">
                <span className="font-mono text-[10px] uppercase text-[#78716C] dark:text-[#94A3B8] block">
                  {isEn ? 'Period' : 'காலம்'}
                </span>
                <span className="font-serif font-bold text-[#8B3A1C] dark:text-[#E07A5F]">
                  {selection.data?.period || selection.data?.periodDate || selection.data?.date || 'c. 3rd BCE – 2nd CE'}
                </span>
              </div>
              <div className="p-3 rounded-xl bg-white dark:bg-[#161D24] border border-[#E7E2D8] dark:border-[#27323C]">
                <span className="font-mono text-[10px] uppercase text-[#78716C] dark:text-[#94A3B8] block">
                  {isEn ? 'Location / Site' : 'கண்டெடுக்கப்பட்ட இடம்'}
                </span>
                <span className="font-serif font-medium truncate block">
                  {selection.data?.location || selection.data?.site || 'Tamilakam / South India'}
                </span>
              </div>
              <div className="p-3 rounded-xl bg-white dark:bg-[#161D24] border border-[#E7E2D8] dark:border-[#27323C]">
                <span className="font-mono text-[10px] uppercase text-[#78716C] dark:text-[#94A3B8] block">
                  {isEn ? 'Language & Script' : 'மொழி & எழுத்து'}
                </span>
                <span className="font-mono text-[11px] font-medium">
                  {selection.data?.script || (isEn ? 'Tamil / Tamil-Brahmi' : 'தமிழ் / தமிழ்-பிராமி')}
                </span>
              </div>
              <div className="p-3 rounded-xl bg-white dark:bg-[#161D24] border border-[#E7E2D8] dark:border-[#27323C]">
                <span className="font-mono text-[10px] uppercase text-[#78716C] dark:text-[#94A3B8] block">
                  {isEn ? 'Repository / Archive' : 'பாதுகாக்கப்படும் இடம்'}
                </span>
                <span className="font-serif font-medium truncate block">
                  {selection.data?.repository || selection.data?.museumOrRepository || 'Epigraphy & Manuscript Archive'}
                </span>
              </div>
            </div>

            {/* 1. ORIGINAL EVIDENCE (Section 11, Hierarchy #1) */}
            {selection.data?.imageUrl && (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono uppercase font-bold text-[#8B3A1C] dark:text-[#E07A5F] flex items-center gap-1">
                    <Layers className="w-3.5 h-3.5" />
                    <span>{isEn ? '1. Original Evidence' : '1. அசல் மூலச் சான்று'}</span>
                  </span>
                  
                  {/* Controls: − 100% + Fullscreen Download (Section 9) */}
                  <div className="flex items-center gap-1 bg-white dark:bg-[#161D24] border border-[#E7E2D8] dark:border-[#27323C] rounded-lg p-0.5 text-xs font-mono">
                    <button
                      onClick={() => setZoomScale(s => Math.max(0.75, s - 0.25))}
                      className="px-2 py-0.5 hover:bg-[#F2ECE1] dark:hover:bg-[#1E252D] rounded transition-colors cursor-pointer"
                      title="Zoom Out"
                    >
                      −
                    </button>
                    <button
                      onClick={() => setZoomScale(1)}
                      className="px-1.5 py-0.5 text-[10px] hover:bg-[#F2ECE1] dark:hover:bg-[#1E252D] rounded transition-colors cursor-pointer"
                      title="Reset Zoom"
                    >
                      100%
                    </button>
                    <button
                      onClick={() => setZoomScale(s => Math.min(2.5, s + 0.25))}
                      className="px-2 py-0.5 hover:bg-[#F2ECE1] dark:hover:bg-[#1E252D] rounded transition-colors cursor-pointer"
                      title="Zoom In"
                    >
                      +
                    </button>
                    <button
                      onClick={() => setIsFullScreen(true)}
                      className="p-1 hover:bg-[#F2ECE1] dark:hover:bg-[#1E252D] rounded transition-colors cursor-pointer"
                      title="Fullscreen"
                    >
                      <Maximize2 className="w-3 h-3" />
                    </button>
                    <a
                      href={selection.data.imageUrl}
                      download="tamil-ai-evidence.jpg"
                      target="_blank"
                      rel="noreferrer"
                      className="p-1 hover:bg-[#F2ECE1] dark:hover:bg-[#1E252D] rounded transition-colors cursor-pointer"
                      title="Download"
                    >
                      <Download className="w-3 h-3" />
                    </a>
                  </div>
                </div>

                <div className="relative aspect-[4/3] rounded-xl overflow-hidden border border-[#E7E2D8] dark:border-[#27323C] bg-neutral-900 flex items-center justify-center">
                  <img
                    src={selection.data.imageUrl}
                    alt={selection.data.title}
                    style={{ transform: `scale(${zoomScale})` }}
                    className="w-full h-full object-cover transition-transform duration-200"
                  />
                  {selection.data.photoCaption && (
                    <div className="absolute bottom-2 left-2 right-2 px-2.5 py-1 rounded bg-black/75 backdrop-blur-xs text-[10px] font-mono text-white/90">
                      {selection.data.photoCaption}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* 2. TRANSCRIPTION (Section 11, Hierarchy #2) */}
            {(selection.data?.transcription || selection.data?.originalTamil || selection.data?.originalTextOrTransliteration || selection.data?.relevantPassage) && (
              <div className="space-y-1.5">
                <span className="text-[10px] font-mono uppercase font-bold text-[#1C1917] dark:text-[#F8FAFC]">
                  {isEn ? '2. Original Transcription' : '2. அசல் மூலப் பாடம்'}
                </span>
                <div className="p-4 rounded-xl bg-white dark:bg-[#161D24] border border-[#E7E2D8] dark:border-[#27323C] font-serif text-sm font-bold leading-relaxed whitespace-pre-line text-[#1C1917] dark:text-[#F8FAFC]">
                  {selection.data.transcription || selection.data.originalTamil || selection.data.originalTextOrTransliteration || selection.data.relevantPassage}
                </div>
              </div>
            )}

            {/* 3. TRANSLATION (Section 11, Hierarchy #3) */}
            {(selection.data?.englishTranslation || selection.data?.translation || selection.data?.modernTamilTranslation || selection.data?.modernTamil) && (
              <div className="space-y-1.5">
                <span className="text-[10px] font-mono uppercase font-bold text-[#78716C] dark:text-[#94A3B8]">
                  {isEn ? '3. Translation' : '3. மொழிபெயர்ப்பு & எளிய உரை'}
                </span>
                <div className="p-4 rounded-xl bg-[#FBF9F5] dark:bg-[#161D24] border border-[#E7E2D8] dark:border-[#27323C] font-serif text-xs leading-relaxed italic text-[#292524] dark:text-[#CBD5E1]">
                  {selection.data.englishTranslation || selection.data.translation || selection.data.modernTamilTranslation || selection.data.modernTamil}
                </div>
              </div>
            )}

            {/* 4. WHAT THIS EVIDENCE ESTABLISHES (Section 9 & 11) */}
            <div className="p-4 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/50 space-y-1.5 text-xs">
              <span className="font-mono text-[10px] uppercase font-bold text-emerald-900 dark:text-emerald-300 block">
                {isEn ? 'What this evidence establishes' : 'இந்த ஆதாரம் நிறுவுவது'}
              </span>
              <p className="text-[#292524] dark:text-[#CBD5E1] leading-relaxed font-serif">
                {selection.data?.whatItEstablishes || selection.data?.whyItMatters || selection.data?.significance || 
                  (isEn 
                    ? 'Establishes direct authentic occurrences in verified epigraphy and manuscripts.' 
                    : 'நிறுவப்பட்ட அசல் மூலத் தரவுகள் மற்றும் தொல்லியல் சான்றுகளின் வழி உறுதிசெய்யப்படுகிறது.')}
              </p>
            </div>

            {/* 5. LIMITATIONS (Section 9) */}
            <div className="p-4 rounded-xl bg-amber-50/70 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/50 space-y-1.5 text-xs">
              <span className="font-mono text-[10px] uppercase font-bold text-amber-900 dark:text-amber-300 block">
                {isEn ? 'Limitations & What cannot be established' : 'வரம்புகளும் முடிவுசெய்ய முடியாதவையும்'}
              </span>
              <p className="text-[#292524] dark:text-[#CBD5E1] leading-relaxed font-serif">
                {selection.data?.limitations || 
                  (isEn 
                    ? 'Does not establish exact calendar day or personal biographical lineage beyond what is explicitly recorded on the stone or palm leaf.' 
                    : 'மூல ஆவணத்தில் வெளிப்படையாகக் கூறப்படாத பிற வினாக்களுக்கு இது நேரடி சான்றாக அமையாது.')}
              </p>
            </div>

            {/* 6. REFERENCES (Section 9) */}
            <div className="p-3.5 rounded-xl bg-white dark:bg-[#161D24] border border-[#E7E2D8] dark:border-[#27323C] space-y-1 text-xs font-mono">
              <span className="text-[#78716C] text-[10px] uppercase block">
                {isEn ? 'Archival Reference & Citation' : 'ஆவண மேற்கோள் எண்'}
              </span>
              <div className="text-[#1C1917] dark:text-[#F8FAFC]">
                {selection.data?.pageOrReference || selection.data?.citationReference || selection.data?.epigraphicalReference || selection.data?.publisherOrJournal || 'Archaeological Survey & Critical Editions'}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Fullscreen Modal if user clicked Fullscreen */}
      {isFullScreen && selection?.data?.imageUrl && (
        <div className="fixed inset-0 z-50 bg-black/95 flex flex-col items-center justify-center p-4">
          <button
            onClick={() => setIsFullScreen(false)}
            className="absolute top-4 right-4 p-2 text-white/70 hover:text-white bg-white/10 hover:bg-white/20 rounded-full transition-colors cursor-pointer"
          >
            <X className="w-6 h-6" />
          </button>
          <img
            src={selection.data.imageUrl}
            alt={selection.title}
            className="max-w-[90vw] max-h-[85vh] object-contain rounded-lg shadow-2xl"
          />
        </div>
      )}
    </aside>
  );
};
