import React from 'react';
import { EvidenceLevel } from '../types/research';
import { ShieldCheck, BookOpen, AlertCircle, HelpCircle, Sparkles } from 'lucide-react';

interface EvidenceLevelBadgeProps {
  level: EvidenceLevel;
  size?: 'sm' | 'md' | 'lg';
  showDescription?: boolean;
}

export const EvidenceLevelBadge: React.FC<EvidenceLevelBadgeProps> = ({
  level,
  size = 'md',
  showDescription = false
}) => {
  const getConfig = () => {
    switch (level) {
      case 'DIRECT_EVIDENCE':
        return {
          icon: ShieldCheck,
          label: 'Direct Evidence',
          tamilLabel: 'நேரடிச் சான்று',
          desc: 'Directly supported by a primary source (inscription, manuscript, excavation, or text).',
          bg: 'bg-emerald-50 dark:bg-emerald-950/40',
          border: 'border-emerald-300 dark:border-emerald-800',
          text: 'text-emerald-800 dark:text-emerald-300',
          dot: 'bg-emerald-600 dark:bg-emerald-400'
        };
      case 'SCHOLARLY_INTERPRETATION':
        return {
          icon: BookOpen,
          label: 'Scholarly Interpretation',
          tamilLabel: 'ஆய்வறிஞர் விளக்கம்',
          desc: 'Based on identified peer-reviewed scholars and historical research analysis.',
          bg: 'bg-sky-50 dark:bg-sky-950/40',
          border: 'border-sky-300 dark:border-sky-800',
          text: 'text-sky-800 dark:text-sky-300',
          dot: 'bg-sky-600 dark:bg-sky-400'
        };
      case 'PROBABLE':
        return {
          icon: AlertCircle,
          label: 'Probable',
          tamilLabel: 'ஏற்புடைய ஊகம்',
          desc: 'Supported by contextual historical evidence, though direct confirmation remains partial.',
          bg: 'bg-amber-50 dark:bg-amber-950/40',
          border: 'border-amber-300 dark:border-amber-800',
          text: 'text-amber-800 dark:text-amber-300',
          dot: 'bg-amber-500 dark:bg-amber-400'
        };
      case 'SPECULATIVE':
        return {
          icon: HelpCircle,
          label: 'Speculative',
          tamilLabel: 'கருதுகோள் / உறுதியற்றது',
          desc: 'Possible historical interpretation with limited or debated evidence.',
          bg: 'bg-orange-50 dark:bg-orange-950/40',
          border: 'border-orange-300 dark:border-orange-800',
          text: 'text-orange-800 dark:text-orange-300',
          dot: 'bg-orange-600 dark:bg-orange-400'
        };
      case 'AI_VISUALIZATION':
        return {
          icon: Sparkles,
          label: 'AI Visualization',
          tamilLabel: 'AI மாதிரி காட்சிப்படுத்தல்',
          desc: 'Generated illustrative reconstruction — NOT primary historical evidence.',
          bg: 'bg-purple-50 dark:bg-purple-950/40',
          border: 'border-purple-300 dark:border-purple-800',
          text: 'text-purple-800 dark:text-purple-300',
          dot: 'bg-purple-600 dark:bg-purple-400'
        };
    }
  };

  const config = getConfig();
  const Icon = config.icon;

  const sizeClasses = {
    sm: 'text-[10px] px-2 py-0.5 gap-1',
    md: 'text-xs px-2.5 py-1 gap-1.5',
    lg: 'text-sm px-3 py-1.5 gap-2'
  }[size];

  return (
    <div className="inline-flex flex-col">
      <span
        className={`inline-flex items-center rounded-md font-mono font-medium border shadow-2xs ${config.bg} ${config.border} ${config.text} ${sizeClasses}`}
        title={config.desc}
      >
        <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${config.dot}`} />
        <Icon className="w-3 h-3 shrink-0" />
        <span className="font-semibold">{config.label}</span>
        <span className="text-[10px] opacity-75 font-tamil hidden sm:inline">({config.tamilLabel})</span>
      </span>
      {showDescription && (
        <span className="text-[11px] text-neutral-500 mt-1 font-sans italic">
          {config.desc}
        </span>
      )}
    </div>
  );
};
