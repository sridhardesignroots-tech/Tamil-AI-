import React from 'react';
import { ResearchMode, LanguagePreference } from '../types/research';
import { 
  Sidebar, Sliders, Globe, ShieldCheck, ChevronRight, 
  Settings as SettingsIcon, Layers, BookOpen, Zap 
} from 'lucide-react';

interface ResearchHeaderProps {
  currentTitle: string | null;
  currentCategory?: string;
  isLensOpen: boolean;
  onToggleLens: () => void;
  language: LanguagePreference;
  onLanguageChange: (lang: LanguagePreference) => void;
  researchMode: ResearchMode;
  onOpenSettings: (tab?: string) => void;
}

export const ResearchHeader: React.FC<ResearchHeaderProps> = ({
  currentTitle,
  currentCategory,
  isLensOpen,
  onToggleLens,
  language,
  onLanguageChange,
  researchMode,
  onOpenSettings
}) => {
  const getModeLabel = () => {
    if (language === 'ta') {
      switch (researchMode) {
        case 'quick':
          return { label: 'விரைவானது', icon: <Zap className="w-3 h-3 text-amber-600" /> };
        case 'deep':
          return { label: 'ஆழ்ந்த ஆய்வு', icon: <Layers className="w-3 h-3 text-[#354653]" /> };
        case 'research':
        default:
          return { label: 'ஆராய்ச்சி நிலை', icon: <BookOpen className="w-3 h-3 text-[#8B3A1C]" /> };
      }
    }
    switch (researchMode) {
      case 'quick':
        return { label: 'Quick Discovery', icon: <Zap className="w-3 h-3 text-amber-600" /> };
      case 'deep':
        return { label: 'Deep Multi-Source', icon: <Layers className="w-3 h-3 text-[#354653]" /> };
      case 'research':
      default:
        return { label: 'Research Standard', icon: <BookOpen className="w-3 h-3 text-[#8B3A1C]" /> };
    }
  };

  const modeInfo = getModeLabel();

  return (
    <header className="h-16 px-4 sm:px-6 border-b border-[#E7E2D8] dark:border-[#27323C] bg-[#FAF8F5]/90 dark:bg-[#151D22]/90 backdrop-blur-md flex items-center justify-between shrink-0 z-10 transition-colors">
      {/* Left: Breadcrumbs / Title */}
      <div className="flex items-center gap-2 min-w-0">
        <span className="text-xs font-mono uppercase tracking-wider text-[#8B3A1C] dark:text-[#E07A5F] font-bold shrink-0">
          {language === 'ta' ? 'தமிழ் அறிவுத் தளம்' : 'TAMIL AI'}
        </span>
        {currentTitle ? (
          <>
            <ChevronRight className="w-3.5 h-3.5 text-[#A8A29E] shrink-0" />
            <span className="text-xs font-serif font-semibold text-[#1C1917] dark:text-[#F8FAFC] truncate max-w-[200px] sm:max-w-xs md:max-w-md">
              {currentTitle}
            </span>
          </>
        ) : (
          <>
            <ChevronRight className="w-3.5 h-3.5 text-[#A8A29E] shrink-0" />
            <span className="text-xs font-serif text-[#78716C] dark:text-[#94A3B8] italic">
              {language === 'ta' ? 'டிஜிட்டல் ஆராய்ச்சி மற்றும் வரலாற்று ஆவணக் களஞ்சியம்' : 'Digital Research Archive & Knowledge System'}
            </span>
          </>
        )}
      </div>

      {/* Right controls */}
      <div className="flex items-center gap-3 shrink-0">
        {/* Mode badge */}
        <div className="hidden md:flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#EFE9DD] dark:bg-[#1E2831] border border-[#E7E2D8] dark:border-[#2E3C49] text-[11px] font-mono text-[#57534E] dark:text-[#CBD5E1]">
          {modeInfo.icon}
          <span>{modeInfo.label}</span>
        </div>

        {/* Dedicated Language Selector: தமிழ் | English (Strictly two options) */}
        <div 
          role="group" 
          aria-label="Language selection"
          className="inline-flex items-center bg-[#EFE9DD] dark:bg-[#1E252D] p-1 rounded-lg border border-[#E7E2D8] dark:border-[#334155] text-xs font-medium"
        >
          <button
            type="button"
            onClick={() => onLanguageChange('ta')}
            className={`px-3 py-1 rounded-md text-xs transition-all cursor-pointer ${
              language === 'ta'
                ? 'bg-white dark:bg-[#2A3441] text-[#8B3A1C] dark:text-[#E07A5F] font-bold shadow-2xs'
                : 'text-[#78716C] dark:text-[#94A3B8] hover:text-[#1C1917] dark:hover:text-[#F8FAFC]'
            }`}
            aria-pressed={language === 'ta'}
            title="தமிழ் இடைமுகம் (Tamil Mode)"
          >
            தமிழ்
          </button>
          
          <span className="text-[#C7BAA7] dark:text-[#475569] select-none px-1 text-xs">
            |
          </span>

          <button
            type="button"
            onClick={() => onLanguageChange('en')}
            className={`px-3 py-1 rounded-md text-xs transition-all cursor-pointer ${
              language === 'en'
                ? 'bg-white dark:bg-[#2A3441] text-[#8B3A1C] dark:text-[#E07A5F] font-bold shadow-2xs'
                : 'text-[#78716C] dark:text-[#94A3B8] hover:text-[#1C1917] dark:hover:text-[#F8FAFC]'
            }`}
            aria-pressed={language === 'en'}
            title="English interface (English Mode)"
          >
            English
          </button>
        </div>

        {/* Settings Button */}
        <button
          onClick={() => onOpenSettings()}
          className="p-2 rounded-lg border border-[#E7E2D8] dark:border-[#2E3C49] bg-white dark:bg-[#1E252D] text-[#57534E] dark:text-[#CBD5E1] hover:text-[#1C1917] dark:hover:text-white hover:border-[#8B3A1C] transition-colors cursor-pointer"
          title={language === 'ta' ? 'அமைப்புகள்' : 'Settings'}
        >
          <SettingsIcon className="w-4 h-4" />
        </button>

        {/* Evidence Lens Toggle */}
        <button
          onClick={onToggleLens}
          className={`px-3 py-1.5 rounded-lg border text-xs font-mono font-medium flex items-center gap-1.5 transition-all cursor-pointer ${
            isLensOpen
              ? 'bg-[#8B3A1C] text-white border-[#8B3A1C] shadow-xs'
              : 'bg-white dark:bg-[#1E252D] border-[#E7E2D8] dark:border-[#2E3C49] text-[#57534E] dark:text-[#CBD5E1] hover:border-[#8B3A1C]'
          }`}
          title={language === 'ta' ? 'சான்று ஆய்வகம்' : 'Evidence Lens'}
        >
          <Sidebar className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">
            {language === 'ta' ? 'சான்றுப் பலகை' : 'Evidence Lens'}
          </span>
        </button>
      </div>
    </header>
  );
};
