import React, { useState, useEffect, useRef } from 'react';
import { Sparkles, HelpCircle, Search, Languages, Compass, X } from 'lucide-react';

interface TextSelectionToolbarProps {
  containerRef: React.RefObject<HTMLDivElement | null>;
  onAction: (action: 'ask' | 'explain' | 'source' | 'translate' | 'deeper', text: string) => void;
  language: 'ta' | 'en';
}

export const TextSelectionToolbar: React.FC<TextSelectionToolbarProps> = ({
  containerRef,
  onAction,
  language
}) => {
  const [selectedText, setSelectedText] = useState('');
  const [position, setPosition] = useState<{ top: number; left: number } | null>(null);
  const toolbarRef = useRef<HTMLDivElement>(null);
  const isEn = language === 'en';

  useEffect(() => {
    const handleSelectionChange = () => {
      const selection = window.getSelection();
      if (!selection || selection.isCollapsed || !containerRef.current) {
        // Delay slight hiding to allow clicking buttons
        return;
      }

      const text = selection.toString().trim();
      if (text.length < 3) {
        setPosition(null);
        setSelectedText('');
        return;
      }

      // Check if selection is inside container
      const anchorNode = selection.anchorNode;
      if (!anchorNode || !containerRef.current.contains(anchorNode)) {
        setPosition(null);
        setSelectedText('');
        return;
      }

      try {
        const range = selection.getRangeAt(0);
        const rect = range.getBoundingClientRect();
        
        // Position above the selection
        setPosition({
          top: Math.max(10, rect.top - 48),
          left: Math.max(16, Math.min(window.innerWidth - 360, rect.left + rect.width / 2 - 160))
        });
        setSelectedText(text);
      } catch {
        setPosition(null);
      }
    };

    const handleMouseUp = () => {
      setTimeout(handleSelectionChange, 10);
    };

    const handleDocumentMouseDown = (e: MouseEvent) => {
      if (toolbarRef.current && !toolbarRef.current.contains(e.target as Node)) {
        const selection = window.getSelection();
        if (selection && selection.isCollapsed) {
          setPosition(null);
          setSelectedText('');
        }
      }
    };

    document.addEventListener('mouseup', handleMouseUp);
    document.addEventListener('selectionchange', handleSelectionChange);
    document.addEventListener('mousedown', handleDocumentMouseDown);

    return () => {
      document.removeEventListener('mouseup', handleMouseUp);
      document.removeEventListener('selectionchange', handleSelectionChange);
      document.removeEventListener('mousedown', handleDocumentMouseDown);
    };
  }, [containerRef]);

  if (!position || !selectedText) return null;

  return (
    <div
      ref={toolbarRef}
      style={{ top: `${position.top}px`, left: `${position.left}px` }}
      className="fixed z-50 flex items-center gap-1 p-1 bg-[#1C1917] text-white dark:bg-[#F8FAFC] dark:text-[#0F172A] rounded-xl shadow-xl border border-white/10 dark:border-black/10 text-xs animate-fadeIn select-none backdrop-blur-md"
    >
      <button
        onClick={() => {
          onAction('ask', selectedText);
          setPosition(null);
        }}
        className="px-2.5 py-1.5 rounded-lg hover:bg-white/15 dark:hover:bg-black/10 transition-colors flex items-center gap-1.5 font-medium cursor-pointer"
        title={isEn ? "Ask follow-up with this selected text" : "இந்த உரையை அடிப்படையாகக் கொண்டு வினவுக"}
      >
        <Sparkles className="w-3.5 h-3.5 text-[#E07A5F] dark:text-[#8B3A1C]" />
        <span>{isEn ? 'Ask Tamil AI' : 'தமிழ் AI-யிடம் கேட்க'}</span>
      </button>

      <span className="w-px h-3.5 bg-white/20 dark:bg-black/20" />

      <button
        onClick={() => {
          onAction('explain', selectedText);
          setPosition(null);
        }}
        className="px-2 py-1.5 rounded-lg hover:bg-white/15 dark:hover:bg-black/10 transition-colors flex items-center gap-1 cursor-pointer"
        title={isEn ? "Explain this sentence" : "இத்தொடரை விளக்குக"}
      >
        <HelpCircle className="w-3.5 h-3.5 text-neutral-400" />
        <span>{isEn ? 'Explain' : 'விளக்குக'}</span>
      </button>

      <button
        onClick={() => {
          onAction('source', selectedText);
          setPosition(null);
        }}
        className="px-2 py-1.5 rounded-lg hover:bg-white/15 dark:hover:bg-black/10 transition-colors flex items-center gap-1 cursor-pointer"
        title={isEn ? "Find archival source for this passage" : "இதற்கான மூல ஆதாரத்தைத் தேடுக"}
      >
        <Search className="w-3.5 h-3.5 text-neutral-400" />
        <span>{isEn ? 'Find source' : 'சான்று தேடுக'}</span>
      </button>

      <button
        onClick={() => {
          onAction('translate', selectedText);
          setPosition(null);
        }}
        className="px-2 py-1.5 rounded-lg hover:bg-white/15 dark:hover:bg-black/10 transition-colors flex items-center gap-1 cursor-pointer"
        title={isEn ? "Translate" : "மொழிபெயர்க்க"}
      >
        <Languages className="w-3.5 h-3.5 text-neutral-400" />
        <span>{isEn ? 'Translate' : 'மொழிபெயர்'}</span>
      </button>

      <button
        onClick={() => {
          onAction('deeper', selectedText);
          setPosition(null);
        }}
        className="px-2 py-1.5 rounded-lg hover:bg-white/15 dark:hover:bg-black/10 transition-colors flex items-center gap-1 cursor-pointer"
        title={isEn ? "Investigate deeper into this concept" : "இதன் ஆழமான வரலாற்றுத் தொடர்பு"}
      >
        <Compass className="w-3.5 h-3.5 text-neutral-400" />
        <span>{isEn ? 'Go deeper' : 'ஆழமாக அறிய'}</span>
      </button>

      <button
        onClick={() => {
          setPosition(null);
          setSelectedText('');
        }}
        className="p-1.5 rounded-lg hover:bg-white/15 dark:hover:bg-black/10 text-neutral-400 hover:text-white dark:hover:text-black transition-colors cursor-pointer ml-0.5"
      >
        <X className="w-3.5 h-3.5" />
      </button>
    </div>
  );
};
