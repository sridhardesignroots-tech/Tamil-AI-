import React, { useState, useRef, useEffect } from 'react';
import { ResearchMode } from '../types/research';
import { Sparkles, ArrowUp, Zap, BookOpen, Layers, HelpCircle, CornerDownLeft } from 'lucide-react';

interface ResearchInputProps {
  onSubmitQuery: (query: string, mode: ResearchMode) => void;
  isLoading: boolean;
  activeMode: ResearchMode;
  onModeChange: (mode: ResearchMode) => void;
  language: 'ta' | 'en';
}

export const ResearchInput: React.FC<ResearchInputProps> = ({
  onSubmitQuery,
  isLoading,
  activeMode,
  onModeChange,
  language
}) => {
  const [inputVal, setInputVal] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const isEn = language === 'en';

  // Auto expand textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 180)}px`;
    }
  }, [inputVal]);

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputVal.trim() || isLoading) return;
    onSubmitQuery(inputVal.trim(), activeMode);
    setInputVal('');
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div className="research-input-area border-t border-[#E5DFC8] dark:border-[#27323C] bg-[#F7F3EA]/95 dark:bg-[#12171B]/95 backdrop-blur-md p-3 sm:p-4 transition-all">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white dark:bg-[#1A2229] border border-[#E5DFC8] dark:border-[#2D3842] rounded-xl shadow-xs focus-within:border-[#A85C43] dark:focus-within:border-[#D47B62] focus-within:ring-2 focus-within:ring-[#A85C43]/20 transition-all p-2.5 sm:p-3">
          {/* Top Bar inside input: Mode selector & hints */}
          <div className="flex flex-wrap items-center justify-between pb-2 mb-1.5 border-b border-[#E5DFC8]/60 dark:border-[#2D3842] gap-2">
            <div className="flex items-center gap-1">
              <span className="text-[10px] font-mono uppercase text-neutral-400 font-semibold mr-1 hidden sm:inline">
                {isEn ? 'Mode:' : 'முறை:'}
              </span>
              
              <button
                type="button"
                onClick={() => onModeChange('quick')}
                className={`px-2 py-0.5 rounded text-[11px] font-mono transition-colors flex items-center gap-1 cursor-pointer ${
                  activeMode === 'quick'
                    ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-900 dark:text-amber-300 font-semibold border border-amber-300 dark:border-amber-800'
                    : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-neutral-200'
                }`}
                title={isEn ? "Quick: Fast concise response" : "விரைவு: சுருக்கமான விடை"}
              >
                <Zap className="w-3 h-3 text-amber-600" />
                {isEn ? 'Quick' : 'விரைவு'}
              </button>

              <button
                type="button"
                onClick={() => onModeChange('research')}
                className={`px-2 py-0.5 rounded text-[11px] font-mono transition-colors flex items-center gap-1 cursor-pointer ${
                  activeMode === 'research'
                    ? 'bg-[#A85C43]/10 text-[#A85C43] dark:text-[#D47B62] font-semibold border border-[#A85C43]/30'
                    : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-neutral-200'
                }`}
                title={isEn ? "Research: Evidence + sources + context" : "ஆய்வு: சான்றுகள் + மூலங்கள்"}
              >
                <BookOpen className="w-3 h-3 text-[#A85C43]" />
                {isEn ? 'Research' : 'ஆய்வு'}
              </button>

              <button
                type="button"
                onClick={() => onModeChange('deep')}
                className={`px-2 py-0.5 rounded text-[11px] font-mono transition-colors flex items-center gap-1 cursor-pointer ${
                  activeMode === 'deep'
                    ? 'bg-[#354653]/15 text-[#354653] dark:text-[#B0C4DE] font-semibold border border-[#354653]/30'
                    : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-neutral-200'
                }`}
                title={isEn ? "Deep Research: Multi-source comparative investigation" : "ஆழ்ந்த ஆய்வு: ஒப்பீட்டு ஆய்வு"}
              >
                <Layers className="w-3 h-3 text-[#354653] dark:text-[#B0C4DE]" />
                {isEn ? 'Deep Research' : 'ஆழ்ந்த ஆய்வு'}
              </button>
            </div>

            <div className="text-[10px] font-mono text-neutral-400 hidden sm:flex items-center gap-1">
              <span>Shift + Enter = {isEn ? 'newline' : 'புதிய வரி'}</span>
              <span>•</span>
              <span className="flex items-center">
                Enter = {isEn ? 'submit' : 'அனுப்புக'} <CornerDownLeft className="w-2.5 h-2.5 ml-0.5" />
              </span>
            </div>
          </div>

          {/* Multiline textarea */}
          <div className="flex items-end gap-2">
            <textarea
              ref={textareaRef}
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              onKeyDown={handleKeyDown}
              rows={1}
              placeholder={
                isEn
                  ? 'Begin a research investigation... (e.g., What archaeological evidence exists for Roman trade at Muziris?)'
                  : 'ஆராய்ச்சி வினாவை உள்ளிடுக... (எ.கா: முசிறி துறைமுக உரோமானிய வணிகச் சான்றுகள் யாவை?)'
              }
              className="w-full bg-transparent resize-none outline-hidden text-neutral-900 dark:text-neutral-100 placeholder:text-neutral-400 text-sm font-serif leading-relaxed min-h-[28px] max-h-[160px] py-1"
            />

            <button
              type="button"
              onClick={() => handleSubmit()}
              disabled={!inputVal.trim() || isLoading}
              className={`p-2 rounded-lg shrink-0 transition-all flex items-center justify-center ${
                inputVal.trim() && !isLoading
                  ? 'bg-[#A85C43] text-white hover:bg-[#924C35] shadow-xs cursor-pointer'
                  : 'bg-neutral-200 dark:bg-neutral-800 text-neutral-400 cursor-not-allowed'
              }`}
              title={isEn ? "Submit Investigation" : "ஆய்வை சமர்ப்பிக்கவும்"}
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Epistemological disclaimer pill */}
        <div className="text-center mt-2">
          <p className="text-[11px] text-neutral-500 dark:text-neutral-400 font-serif italic">
            {isEn
              ? '“AI research syntheses must be inspected against original Tamil sources, epigraphy, and archaeology. Evidence before certainty.”'
              : '“செயற்கை நுண்ணறிவு ஆய்வுகள் மூல நூல்கள், கல்வெட்டுகள் மற்றும் தொல்லியல் சான்றுகளோடு சரிபார்க்கப்பட வேண்டும். உறுதியை விட சான்றுகளே முதன்மையானவை.”'}
          </p>
        </div>
      </div>
    </div>
  );
};
