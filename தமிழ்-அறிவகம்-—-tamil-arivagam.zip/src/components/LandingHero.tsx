import React, { useState } from 'react';
import { Search, ArrowRight, BookOpen, Feather, History, Scroll, Compass, Landmark } from 'lucide-react';

interface LandingHeroProps {
  onSelectPrompt: (query: string, investigationId?: string) => void;
  language: 'ta' | 'en';
}

export const LandingHero: React.FC<LandingHeroProps> = ({ onSelectPrompt, language }) => {
  const [searchInput, setSearchInput] = useState('');
  const [showMoreTopics, setShowMoreTopics] = useState(false);
  const isEn = language === 'en';

  // Section 3: The 3 core primary examples
  const primaryExamples = [
    {
      category: isEn ? 'Thirukkural' : 'திருக்குறள்',
      icon: Feather,
      question: isEn 
        ? 'Is there a Thirukkural about hard work?' 
        : 'கடின உழைப்பைப் பற்றி திருக்குறளில் குறள் இருக்கிறதா?',
      investigationId: 'thirukkural-hard-work'
    },
    {
      category: isEn ? 'Classical Literature' : 'இலக்கியம்',
      icon: BookOpen,
      question: isEn 
        ? 'What does Sangam literature say about maritime trade?' 
        : 'சங்க இலக்கியத்தில் கடல் வாணிபம் பற்றி என்ன சொல்லப்பட்டுள்ளது?',
      investigationId: 'roman-tamil-trade'
    },
    {
      category: isEn ? 'History & Epigraphy' : 'வரலாறு',
      icon: History,
      question: isEn 
        ? 'What do Tamil-Brahmi rock inscriptions establish?' 
        : 'இந்த கல்வெட்டு என்ன சொல்கிறது?',
      investigationId: 'tamil-brahmi-epigraphy'
    }
  ];

  // Secondary topics (available via progressive exploration)
  const additionalTopics = [
    {
      title: isEn ? 'Keeladi Excavations' : 'கீழடி அகழாய்வு அறிக்கைகள்',
      desc: isEn 
        ? 'Stratigraphy, graffiti potsherds, and 6th-century BCE carbon dates' 
        : 'மண்பாண்டக் கீறல்கள், அடுக்கு நிலவியல் மற்றும் கி.மு. 6ஆம் நூற்றாண்டு காலக்கணிப்பு',
      id: 'keeladi-excavations'
    },
    {
      title: isEn ? 'Pallar Community & Agrarian History' : 'பள்ளர் சமூக வரலாறும் உழவு நெறியும்',
      desc: isEn 
        ? 'Sangam Marutham agricultural civilization and medieval epigraphical records' 
        : 'சங்க மருத நில வேளாண்மை மற்றும் இடைக்கால செப்பேடுகள் சான்றுகள்',
      id: 'pallar-community-history'
    },
    {
      title: isEn ? 'Chola Maritime Expeditions' : 'சோழர் கடற்படைப் பயணங்கள்',
      desc: isEn 
        ? 'Thanjavur big temple inscriptions, Srivijaya, and Bay of Bengal trade' 
        : 'தஞ்சைப் பெருங்கோயில் கல்வெட்டுகள், கடாரம் மற்றும் வங்காள விரிகுடா வாணிபம்',
      id: 'chola-maritime-expeditions'
    }
  ];

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchInput.trim()) return;
    onSelectPrompt(searchInput.trim());
  };

  return (
    <div className="max-w-[760px] mx-auto py-12 sm:py-20 px-4 space-y-12 animate-fadeIn">
      {/* Brand & Welcoming Header */}
      <div className="text-center space-y-4">
        <div className="inline-block">
          <span className="text-xs font-mono font-semibold uppercase tracking-widest text-[#8B3A1C] dark:text-[#E07A5F] px-3 py-1 rounded-full bg-[#8B3A1C]/10 dark:bg-[#8B3A1C]/20 border border-[#8B3A1C]/20">
            {isEn ? 'Tamil AI · Evidence-First Research' : 'தமிழ் AI · ஆதாரப் பூர்வ அறிவுத் தளம்'}
          </span>
        </div>

        <h1 className="text-3xl sm:text-5xl font-serif font-bold text-[#1C1917] dark:text-[#F8FAFC] tracking-tight leading-[1.3]">
          {isEn ? 'What would you like to explore in Tamil knowledge?' : 'தமிழைப் பற்றி என்ன தெரிந்துகொள்ள விரும்புகிறீர்கள்?'}
        </h1>

        <p className="text-sm sm:text-base font-sans text-[#78716C] dark:text-[#94A3B8]">
          {isEn 
            ? 'Ask anything about Tamil literature, history, manuscripts, and primary sources.' 
            : 'தமிழ் இலக்கியம், வரலாறு, தொல்லியல் மற்றும் மூலச் சான்றுகள் குறித்து கேளுங்கள்.'}
        </p>
      </div>

      {/* Large, Comfortable Input Area */}
      <form
        onSubmit={handleSearchSubmit}
        className="bg-white dark:bg-[#1E252D] rounded-2xl border-2 border-[#E7E2D8] dark:border-[#334155] p-2.5 sm:p-3 shadow-md focus-within:border-[#8B3A1C] dark:focus-within:border-[#E07A5F] transition-all flex items-center gap-3"
      >
        <div className="w-10 h-10 rounded-xl bg-[#FAF8F5] dark:bg-[#161D24] text-[#8B3A1C] dark:text-[#E07A5F] flex items-center justify-center shrink-0">
          <Search className="w-5 h-5" />
        </div>

        <input
          type="text"
          value={searchInput}
          onChange={(e) => setSearchInput(e.target.value)}
          placeholder={isEn ? "Ask your question in English or Tamil..." : "உங்கள் கேள்வியை இங்கே கேளுங்கள்..."}
          className="flex-1 bg-transparent text-base sm:text-lg font-serif text-[#1C1917] dark:text-[#F8FAFC] placeholder:text-[#A8A29E] dark:placeholder:text-[#64748B] outline-hidden px-1"
        />

        <button
          type="submit"
          disabled={!searchInput.trim()}
          className="px-5 py-2.5 bg-[#8B3A1C] hover:bg-[#722F16] text-white rounded-xl text-xs sm:text-sm font-medium flex items-center gap-2 transition-all disabled:opacity-40 cursor-pointer shadow-xs shrink-0"
        >
          <span>{isEn ? 'Ask' : 'கேளுங்கள்'}</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </form>

      {/* The 3 Core Examples */}
      <div className="space-y-3">
        <div className="text-[11px] font-mono uppercase tracking-wider text-[#78716C] dark:text-[#94A3B8] font-bold">
          {isEn ? 'Sample Inquiries' : 'மாதிரி வினாக்கள்'}
        </div>

        <div className="grid grid-cols-1 gap-3">
          {primaryExamples.map((item, idx) => {
            const Icon = item.icon;
            return (
              <button
                key={idx}
                onClick={() => onSelectPrompt(item.question, item.investigationId)}
                className="w-full text-left p-4 rounded-xl bg-white dark:bg-[#1E252D] border border-[#E7E2D8] dark:border-[#27323C] hover:border-[#8B3A1C] dark:hover:border-[#E07A5F] hover:shadow-xs transition-all group cursor-pointer flex items-center justify-between gap-4"
              >
                <div className="flex items-start gap-3.5">
                  <div className="w-8 h-8 rounded-lg bg-[#FAF8F5] dark:bg-[#161D24] text-[#8B3A1C] dark:text-[#E07A5F] flex items-center justify-center shrink-0 mt-0.5 border border-[#EBE5DA] dark:border-[#27323C]">
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="space-y-0.5">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-[#8B3A1C] dark:text-[#E07A5F] font-bold block">
                      {item.category}
                    </span>
                    <div className="text-sm sm:text-base font-serif font-medium text-[#1C1917] dark:text-[#F8FAFC] group-hover:text-[#8B3A1C] dark:group-hover:text-[#E07A5F] transition-colors">
                      "{item.question}"
                    </div>
                  </div>
                </div>

                <ArrowRight className="w-4 h-4 text-[#A8A29E] group-hover:text-[#8B3A1C] dark:group-hover:text-[#E07A5F] group-hover:translate-x-0.5 transition-all shrink-0" />
              </button>
            );
          })}
        </div>
      </div>

      {/* Progressive Exploration Fold */}
      <div className="pt-2 text-center">
        <button
          onClick={() => setShowMoreTopics(!showMoreTopics)}
          className="text-xs font-mono text-[#78716C] dark:text-[#94A3B8] hover:text-[#1C1917] dark:hover:text-[#F8FAFC] underline underline-offset-4 transition-colors cursor-pointer"
        >
          {showMoreTopics 
            ? (isEn ? 'Show fewer topics' : 'குறைவான தலைப்புகளைக் காட்டு') 
            : (isEn ? 'Explore more topics (Keeladi, Chola Maritime, Agrarian History)' : 'மேலும் தலைப்புகளைப் பார்க்க (கீழடி, சோழர், சமூக வரலாறு)')}
        </button>

        {showMoreTopics && (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-4 text-left animate-fadeIn">
            {additionalTopics.map((topic, i) => (
              <button
                key={i}
                onClick={() => onSelectPrompt(topic.title, topic.id)}
                className="p-3.5 rounded-xl bg-white dark:bg-[#1E252D] border border-[#E7E2D8] dark:border-[#27323C] hover:border-[#8B3A1C] transition-colors cursor-pointer space-y-1"
              >
                <div className="text-xs font-serif font-bold text-[#1C1917] dark:text-[#F8FAFC]">
                  {topic.title}
                </div>
                <div className="text-[11px] font-sans text-[#78716C] dark:text-[#94A3B8] leading-tight">
                  {topic.desc}
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Epistemic note at the foot */}
      <div className="pt-4 text-center text-[11px] font-mono text-[#A8A29E] dark:text-[#64748B]">
        {isEn 
          ? 'Primary Sources • Scholars • Thirukkural • Archival Evidence-Based AI' 
          : 'முதன்மை ஆதாரங்கள் • அறிஞர்கள் • திருக்குறள் • சான்றுகள் அடிப்படையிலான AI'}
      </div>
    </div>
  );
};
