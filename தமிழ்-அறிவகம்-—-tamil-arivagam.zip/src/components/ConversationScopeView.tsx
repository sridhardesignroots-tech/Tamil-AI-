import React from 'react';
import { ClassificationResult } from '../utils/scopeClassifier';
import { Sparkles, ArrowRight, BookOpen, Compass, Landmark, Scroll, ShieldCheck, HelpCircle } from 'lucide-react';

interface ConversationScopeViewProps {
  userQuery: string;
  classification: ClassificationResult;
  onSelectSuggestedPrompt: (query: string) => void;
  onOpenCollections?: () => void;
  language: 'ta' | 'en';
}

export const ConversationScopeView: React.FC<ConversationScopeViewProps> = ({
  userQuery,
  classification,
  onSelectSuggestedPrompt,
  onOpenCollections,
  language
}) => {
  const isGreeting = classification.intent === 'GREETING';
  const isEn = language === 'en';

  return (
    <div className="max-w-3xl mx-auto py-10 px-4 space-y-8 animate-fade-in font-sans">
      {/* User's Original Message Bubble */}
      <div className="flex justify-end">
        <div className="bg-[#EFE9DD] dark:bg-[#1E2831] border border-[#E5DFC8] dark:border-[#354350] rounded-2xl rounded-tr-xs px-4 py-2.5 max-w-lg text-sm text-neutral-900 dark:text-neutral-100 font-serif shadow-xs">
          {userQuery}
        </div>
      </div>

      {/* Assistant Response Card */}
      <div className="bg-white dark:bg-[#1A2229] border border-[#E5DFC8] dark:border-[#2D3842] rounded-2xl p-6 shadow-xs space-y-5">
        <div className="flex items-center gap-2.5 pb-3 border-b border-[#E5DFC8]/60 dark:border-[#2D3842]">
          <div className="w-8 h-8 rounded-lg bg-[#A85C43] text-white flex items-center justify-center font-serif text-sm font-bold shadow-2xs">
            அ
          </div>
          <div>
            <div className="text-sm font-bold font-serif text-neutral-900 dark:text-white">
              {isEn ? 'Tamil AI — Scholarly Research Engine' : 'தமிழ் AI — ஆய்வுப் பெட்டகம்'}
            </div>
            <div className="text-[10px] font-mono uppercase tracking-widest text-[#9B8060] dark:text-[#C4A57F]">
              {isGreeting 
                ? (isEn ? 'CONVERSATIONAL GREETING' : 'வணக்கம்') 
                : (isEn ? 'RESEARCH SCOPE GUIDANCE' : 'ஆய்வு வழிகாட்டுதல்')}
            </div>
          </div>
        </div>

        {/* Response Body Text */}
        <div className="space-y-2">
          <p className="text-base text-neutral-800 dark:text-neutral-200 leading-relaxed font-serif whitespace-pre-line">
            {!isEn && classification.tamilMessage
              ? classification.tamilMessage
              : classification.message}
          </p>

          {!isGreeting && (
            <div className="p-3 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-lg text-xs text-amber-900 dark:text-amber-200 font-sans leading-relaxed">
              <span className="font-semibold block mb-0.5">
                {isEn ? 'Focus: Evidence Before Certainty' : 'கொள்கை: சான்றுகளே முதன்மையானவை'}
              </span>
              {isEn
                ? 'Tamil AI is dedicated exclusively to verified knowledge across Tamil literature, archaeology, epigraphy, social history, and traditional science.'
                : 'தமிழ் AI தமிழிலக்கியம், தொல்லியல், கல்வெட்டியல் மற்றும் வரலாற்றுத் தரவுகளில் மட்டுமே நிறுவப்பட்ட அறிவை வழங்குகிறது.'}
            </div>
          )}
        </div>

        {/* Suggested Research Prompts */}
        {classification.suggestedPrompts && classification.suggestedPrompts.length > 0 && (
          <div className="space-y-3 pt-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-mono uppercase font-bold text-neutral-500 dark:text-neutral-400 text-[10px] tracking-wider">
                {isGreeting 
                  ? (isEn ? 'EXPLORE RECOMMENDED INVESTIGATIONS' : 'பரிந்துரைக்கப்பட்ட ஆய்வுகள்') 
                  : (isEn ? 'TRY A TAMIL KNOWLEDGE INVESTIGATION' : 'பரிந்துரைக்கப்பட்ட ஆய்வுத் தலைப்புகள்')}
              </span>
              <span className="text-[10px] font-mono text-[#A85C43]">
                {isEn ? 'Click to initiate' : 'ஆய்வைத் தொடங்குக'}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {classification.suggestedPrompts.map((item, idx) => (
                <div
                  key={idx}
                  onClick={() => onSelectSuggestedPrompt(isEn ? item.query : (item.tamilQuery || item.query))}
                  className="p-3 rounded-xl border border-[#E5DFC8] dark:border-[#2D3842] bg-[#FAF7F0] dark:bg-[#151D23] hover:border-[#A85C43] dark:hover:border-[#D47B62] transition-all cursor-pointer group shadow-2xs space-y-1 text-left"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[9px] font-mono uppercase px-1.5 py-0.2 rounded bg-neutral-200/60 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400">
                      {item.category}
                    </span>
                    <ArrowRight className="w-3 h-3 text-neutral-400 group-hover:text-[#A85C43] group-hover:translate-x-0.5 transition-all" />
                  </div>
                  <div className="text-xs font-semibold text-neutral-900 dark:text-white font-serif group-hover:text-[#A85C43] transition-colors leading-snug">
                    {isEn ? item.query : (item.tamilQuery || item.query)}
                  </div>
                  {isEn && item.tamilQuery && (
                    <div className="text-[11px] font-tamil text-[#9B8060] truncate">
                      {item.tamilQuery}
                    </div>
                  )}
                  {!isEn && (
                    <div className="text-[11px] font-sans text-neutral-400 truncate">
                      {item.query}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Action button */}
        {onOpenCollections && (
          <div className="pt-2 flex items-center justify-center sm:justify-start">
            <button
              onClick={onOpenCollections}
              className="text-xs font-mono font-medium text-[#A85C43] dark:text-[#D47B62] hover:underline flex items-center gap-1.5 cursor-pointer"
            >
              <Scroll className="w-3.5 h-3.5" />
              <span>
                {isEn 
                  ? 'Browse All Indexed Tamil Archival Collections →' 
                  : 'அனைத்து தமிழ் ஆவணத் தொகுப்புகளையும் காண்க →'}
              </span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
