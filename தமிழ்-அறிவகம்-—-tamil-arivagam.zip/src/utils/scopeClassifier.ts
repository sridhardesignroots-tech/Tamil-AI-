/**
 * Tamil Arivagam - Scope & Conversation Classifier
 * Distinguishes between:
 * 1. Casual greetings
 * 2. In-scope Tamil knowledge questions
 * 3. Out-of-scope questions unrelated to Tamil knowledge
 */

export type QueryIntentType = 'GREETING' | 'TAMIL_RESEARCH' | 'OUT_OF_SCOPE';

export interface ClassificationResult {
  intent: QueryIntentType;
  message?: string;
  tamilMessage?: string;
  suggestedPrompts?: Array<{
    query: string;
    tamilQuery: string;
    category: string;
  }>;
}

const GREETING_PATTERNS = [
  /^(hi|hello|hey|vanakkam|வணக்கம்|namaste|vanakam|good\s+morning|good\s+afternoon|good\s+evening|greetings|howdy)\b/i,
  /^(who\s+are\s+you|what\s+is\s+tamil\s+arivagam|what\s+can\s+you\s+do|நீ\s+யார்|உன்னால்\s+என்ன\s+செய்ய\s+முடியும்)/i,
  /^(help|start|begin|வாழ்க\s+தமிழ்)/i
];

const OUT_OF_SCOPE_KEYWORDS = [
  'weather', 'temperature', 'forecast', 'rain today',
  'cricket score', 'football match', 'nba', 'ipl score', 'who won the match',
  'stock price', 'bitcoin', 'crypto', 'nasdaq', 'nifty',
  'python code', 'javascript error', 'react component bug', 'css flexbox', 'write a script', 'fix this code',
  'recipe for pizza', 'how to bake cake', 'pasta recipe',
  'hollywood movie', 'taylor swift', 'k-pop',
  'solve 2+2', 'quadratic equation', 'calculus problem',
  'flight ticket', 'hotel booking'
];

const TAMIL_AFFINITY_KEYWORDS = [
  'tamil', 'தமிழ்', 'tamilakam', 'தமிழகம்', 'dravidian', 'திராவிடம்',
  'sangam', 'சங்கம்', 'tolkappiyam', 'தொல்காப்பியம்', 'thirukkural', 'திருக்குறள்',
  'kural', 'குறள்', 'akanānūṟu', 'அகநானூறு', 'purananuru', 'புறநானூறு',
  'silappathikaram', 'சிலப்பதிகாரம்', 'manimekalai', 'மணிமேகலை',
  'keeladi', 'கீழடி', 'adichanallur', 'ஆதிச்சநல்லூர்', 'kodumanal', 'கொடுமணல்',
  'porunthal', 'பொருந்தல்', 'sivagalai', 'சிவகளை', 'korkai', 'கொற்கை', 'poompuhar', 'பூம்புகார்',
  'chola', 'சோழ', 'pandya', 'பாண்டிய', 'chera', 'சேர', 'pallava', 'பல்லவ',
  'ay dynasty', 'velir', 'வேளிர்', 'rajaraja', 'ராஜராஜ', 'rajendra', 'ராஜேந்திர',
  'inscriptions', 'கல்வெட்டு', 'epigraphy', 'tamil-brahmi', 'பிராமி', 'vatteluttu', 'வட்டெழுத்து',
  'manuscript', 'ஓலைச்சுவடி', 'olaichuvadi', 'copper plate', 'செப்பேடு',
  'maritime', 'yavana', 'யவனர்', 'muziris', 'முசிறி', 'arikamedu', 'அரிக்கமேடு',
  'pattanam', 'பட்டணம்', 'berenike', 'பெரெனிகே', 'srivijaya', 'ஸ்ரீவிஜயம்', 'kadaram', 'கடாரம்',
  'pallar', 'பள்ளர்', 'mallar', 'மள்ளர்', 'marutham', 'மருதம்', 'mukkudal', 'முக்கூடல்', 'pallu', 'பள்ளு',
  'devendrakula', 'வேளாளர்', 'vellalar', 'paraiyar', 'maravar', 'nadar', 'chettiar',
  'siddha', 'சித்தர்', 'vaigai', 'வைகை', 'kaveri', 'காவிரி', 'thamirabarani', 'தாமிரபரணி',
  'thinai', 'திணை', 'kurinji', 'முல்லை', 'நெய்தல்', 'பாலை',
  'swaminatha iyer', 'உ.வே.சா', 'mahadevan', 'ஐராவதம்', 'parithimar kalaignar',
  'diaspora', 'eelam', 'ஈழம்', 'ceylon', 'malaysia tamil', 'singapore tamil',
  'jambai', 'mangulam', 'sittannavasal', 'thanjavur', 'தஞ்சாவூர்', 'madurai', 'மதுரை',
  'karur', 'கரூர்', 'gangaikonda', 'கங்கைகொண்ட'
];

export function classifyUserQuery(rawQuery: string): ClassificationResult {
  const query = rawQuery.trim();
  const lower = query.toLowerCase();

  // 1. Check for Greetings
  const isGreeting = GREETING_PATTERNS.some(pattern => pattern.test(query));
  if (isGreeting || query.length <= 4 && (lower === 'hi' || lower === 'hey')) {
    let greetingText = "Vanakkam! 🙏 How can I help you explore Tamil knowledge today?";
    if (lower.includes('morning')) greetingText = "Good morning! ☀️ What would you like to explore in Tamil knowledge?";
    if (lower.includes('evening')) greetingText = "Good evening! 🌅 How can I help you explore Tamil history and literature?";
    if (lower.includes('வணக்கம்')) greetingText = "வணக்கம்! 🙏 தமிழ் மொழி, இலக்கியம், வரலாறு, தொல்லியல் குறித்து என்ன ஆய்வு செய்ய விரும்புகிறீர்கள்?";

    return {
      intent: 'GREETING',
      message: greetingText,
      tamilMessage: 'வணக்கம்! தமிழ் அறிவுத் துறையில் நீங்கள் என்ன ஆய்வு செய்ய விரும்புகிறீர்கள்?',
      suggestedPrompts: [
        {
          query: 'What evidence exists for trade between Tamilakam and the Roman world?',
          tamilQuery: 'பண்டைய தமிழகத்திற்கும் உரோமானிய உலகுக்கும் இடையிலான வணிகச் சான்றுகள் யாவை?',
          category: 'Maritime & Trade'
        },
        {
          query: 'What is known about Keeladi from excavation reports?',
          tamilQuery: 'கீழடி அகழாய்வு அறிக்கைகள் மூலம் தெரியவரும் உண்மைகள் யாவை?',
          category: 'Archaeology'
        },
        {
          query: 'What do Tamil-Brahmi inscriptions reveal about early Tamil script evolution?',
          tamilQuery: 'தமிழ்-பிராமிக் கல்வெட்டுகள் தமிழ் எழுத்து வளர்ச்சி குறித்து எவற்றை வெளிப்படுத்துகின்றன?',
          category: 'Epigraphy'
        },
        {
          query: 'What sources discuss the history of Pallar?',
          tamilQuery: 'பள்ளர் சமூக வரலாறு குறித்த வரலாற்றுச் சான்றுகளும் மூல நூல்களும் யாவை?',
          category: 'Social History'
        }
      ]
    };
  }

  // 2. Check for Explicit Tamil Affinity
  const hasTamilAffinity = TAMIL_AFFINITY_KEYWORDS.some(kw => lower.includes(kw));

  // 3. Check for Completely Unrelated Out-of-Scope Queries
  const isExplicitlyOutOfScope = OUT_OF_SCOPE_KEYWORDS.some(kw => lower.includes(kw));

  if (isExplicitlyOutOfScope && !hasTamilAffinity) {
    return {
      intent: 'OUT_OF_SCOPE',
      message: "I’m Tamil Arivagam, an AI research platform focused exclusively on Tamil knowledge. I can help you explore Tamil language, history, literature, archaeology, inscriptions, manuscripts, Tamil people and communities, culture, traditions, scholars, and related research.\n\nPlease ask me something related to Tamil and Tamil knowledge.",
      tamilMessage: "அது தமிழ் அறிவகத்தின் ஆய்வு எல்லைக்கு அப்பாற்பட்டது. தமிழ் மொழி, இலக்கியம், வரலாறு, தொல்லியல், கல்வெட்டுகள், சமூக வரலாறு மற்றும் பண்பாடு தொடர்பான வினாக்களை நீங்கள் என்னிடம் கேட்கலாம்.",
      suggestedPrompts: [
        {
          query: 'What evidence exists for trade between Tamilakam and the Roman world?',
          tamilQuery: 'பண்டைய தமிழகத்திற்கும் உரோமானிய உலகுக்கும் இடையிலான வணிகச் சான்றுகள் யாவை?',
          category: 'Trade & Maritime'
        },
        {
          query: 'What do Sangam texts say about Marutham landscape & agriculture?',
          tamilQuery: 'மருத நில வேளாண்மை குறித்து சங்க இலக்கியங்கள் கூறுவது யாது?',
          category: 'Literature'
        },
        {
          query: 'What is known about Keeladi from excavation reports?',
          tamilQuery: 'கீழடி அகழாய்வு அறிக்கைகள் கூறும் தரவுகள் யாவை?',
          category: 'Archaeology'
        },
        {
          query: 'What inscriptions record the naval campaign of Rajendra Chola I?',
          tamilQuery: 'முதலாம் ராஜேந்திர சோழனின் கடற்படைப் படையெடுப்பைக் குறிக்கும் கல்வெட்டுகள் யாவை?',
          category: 'Inscriptions'
        }
      ]
    };
  }

  // 4. Default: Treat as Tamil Research Inquiry
  return {
    intent: 'TAMIL_RESEARCH'
  };
}
