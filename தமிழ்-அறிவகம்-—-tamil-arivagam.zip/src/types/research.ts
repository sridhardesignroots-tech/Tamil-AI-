/**
 * Tamil AI - Type Definitions
 * Evidence-first schema for Tamil language, literature, history, archaeology,
 * inscriptions, manuscripts, copper plates, ancient books, scholars, and Thirukkural.
 */

export type ResearchMode = 'quick' | 'research' | 'deep';

export type LanguagePreference = 'ta' | 'en';

export type ThemePreference = 'ivory' | 'ink' | 'night';

export type ReadingDensity = 'relaxed' | 'balanced' | 'compact';

/**
 * 5-tier Evidence Level Classification
 * 🟢 Direct Evidence (Primary source)
 * 🔵 Scholarly Interpretation (Identified scholars/research)
 * 🟡 Probable (Supported by evidence but not certain)
 * 🟠 Speculative (Possible interpretation with limited evidence)
 * 🟣 AI Visualization (Generated illustration and NOT historical evidence)
 */
export type EvidenceLevel = 
  | 'DIRECT_EVIDENCE'
  | 'SCHOLARLY_INTERPRETATION'
  | 'PROBABLE'
  | 'SPECULATIVE'
  | 'AI_VISUALIZATION';

export interface EvidenceStatus {
  primaryTextual: 'FOUND' | 'NOT_IDENTIFIED' | 'UNCLEAR';
  archaeological: 'FOUND' | 'PARTIAL' | 'NOT_FOUND' | 'UNCLEAR';
  independentSupporting: 'FOUND' | 'UNCLEAR' | 'NOT_IDENTIFIED';
  scholarlyDiscussion: 'FOUND' | 'DEBATED' | 'NOT_FOUND';
  directConnectionToModernTerminology: 'ESTABLISHED' | 'UNCERTAIN' | 'NOT_ESTABLISHED' | 'DISTINCT';
  dating: 'DOCUMENTED' | 'UNCERTAIN' | 'APPROXIMATE';
}

export interface ClaimWithEvidenceLevel {
  id: string;
  claim: string;
  tamilClaim?: string;
  level: EvidenceLevel;
  sourceReference: string;
  evidentiaryNote: string;
}

export interface LexicalItem {
  term: string;
  meaning: string;
  notes?: string;
}

export interface PrimaryText {
  id: string;
  title: string;
  work: string;
  period: string;
  reference: string;
  originalTamil: string;
  modernTamil: string;
  englishTranslation: string;
  phoneticTransliteration?: string;
  lexicalBreakdown?: LexicalItem[];
  provenanceNotes: string;
  verifiedStatus: 'VERIFIED' | 'PARTIALLY_VERIFIED' | 'UNVERIFIED';
  archivalScanUrl?: string;
  archivalScanCaption?: string;
}

export interface ArchivalScanItem {
  id: string;
  title: string;
  sourceType?: string;
  period: string;
  location: string;
  language?: string;
  originalLanguage?: string;
  script?: string;
  repository: string;
  imageUrl: string;
  highResUrl?: string;
  transcription?: string;
  transliteration?: string;
  modernTamilTranslation?: string;
  englishTranslation?: string;
  whatItEstablishes?: string;
  citationReference?: string;
  zoomLevel?: number;
}

export interface ArchaeologicalEvidence {
  id: string;
  objectName: string;
  site: string;
  excavationSeason?: string;
  periodDate: string;
  excavationReport: string;
  description: string;
  museumOrRepository: string;
  verifiedStatus: 'VERIFIED' | 'PARTIALLY_VERIFIED';
  hasAuthenticPhoto?: boolean;
  photoCaption?: string;
  imageUrl?: string;
}

export interface InscriptionEvidence {
  id: string;
  codeOrTitle: string;
  script: 'Tamil-Brahmi' | 'Vatteluttu' | 'Tamil' | 'Grantha' | string;
  location: string;
  rulerOrDynasty?: string;
  periodDate: string;
  originalTextOrTransliteration: string;
  translation: string;
  significance: string;
  epigraphicalReference: string;
  archivalScanUrl?: string;
}

export interface ForeignSource {
  id: string;
  workTitle: string;
  author: string;
  periodDate: string;
  excerptOriginalOrTranslation: string;
  citationReference: string;
  contextualNotes: string;
}

export interface ScholarlyDebate {
  id: string;
  topicTitle: string;
  interpretationA: {
    scholar: string;
    publication: string;
    date: string;
    argument: string;
    evidenceUsed: string[];
  };
  interpretationB: {
    scholar: string;
    publication: string;
    date: string;
    argument: string;
    evidenceUsed: string[];
  };
  whatIsAgreedUpon: string;
  whatRemainsDebated: string;
}

export interface TimelineItem {
  id: string;
  era: 'Ancient' | 'Medieval' | 'Early Modern' | 'Modern';
  dateLabel: string;
  dateCertainty?: 'DOCUMENTED' | 'APPROXIMATE' | 'UNCERTAIN';
  title: string;
  tamilTitle?: string;
  description?: string;
  event?: string;
  source?: string;
  evidence?: string;
  category: 'Literature' | 'Archaeology' | 'Epigraphy' | 'Foreign Source' | 'Scholarly Publication';
  entityRefId?: string;
}

export interface BookRecord {
  id: string;
  title: string;
  tamilTitle?: string;
  author: string;
  authorLifespan?: string;
  publicationYear: string | number;
  publisher?: string;
  subject: string;
  coverImage?: string;
  whyRelevant: string;
  relevantPassageOrPage?: string;
  referenceSource?: string;
  isbnOrRef?: string;
}

export interface Scholar {
  id: string;
  fullName: string;
  knownAs: string;
  profession: string;
  field: string;
  institution: string;
  region: string;
  birthDeath: string; // e.g. "1855 – 1942" or "Born 1954"
  isLiving?: boolean;
  careerTimeline: string[];
  keyPublications: string[];
  researchContribution: string;
  relevanceToQuestion: string;
  photoStatus: 'AUTHENTIC' | 'NONE' | 'ILLUSTRATION';
  photoNote: string;
  imageUrl?: string;
}

export interface TraditionalCommentary {
  commentator: string;
  period: string;
  commentary: string;
}

export interface ThirukkuralRecord {
  kuralNumber: number;
  line1: string;
  line2: string;
  transliteration: string;
  paal: string; // e.g., 'அறத்துப்பால் / Book of Virtue'
  iyal: string; // e.g., 'இல்லறவியல் / Domestic Life'
  adhikaram: string; // e.g., 'கல்வி / Learning'
  adhikaramNumber: number;
  porul?: string; // Concise traditional/clear explanation
  modernTamilExplanation?: string;
  modernTamilTranslation?: string;
  englishTranslation: string;
  traditionalCommentaries?: TraditionalCommentary[];
  commentaries?: Array<{
    scholar: string;
    period: string;
    tamilText: string;
    englishSummary: string;
  }>;
  lexicalAnalysis?: Array<{
    word: string;
    grammar: string;
    meaning: string;
  }>;
  scholarlyInterpretations?: string[];
  relatedKurals?: Array<{ number: number; line1: string; theme: string }>;
  extendedRelatedKurals?: Array<{ number: number; line1: string; line2?: string; theme: string; meaning?: string }>;
  sources?: string[];
  historicalContext?: string;
  crossReferences?: string[];
}

export interface SourceItem {
  id: string;
  title: string;
  author: string;
  publication: string;
  date: string;
  publisherOrJournal: string;
  sourceType: 'Primary Inscription' | 'Sangam Text' | 'Excavation Report' | 'Classical Foreign Text' | 'Monograph' | 'Epigraphical Survey' | 'Palm-Leaf Manuscript';
  verificationStatus: 'VERIFIED' | 'PARTIALLY_VERIFIED' | 'UNVERIFIED';
  relevantPassage: string;
  pageOrReference: string;
  whyItMatters: string;
  relatedSources: string[];
  archivalScanUrl?: string;
}

export interface RelatedResearchItem {
  topic: string;
  tamilTopic?: string;
  relevanceNotes: string;
  suggestedQuery: string;
}

export interface NewsItem {
  id: string;
  headline: string;
  publisher: string;
  date: string;
  factualSummary: string;
  relevance: string;
  linkText: string;
}

export interface AIIllustration {
  id: string;
  title: string;
  promptTheme?: 'agricultural_setting' | 'architecture' | 'people_clothing' | 'map' | 'historical_event' | string;
  caption: string;
  disclaimer: string;
  imageUrl: string;
  aspectRatio?: string;
  variationUrls?: string[];
  sceneDescription?: string;
  historicalBasis?: string;
}

export interface DirectAnswerSection {
  tamilExplanation: string;
  englishExplanation: string;
  meaning: string;
  historicalContext: string;
  relevantTerminology: Array<{ term: string; meaning: string; context?: string }>;
  datesOrPeriod: string;
  dateCertainty: 'DOCUMENTED' | 'APPROXIMATE' | 'UNCERTAIN';
}

export interface KnowledgeNode {
  id: string;
  label: string;
  tamilLabel?: string;
  type: 'question' | 'terminology' | 'literature' | 'inscription' | 'site' | 'scholar' | 'publication' | 'related' | 'kural' | string;
  description: string;
  details?: string;
}

export interface KnowledgeEdge {
  from: string;
  to: string;
  label?: string;
}

export interface ResearchBrief {
  id: string;
  query: string;
  tamilQuery: string;
  category: 'Maritime & Commerce' | 'Archaeology' | 'Epigraphy' | 'Social History' | 'Literature' | 'Philosophy' | 'Thirukkural';
  completedDate: string;
  researchMode: ResearchMode;
  isDemoData: boolean;
  evidenceStatus: EvidenceStatus;
  
  // Section 2: Direct Answer
  directAnswer?: DirectAnswerSection;
  
  keyFinding: string;
  whatSourceActuallySays: string;
  
  // Section 3: Evidence Level classifications
  claimsWithLevels?: ClaimWithEvidenceLevel[];

  // Primary Evidence (Section 2.C)
  primaryTexts: PrimaryText[];
  archivalScans?: ArchivalScanItem[];
  archaeologicalEvidence: ArchaeologicalEvidence[];
  inscriptions: InscriptionEvidence[];
  foreignSources: ForeignSource[];
  
  // Related Books (Section 4)
  relatedBooks?: BookRecord[];
  
  // Scholars (Section 5)
  scholars?: Scholar[];
  
  // Historiography
  scholarlyDebates: ScholarlyDebate[];
  whatIsEstablished: string[];
  whatRemainsDebated: string[];
  
  // Timeline (Section 2.B)
  timeline: TimelineItem[];
  
  knowledgeGraph: {
    nodes: Array<{
      id: string;
      label: string;
      tamilLabel?: string;
      type: 'question' | 'terminology' | 'literature' | 'inscription' | 'site' | 'scholar' | 'publication' | 'related' | 'kural';
      description: string;
      details?: string;
    }>;
    edges: Array<{
      from: string;
      to: string;
      label?: string;
    }>;
  };
  
  // Thirukkural (Section 8)
  thirukkural?: ThirukkuralRecord;
  
  // AI Historical Visualization (Section 7)
  aiIllustrations?: AIIllustration[];
  customVisualizationPrompts?: string[];
  
  relatedResearch: RelatedResearchItem[];
  recentNewsOrDevelopments?: NewsItem[];
}

export type LensEntityType = 
  | 'source'
  | 'scholar'
  | 'book'
  | 'archaeology'
  | 'inscription'
  | 'manuscript'
  | 'location'
  | 'foreignSource'
  | 'primaryText'
  | 'thirukkural'
  | 'archivalScan'
  | 'debate'
  | 'timeline'
  | 'knowledgeNode';

export interface LensSelection {
  type: LensEntityType;
  id: string;
  title: string;
  data: any;
}

export interface PersonalCollection {
  id: string;
  name: string;
  description: string;
  createdDate: string;
  itemCount: number;
  savedBriefIds: string[];
  savedBookIds: string[];
  savedScholarIds: string[];
  savedScanIds: string[];
}

export interface UserPreferences {
  defaultMode: ResearchMode;
  language: LanguagePreference;
  theme: ThemePreference;
  readingDensity: ReadingDensity;
  tamilTextSize: 'normal' | 'medium' | 'large';
  evidencePreferences: {
    prioritizePrimaryText: boolean;
    requireArchaeology: boolean;
    showScholarlyDebates: boolean;
    showUncertaintyBadges: boolean;
    showProvenance: boolean;
    showLexicalBreakdown: boolean;
    allowAIIllustrations: boolean;
  };
  aiBehaviour: {
    strictEvidenceFiltering: boolean;
    distinguishModernFromAncientTerminology: boolean;
    neverManufactureCertainty: boolean;
  };
}
